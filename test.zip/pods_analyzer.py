import argparse
import math
import sys

from pkg.analyzers.asi import kubelet_log_analyzer, alinet_log_analyzer
from pkg.utils import common_util, io_util
import copy
import logging
from test import test_env
from pkg.framework import context

def init_kubelet_analyzer(context, log_file, from_timestamp, to_timestamp):
    kubelet_analyzer_args = {
        'context': context,
        'log_parser': {
            'class': 'pkg.analyzers.log_analyzer.CommonLogParser',
            'init_args': {
                'log_pattern': r'^([\S])(\S+ \S+)   (\S+) (\S+) ([\S|\s]+)',
                'date_time_format': '%Y%m%d %H:%M:%S.%f',
                'date_time_convert_eval': '"2023"+date_time',
                'date_time_index': 2,
                'log_level_index': 1,
                'source_index': 4,
                'content_start_index': 5
            }
        },
        'log_processor': {
            'class': 'pkg.analyzers.asi.kubelet_log_analyzer.PodRuntimeInfoProcessor',
            'init_args': {}
        },
    }
    kubelet_analyzer = kubelet_log_analyzer.KubeletLogAnalyzer("kubelet_log_analyzer", **kubelet_analyzer_args)
    kubelet_analyzer.process(log_file, from_timestamp=from_timestamp, to_timestamp=to_timestamp)
    return kubelet_analyzer


def init_alinet_analyzer(context, log_file, from_timestamp, to_timestamp):
    alinet_analyzer_args = {
        'context': context,
        'log_parser': {
            'class': 'pkg.analyzers.log_analyzer.CommonLogParser',
            'init_args': {
                'log_pattern': r'^time="(\S+ \S+)\d\d\d" level=(\S+) ([\S|\s]+)',
                'date_time_format': '%Y-%m-%d %H:%M:%S.%f',
                'date_time_index': 1,
                'log_level_index': 2,
                'source_index': 2,
                'content_start_index': 3
            }
        },
        'log_processor': {
            'class': 'pkg.analyzers.asi.alinet_log_analyzer.PodNetworkInfoProcessor',
            'init_args': {}
        },
    }
    alinet_analyzer = alinet_log_analyzer.AlinetLogAnalyzer("alinet_log_analyzer", **alinet_analyzer_args)
    alinet_analyzer.process(log_file, from_timestamp=from_timestamp, to_timestamp=to_timestamp)
    return alinet_analyzer


def get_events_and_timestamp_range(pod_infos):
    events_result = set()
    time_range = [math.inf, 0]
    for _, events in pod_infos.items():
        for event_key, time in events.items():
            events_result.add(event_key)
            if time < time_range[0]:
                time_range[0] = time
            if time > time_range[1]:
                time_range[1] = time
    return events_result, math.floor(time_range[0]), math.ceil(time_range[1])

def get_qps_statistic(pod_infos):
    events, from_timestamp, to_timestamp = get_events_and_timestamp_range(pod_infos)
    qps_statistics = {}
    logging.info(f"events: {events}")
    for event in events:
        qps_statistics[event] = [0] * (to_timestamp - from_timestamp + 1)
    for events in pod_infos.values():
        for event, time in events.items():
            time = math.floor(time)
            if time < from_timestamp or time > to_timestamp:
                logging.warning(f"time:{time}, from_timestamp:{from_timestamp}, to_timestamp:{to_timestamp}")
                continue
            qps_statistics[event][time - from_timestamp] += 1
    return qps_statistics

def get_latency_statistics(pod_infos, phase_latency_mapping):
    latency_statistics = {}
    phase_latency_data = {}
    for events in pod_infos.values():
        for phase, (start_event, end_event) in phase_latency_mapping.items():
            start_time = events.get(start_event)
            end_time = events.get(end_event)
            if start_time is None or end_time is None:
                logging.debug(f"skip not-found phase {phase}, {start_event}"
                              f" time={start_time}, {end_event} time={end_time}")
                continue
            latency = end_time - start_time
            latency_array = phase_latency_data.get(phase)
            if latency_array is None:
                latency_array = []
                phase_latency_data[phase] = latency_array
            phase_latency_data[phase].append(latency)
    for phase, latency_array in phase_latency_data.items():
        latency_statistics[phase] = (round(min(latency_array), 3),
                                     round(max(latency_array), 3),
                                     round(sum(latency_array) / len(latency_array), 3))
    return latency_statistics

def merge_pod_infos(info_dict1, info_dict2):
    if len(info_dict1) == 0:
        return copy.deepcopy(info_dict2)
    result = copy.deepcopy(info_dict1)
    for pod, info in info_dict2.items():
        existing_info = result.get(pod)
        if existing_info is None:
            logging.warning(f"incomplete info for pod {pod}")
        else:
            result[pod] = {**existing_info, **info}
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='pods analyzer')
    parser.add_argument("--log_level", help="log level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"])
    parser.add_argument("--kubelet_log", help="kubelet log path")
    parser.add_argument("--alinet_log", help="alinet log path")
    parser.add_argument("--vc_syncer_log", help="vc-syncer log path")
    parser.add_argument("--time_format", help="from time", default="%Y-%m-%d %H:%M:%S")
    parser.add_argument("--from_time", help="from time")
    parser.add_argument("--to_time", help="to time")
    parser.add_argument("--import_path", help="import file path of pod infos")
    parser.add_argument("--export_path", help="export file path of pod infos")

    #  parse args
    args = parser.parse_args()

    # init context
    logging.basicConfig(stream=None, level=args.log_level,
                        format='%(asctime)s - %(levelname)s: %(message)s')
    logging.info(f"arguments: {args}")
    context = context.Context(sys.path[0], None)

    # load pod_infos
    pod_infos = {}
    if args.import_path:
        pod_infos = io_util.load_dict(args.import_path)
        logging.info(f"loaded pod_infos from {args.import_path}: {pod_infos}")

    from_timestamp, to_timestamp = None, None
    if args.from_time:
        from_timestamp = common_util.parse_timestamp(args.from_time, args.time_format)
    if args.to_time:
        to_timestamp = common_util.parse_timestamp(args.to_time, args.time_format)
    if args.kubelet_log:
        kubelet_analyzer = init_kubelet_analyzer(context, args.kubelet_log, from_timestamp, to_timestamp)
        kubelet_processor = kubelet_analyzer.get_processor()
        kubelet_pod_infos = kubelet_processor.get_pod_infos()
        pod_infos = merge_pod_infos(pod_infos, kubelet_pod_infos)
    if args.alinet_log:
        alinet_analyzer = init_alinet_analyzer(context, args.alinet_log, from_timestamp, to_timestamp)
        alinet_processor = alinet_analyzer.get_processor()
        alinet_pod_infos = alinet_processor.get_pod_infos()
        pod_infos = merge_pod_infos(pod_infos, alinet_pod_infos)
    logging.info(f"pod_infos:{pod_infos}")

    if args.export_path:
        io_util.save_dict(args.export_path, pod_infos)
        logging.info(f"exported pod_infos to {args.export_path}")

    if len(pod_infos) == 0:
        logging.error(f"pods not found")
        exit(1)

    # QPS statistics
    qps_statistic = get_qps_statistic(pod_infos)
    logging.info(f"qps_statistic:")
    for event, statistic in qps_statistic.items():
        print(event)
        print(statistic)

    # Latency statistics
    phase_latency_mapping = {
        "ToFirstSync": ("FirstSeen", "FirstSync"),
        "MountVolumes": ("MountVolumesStart", "MountVolumesDone"),
        "CreatePodSandbox": ("PodSandboxCreating", "PodSandboxCreated"),
        "CreateContainer": ("ContainerCreating", "ContainerCreated"),
        "StartContainer": ("ContainerCreated", "ContainerStarted"),
        "AttachNetworkInterface": ("CNIFirstSeen", "CNIAttached"),
    }
    latency_statistics = get_latency_statistics(pod_infos, phase_latency_mapping)
    logging.info(f"latency_statistics: ")
    for key, statistic in latency_statistics.items():
        print(key)
        print(statistic)