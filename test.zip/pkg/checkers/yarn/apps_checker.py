from pkg.caches.yarn.common import *
from pkg.checkers.generic import *


class AppsChecker(Checker):

    def __init__(self, key, context):
        super().__init__(key, context)

    def check(self, app_ids):
        if isinstance(app_ids, str):
            app_ids = [app_ids]
        verification = Verification(CHECKER_KEY_YARN_APPS)
        for app_id in app_ids:
            app = get_required_app(self.context, app_id)
            sub_verf = verification.add_sub_verification('Check app <{}>'.format(app_id))
            queue = get_required_queue(self.context, app.get_queue())
            check_app(self.context, sub_verf, app, queue)
        verification.refresh_status(recursively=True)
        return verification
