from pkg.framework import check
from pkg.checkers.generic import CheckOption
from pkg.framework.check import Verification
from pkg.constants import *
from pkg.caches.yarn.common import *
from pkg.checkers.generic import *


class QueuesChecker(Checker):

    def __init__(self, key, context):
        super().__init__(key, context)

    def check(self, queue_names, check_pending_apps, filter_out_non_pending=False):
        if isinstance(queue_names, str):
            queue_names = [queue_names]
        verification = Verification(CHECKER_KEY_YARN_QUEUES)
        for queue_name in queue_names:
            queue = get_required_queue(self.context, queue_name)
            self.__check_queue(verification, queue, check_pending_apps=check_pending_apps,
                               filter_out_non_pending=filter_out_non_pending, recursively=True)
        verification.refresh_status(recursively=True)
        return verification

    def __check_queue(self, verification, queue, check_pending_apps=False,
                      filter_out_non_pending=False, recursively=True):
        # skip leaf-queue without pending containers
        if filter_out_non_pending and queue.get_num_pending_containers() == 0:
            logging.info('skip non-pending leaf queue {}'.format(queue.get_path()))
            return
        sub_verf = verification.add_sub_verification(
            'Check {} queue <{}>'.format('leaf' if queue.is_leaf() else 'parent', queue.get_path()),
            status=CHECKER_VERIFICATION_STATUS_SUCCEEDED)
        self.__check_queue_state(sub_verf, queue, check_pending_apps)
        if recursively and len(queue.get_child_queues()) > 0:
            for child_queue in queue.get_child_queues().values():
                self.__check_queue(sub_verf, child_queue, check_pending_apps=check_pending_apps,
                                   filter_out_non_pending=filter_out_non_pending, recursively=recursively)

    def __check_queue_state(self, verification, queue, check_pending_apps):
        # check queue resource
        if queue.is_leaf():
            verification.add_output('Apps', queue.get_apps_info(delimiter=', '))
            verification.add_output('Containers', queue.get_containers_info(delimiter=', '))
        partition_infos = queue.get_partition_infos()
        no_pending = True
        for partition_name, partition_info in partition_infos.items():
            if partition_info.has_pending_resource():
                no_pending = False
                verification.add_output('Pending in partition "{}"'.format(partition_name),
                                        ['Capacities: {}'.format(partition_info.get_capacities_info(', ')),
                                         'Resources: {}'.format(partition_info.get_resources_info(', ')),
                                         'AM Resources: {}'.format(partition_info.get_am_resources_info(', ')),
                                         'User Resources: {}'.format(queue.get_user_resources_info(', ')),
                                         'Headroom: {}'.format(partition_info.get_headroom_info(', '))
                                         ])
                if queue.get_num_pending_apps() is not None and queue.get_num_pending_apps() > 0:
                    verification.add_output('Diagnostic for pending apps',
                                            'perhaps limited by AMHeadroom={} or Headroom={}'
                                            .format(partition_info.get_am_headroom(), partition_info.get_headroom()))
                try:
                    activities = get_activities(self.context, queue.get_path(), partition_name)
                    if len(activities) > 0:
                        activity = activities[0]
                        columns, rows = activity.get_columns_rows()
                        common_util.format_rows(rows, column_max_width=50)
                        table = common_util.generate_table(columns, rows)
                        verification.add_output('Activities for pending apps\n{}'.format(table))
                except Exception as e:
                    logging.warning("skip analyzing activities for partition {} queue {} since {}".format(
                        partition_name, queue.get_path(), e))
                # check pending apps
                if check_pending_apps and queue.is_leaf() and (
                        queue.get_num_pending_apps() > 0 or queue.get_num_pending_containers() > 0):
                    self.__check_pending_apps(verification, queue)
                verification.succeeded()
        if no_pending and queue.is_leaf():
            verification.add_output('No pending resource')
            verification.succeeded()

    def __check_pending_apps(self, verification, queue):
        sub_verf = verification.add_sub_verification('Check pending apps in queue <{}>'.format(queue.get_path()))
        apps_cache = get_required_cache(self.context, CACHE_KEY_YARN_APPS)
        apps = apps_cache.get_data().values()
        pending_apps = list(
            filter(lambda x: x.get_queue() == queue.get_name() and x.get_num_pending_containers() > 0, apps))
        for app in pending_apps:
            app_verf = sub_verf.add_sub_verification('Check pending app <{}>'.format(app.get_id()))
            check_app(self.context, app_verf, app, queue)
        sub_verf.refresh_status(recursively=True)
