import os.path

from pkg.checkers.generic import CheckOption
from pkg.caches.yarn.common import *
from pkg.constants import *
from pkg.utils import io_util
from pkg.analyzers.log_analyzer import *


class RMStateCheckOption(CheckOption):

    def check(self, verification):
        # Check RM State
        yarn_basic_info = get_required_yarn_basic_info(self.context)
        yarn_state_cache = get_required_cache(self.context, CACHE_KEY_YARN_STATE)
        rm_states = yarn_state_cache.get_data(YARN_STATE_KEY_RM_STATES)
        # Check RM HA state
        verification.add_output("BasicInfo", yarn_basic_info.to_json())
        if yarn_basic_info.ha_enabled:
            ha_verf = verification.add_sub_verification('Check RM HA state')
            ha_verf.add_sub_verification("Number of RMs > 1", assert_result=len(rm_states) > 1)
            active_rm_id = None
            for rm_state in rm_states:
                state_info_dict = rm_state.get_info_dict()
                rm_state_verf = verification.add_sub_verification(
                    'Check RM state for {} - {}'.format(rm_state.get_id(), rm_state.get_hostname()))
                rm_state_verf.add_output("RMState Info", state_info_dict)
                rm_state_verf.add_sub_verification(
                    "haZooKeeperConnectionState == CONNECTED", assert_result=state_info_dict.get(
                        'haZooKeeperConnectionState') == 'CONNECTED' or state_info_dict.get(
                        'haZooKeeperConnectionState') == 'Connected to zookeeper : true')
                rm_state_verf.add_sub_verification(
                    "Use ZK StateStore", assert_result=state_info_dict.get(
                        'rmStateStoreName') == 'org.apache.hadoop.yarn.server.resourcemanager.recovery.ZKRMStateStore')
                if state_info_dict.get('haState') == 'ACTIVE':
                    active_rm_id = rm_state.get_id()
            ha_verf.add_sub_verification("Has active RM: {}".format(active_rm_id),
                                         assert_result=active_rm_id is not None)


class NodesCheckOption(CheckOption):

    def check(self, verification):
        nodes_cache = get_required_cache(self.context, CACHE_KEY_YARN_NODES)
        nodes = nodes_cache.get_data()
        state_groups = common_util.group_by_dict(nodes.values(), lambda n: n.get_state(), lambda n: n.get_id())
        groups_info_dict = dict(map(lambda kv: [kv[0], len(kv[1])], state_groups.items()))
        verification.add_output("States Info", groups_info_dict)
        verification.add_sub_verification("Number of RUNNING nodes > 0",
                                          assert_result=state_groups.get("RUNNING") is not None)
        self.__check_no_status(verification, state_groups, "UNHEALTHY")
        self.__check_no_status(verification, state_groups, "DECOMMISSIONING")

    def __check_no_status(self, verification, state_groups, check_status):
        verification.add_sub_verification(
            "Number of {} nodes == 0{}".format(check_status,
                                               '' if state_groups.get(check_status) is None
                                               else ' (actual: {})'.format(len(state_groups.get(check_status)))),
            assert_result=state_groups.get(check_status) is None)


class MetricsCheckOption(CheckOption):

    def __init__(self, key, context, interval_s, max_wait_s):
        super().__init__(key, context)
        self.__interval_s = interval_s
        self.__max_wait_s = max_wait_s

    def check(self, verification):
        metrics_analyzer = self.context.get_analyzer(ANALYZER_KEY_YARN_METRICS)
        # last_report = None
        report = metrics_analyzer.process_periodically(self.__interval_s, self.__max_wait_s)
        verification.add_output("HEALTHY diagnostics", report.get_healthy_diagnostics())
        if len(report.get_unhealthy_diagnostics()) > 0:
            verification.add_output("UNHEALTHY diagnostics", report.get_unhealthy_diagnostics())
        verification.add_sub_verification("Number of UNHEALTHY diagnostics == 0",
                                          assert_result=len(report.get_unhealthy_diagnostics()) == 0)


class ConfCheckOption(CheckOption):

    def __init__(self, key, context, check_set):
        super().__init__(key, context)
        self.__check_set = check_set

    def check(self, verification):
        active_rm_state = get_active_rm_state(self.context)
        chosen_conf_templates_dir = None
        for check_item in self.__check_set:
            match_regex = check_item.get(CONF_KEY_VERSION_MATCH_REGEX)
            if re.match(match_regex, active_rm_state.get_version()):
                chosen_conf_templates_dir = check_item.get(CONF_KEY_CONF_TEMPLATES_DIR)
                logging.info("chosen conf templates directory: {}".format(chosen_conf_templates_dir))
                break
        verification.add_sub_verification("Chosen conf templates {}".format(chosen_conf_templates_dir),
                                          assert_result=chosen_conf_templates_dir is not None)
        if chosen_conf_templates_dir is None:
            raise ConfError("failed to find matched conf templates!")
        if not os.path.isabs(chosen_conf_templates_dir):
            chosen_conf_templates_dir = os.path.join(self.context.get_executing_path(), chosen_conf_templates_dir)
        if not os.path.exists(chosen_conf_templates_dir):
            raise ConfError("configured conf_templates_dir {} not found!".format(chosen_conf_templates_dir))
        conf_cache = get_required_cache(self.context, CACHE_KEY_YARN_CONF)
        resource_conf_dict = conf_cache.get_data()
        conf_template_files = io_util.list_file(chosen_conf_templates_dir)
        for conf_template_file in conf_template_files:
            _, conf_template_name = os.path.split(conf_template_file)
            logging.info("start comparing conf template: {}".format(conf_template_name))
            conf_file_path = os.path.join(chosen_conf_templates_dir, conf_template_name)
            conf_template_dict = io_util.read_xml_2_dict(conf_file_path)
            conf_list = resource_conf_dict.get(conf_template_name)
            conf_verf = verification.add_sub_verification(
                "Check conf {}".format(conf_template_name), assert_result=conf_list is not None,
                description="configurations of {} not found".format(conf_template_name))
            if conf_list is None:
                continue
            conf_dict = dict(map(lambda x: [x[0], x[1]], conf_list))
            diff_conf_items, lost_conf_items = self.__compare_conf_dict(conf_template_dict, conf_dict)
            diff_verf = conf_verf.add_sub_verification("No different configurations",
                                                       assert_result=len(diff_conf_items) == 0)
            if len(diff_conf_items) > 0:
                diff_verf.add_output("Different configurations", diff_conf_items)
            lost_verf = conf_verf.add_sub_verification("No lost configurations",
                                                       assert_result=len(lost_conf_items) == 0)
            if len(lost_conf_items) > 0:
                lost_verf.add_output("Lost configurations", lost_conf_items)
        verification.refresh_status(recursively=True)

    def __compare_conf_dict(self, conf_template_dict, conf_dict):
        diff_rst, lost_rst = {}, {}
        for (name, stand_value) in conf_template_dict.items():
            if name in conf_dict:
                value = conf_dict.get(name)
                if value != stand_value:
                    diff_rst[name] = (value, stand_value)
            else:
                if stand_value != "":
                    lost_rst[name] = stand_value
        return diff_rst, lost_rst


class AppsScheduleCheckOption(CheckOption):

    def __init__(self, key, context, from_time, to_time, query=None, size=10000, schedule_seconds_ratio=0.5,
                 schedule_waste_containers_ratio=0.1, num_released_containers_threshold=1000):
        super().__init__(key, context)
        self.from_time = from_time
        self.to_time = to_time
        self.from_time = from_time
        self.query = query
        self.size = size
        self.schedule_seconds_ratio = schedule_seconds_ratio
        self.schedule_waste_containers_ratio = schedule_waste_containers_ratio
        self.num_released_containers_threshold = num_released_containers_threshold

    def check(self, verification):
        sls_client_cache = get_required_cache(self.context, CACHE_KEY_SLS_CLIENT)
        rm_log_source = self.context.get_env_value(ENV_KEY_RM_LOG_SOURCE)
        log_domain = self.context.get_env_value(ENV_KEY_DOMAIN)
        topic = self.context.get_cluster_id()
        logs = sls_client_cache.get_data(rm_log_source, self.from_time, self.to_time, log_domain, None,
                                         None, topic, self.query, 0, self.size, False)
        if len(logs) == 0:
            verification.add_output("SKIPPED", "no logs found in SLS store, from_time={}, to_time={}".format(
                self.from_time, self.to_time))
            return verification
        log_analyzer = get_required_analyzer(self.context, ANALYZER_KEY_YARN_RM_SLS_LOG)
        log_analyzer.process(logs)

        first_time_tuple = self.get_timestamp_and_time(logs[0])
        last_time_tuple = self.get_timestamp_and_time(logs[-1])
        schedule_seconds = last_time_tuple[0] - first_time_tuple[0]
        app_statistic_infos = log_analyzer.get_app_statistic_infos()
        logging.info("found {} scheduled apps for AppsScheduleCheckOption in {} seconds between {} and {}".format(
            len(app_statistic_infos), schedule_seconds, first_time_tuple[1], last_time_tuple[1]))
        normal_apps, suspicious_apps = list(), list()
        for app_statistic_info in app_statistic_infos:
            app_id = app_statistic_info.get(ID_KEY)
            aggregated_num_allocated_containers = app_statistic_info.get(
                SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_ALLOCATED)
            aggregated_num_released_containers = app_statistic_info.get(
                SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_RELEASED)
            max_num_allocated_containers = app_statistic_info.get(SCHEDULE_STATISTIC_KEY_MAX_NUM_ALLOCATED)
            app_schedule_seconds = app_statistic_info.get(SCHEDULE_STATISTIC_KEY_SCHEDULE_SECONDS)
            waste_ratio = aggregated_num_allocated_containers / max_num_allocated_containers \
                if max_num_allocated_containers != 0 else 0
            if (app_schedule_seconds > schedule_seconds * self.schedule_seconds_ratio and\
                    waste_ratio > self.schedule_waste_containers_ratio) or aggregated_num_released_containers\
                    >= self.num_released_containers_threshold:
                suspicious_apps.append((app_id, app_statistic_info))
            else:
                normal_apps.append((app_id, app_statistic_info))
        # add output: QPS statistics
        qps_in_minutes = log_analyzer.get_allocate_qps_in_minutes()
        verification.add_output("Allocate QPS in {} minutes".format(len(qps_in_minutes)), qps_in_minutes)
        # add verification: suspicious applications
        sub_verf = verification.add_sub_verification("Number of suspicious applications == 0",
                                                     assert_result=len(suspicious_apps) == 0)
        for app in suspicious_apps:
            sub_verf.add_output('suspicious app: {}'.format(app[0]), app[1])
        for app in normal_apps:
            logging.debug('normal app {}: {}'.format(app[0], app[1]))
        verification.refresh_status(recursively=True)

    def get_timestamp_and_time(self, log):
        return log.get_time(), log.get_contents().get('time')


class LogIssuesCheckOption(CheckOption):

    def __init__(self, key, context):
        super().__init__(key, context)

    def check(self, verification):
        log_issues_hunter = self.context.get_analyzer(ANALYZER_KEY_YARN_LOG_ISSUES_HUNTER)
        issues, checklist = log_issues_hunter.hunt()
        verification.add_output("checklist (size={}): {}".format(len(checklist), checklist))
        for issue_name, issue_output in issues.items():
            verification.add_sub_verification(id=issue_name, description=issue_output,
                                              status=CHECKER_VERIFICATION_STATUS_FAILED)
        if len(issues) > 0:
            verification.refresh_status(recursively=True)
        else:
            verification.succeeded()


class HealthReportCheckOption(CheckOption):

    def check(self, verification):
        cache = get_required_cache(self.context, CACHE_KEY_YARN_HEALTH_REPORT)
        components = cache.get_data()
        if components is None or len(components) == 0:
            verification.add_output("SKIPPED", "health report not found")
            return verification
        components = components.values()
        unhealthy_components = list(filter(lambda n: not n.is_healthy(), components))
        verification.add_sub_verification("Number of UNHEALTHY components <= 0 (actual={})".format(
            len(unhealthy_components)), assert_result=len(unhealthy_components) == 0,
            description=list(unhealthy_components))
        busy_components = list(filter(lambda n: n.get_work_state() == 'BUSY', components))
        verification.add_sub_verification("Number of BUSY components <= 0 (actual={})".format(
            len(unhealthy_components)), assert_result=len(busy_components) == 0,
            description=list(busy_components))
