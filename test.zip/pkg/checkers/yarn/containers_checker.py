from pkg.checkers.generic import *
import os
from pkg.caches.common import parse_log_content


class ContainersChecker(Checker):

    def __init__(self, key, context, rm_query, nm_query, container_query):
        super().__init__(key, context)
        self.__rm_query = rm_query
        self.__nm_query = nm_query
        self.__container_query = container_query

    def check(self, container_ids, from_time='24 hours ago', to_time='now'):
        # load env
        local_conf_cache = self.context.get_cache(CACHE_KEY_CLUSTER_LOCAL_CONF)
        local_conf_cache.load()
        # check env variables
        rm_log_source = self.context.get_env_value(ENV_KEY_RM_LOG_SOURCE)
        nm_log_source = self.context.get_env_value(ENV_KEY_NM_LOG_SOURCE)
        container_log_source = self.context.get_env_value(ENV_KEY_CONTAINER_LOG_SOURCE)
        log_domain = self.context.get_env_value(ENV_KEY_DOMAIN)
        sls_client = self.context.get_cache(CACHE_KEY_SLS_CLIENT)
        verification = Verification(CHECKER_KEY_YARN_CONTAINERS)
        for cid in container_ids:
            container_verf = verification.add_sub_verification(cid)
            rm_logs = sls_client.get_data(rm_log_source, from_time, to_time, log_domain, topic=None, query=cid)
            if rm_logs is None:
                msg = "no logs found in RM log! from_time={}, to_time={}".format(from_time, to_time)
                logging.info("skip analyzing container info for container {} since {}".format(cid, msg))
                container_verf.add_output("skip analyzing container info", msg)
                continue
            # init cache dir for this container
            cache_dir = self.context.get_cache_dir()
            rm_query = self.__rm_query.format(cid)
            container_cache_dir = os.path.join(cache_dir, CHECKER_KEY_YARN_CONTAINERS, rm_query)
            if not os.path.exists(container_cache_dir):
                os.makedirs(container_cache_dir)
            # download and analyze rm logs
            rm_log_file = os.path.join(container_cache_dir, 'rm.log')
            self.download_log(rm_log_file, rm_logs)
            rm_analyzer = self.context.get_analyzer(ANALYZER_KEY_YARN_RM_LOG)
            rm_analyzer.process(rm_log_file)
            container_info = rm_analyzer.get_container_info(cid)
            if container_info is not None:
                container_verf.add_output("container info", container_info.get_data())
            # download and analyze nm logs
            nm_query = self.__nm_query.format(cid)
            nm_logs = sls_client.get_data(nm_log_source, from_time, to_time, log_domain, topic=None, query=nm_query)
            if nm_logs is None:
                msg = "no logs found! from_time={}, to_time={}".format(from_time, to_time)
                logging.info("skip analyzing container runtime info for container {} since {}".format(cid, msg))
                container_verf.add_output("skip analyzing container runtime info", msg)
                continue
            nm_log_file = os.path.join(container_cache_dir, 'nm.log')
            self.download_log(nm_log_file, nm_logs)
            nm_analyzer = self.context.get_analyzer(ANALYZER_KEY_YARN_NM_LOG)
            nm_analyzer.process(nm_log_file)
            container_rt_infos = nm_analyzer.get_container_infos([cid])
            if len(container_rt_infos) == 1:
                container_verf.add_output("container runtime info", container_rt_infos[0])
            container_verf.succeeded()
            # download and analyze container logs
            if container_log_source is None:
                msg = "no log source defined!"
                logging.info("skip analyzing container log for container {} since {}".format(cid, msg))
                container_verf.add_output("skip analyzing container logs", msg)
                continue
            # query example: __tag__:__path__: "container_1623210299043_866108_01_000001"
            container_query = self.__nm_query.format(cid)
            container_logs = sls_client.get_data(nm_log_source, from_time, to_time, log_domain, topic=None,
                                                 query=container_query)
            if container_logs is None:
                msg = "no logs found! from_time={}, to_time={}".format(from_time, to_time)
                logging.info("skip analyzing container log for container {} since {}".format(cid, msg))
                container_verf.add_output("skip analyzing container log", msg)
                continue
            container_log_file = os.path.join(container_cache_dir, 'container.log')
            self.download_log(container_log_file, container_logs)
        verification.refresh_status(recursively=True)
        return verification

    def download_log(self, rm_log_file, logs):
        with open(rm_log_file, 'w') as file:
            for log in logs:
                content = parse_log_content(log)
                if content is None:
                    continue
                file.write(content+'\n')
