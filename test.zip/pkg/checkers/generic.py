import logging

from pkg.framework.check import *
from pkg.framework.error import *
from pkg.utils import common_util

CONF_KEY_SUB_OPTIONS = 'sub_options'
ROOT_KEY = 'root'


class CheckOption(metaclass=ABCMeta):

    def __init__(self, key, context):
        self.key = key
        self.context = context

    def get_key(self):
        return self.key

    @abstractmethod
    def check(self, verification, *args): pass


class CheckOptionsConf:

    def __init__(self, check_options_conf):
        self.root_option = CheckOptionConf(ROOT_KEY, {CONF_KEY_SUB_OPTIONS: check_options_conf})


class CheckOptionConf:

    def __init__(self, key, option_conf):
        self.__key = key
        self.__description = option_conf.get(CONF_KEY_DESCRIPTION)
        self.__opt_class = option_conf.get(CONF_KEY_CLASS)
        self.__init_args = option_conf.get(CONF_KEY_INIT_ARGS)
        sub_options_conf = option_conf.get(CONF_KEY_SUB_OPTIONS)
        if self.__opt_class is None and sub_options_conf is None:
            raise ConfError("either {} or {} should be configured for check option {}".format(
                CONF_KEY_CLASS, CONF_KEY_SUB_OPTIONS, key))
        if self.__opt_class is not None and sub_options_conf is not None:
            raise ConfError("{} and {} should not be configured together for check option {}".format(
                CONF_KEY_CLASS, CONF_KEY_SUB_OPTIONS, key))
        self.__sub_options = list()
        if sub_options_conf is not None:
            for key, sub_option_conf in sub_options_conf.items():
                sub_option = CheckOptionConf(key, sub_option_conf)
                self.__sub_options.append(sub_option)

    def get_key(self):
        return self.__key

    def get_description(self):
        return self.__description

    def get_class(self):
        return self.__opt_class

    def get_init_args(self):
        return self.__init_args

    def get_sub_options(self):
        return self.__sub_options

    def is_group(self):
        return len(self.__sub_options) > 0


class GenericChecker(Checker):

    def __init__(self, key, context, check_options):
        super().__init__(key, context)
        self.__root_option_conf = CheckOptionConf(key, {CONF_KEY_SUB_OPTIONS: check_options})

    def check(self, *args):
        logging.info("start check process by {}".format(self.key))
        root_verification = Verification(self.__root_option_conf.get_key(), self.__root_option_conf.get_description())
        self.__check_option(root_verification, self.__root_option_conf, args)
        return root_verification

    def __check_option(self, verf, option_conf, args):
        logging.info("{}|- check {} ...".format('    ' * verf.get_deep(), verf.get_id()))
        if option_conf.is_group():
            for sub_option in option_conf.get_sub_options():
                sub_verf = verf.add_sub_verification(sub_option.get_key(), sub_option.get_description())
                self.__check_option(sub_verf, sub_option, args)
            verf.refresh_status()
        else:
            init_args_dict = {CONF_KEY_KEY: self.key, CONF_KEY_CONTEXT: self.context}
            if option_conf.get_init_args() is not None:
                init_args_dict.update(option_conf.get_init_args())
            constructor_fn = common_util.reflect_fn(option_conf.get_class())
            check_option = constructor_fn(**init_args_dict)
            check_option.check(verf, *args)
