from pkg.caches.yarn.common import *
from pkg.checkers.generic import *


class FlinkJobChecker(Checker):

    def __init__(self, key, context, event_queries=None, flink_log_queries=None, from_time=None, to_time=None, size=None):
        super().__init__(key, context)
        self.__event_queries = event_queries
        self.__flink_log_queries = flink_log_queries
        self.__from_time = from_time
        self.__to_time = to_time
        self.__size = size

    def check(self, job_id, from_time=None, to_time=None, size=None):
        cluster_local_conf_cache = get_required_cache(self.context, CACHE_KEY_CLUSTER_LOCAL_CONF)
        cluster_local_conf_cache.load()
        verification = Verification(CHECKER_KEY_ASI_FLINK_JOB)
        # check events of pods
        asi_event_log_analyzer = get_required_analyzer(self.context, ANALYZER_KEY_ASI_EVENT_LOG)
        from_time = from_time if from_time else self.__from_time
        to_time = to_time if to_time else self.__to_time
        size = size if size else self.__size
        if self.__event_queries:
            origin_params = {NAME_KEY: job_id, FROM_TIME_KEY: from_time, TO_TIME_KEY: to_time, SIZE_KEY: size}
            for key, query_params in self.__event_queries.items():
                params = {**origin_params, **query_params}
                events_verf = verification.add_sub_verification(
                    'Check events: {}, params: {}'.format(key, query_params))
                event_infos = asi_event_log_analyzer.get_event_infos(**params)
                if not event_infos:
                    events_verf.add_output('None')
                    events_verf.succeeded()
                else:
                    for key, event_info in event_infos.items():
                        events_verf.add_output('{}'.format(key), event_info.get(EVENTS_KEY))
                        events_verf.failed()
        else:
            events_verf = verification.add_sub_verification('Skip checking event since event keywords not configured')
            events_verf.succeeded()
        # check flink log
        asi_flink_log_analyzer = get_required_analyzer(self.context, ANALYZER_KEY_ASI_FLINK_LOG)
        if self.__flink_log_queries:
            origin_params = {"job_id": job_id, FROM_TIME_KEY: from_time, TO_TIME_KEY: to_time, SIZE_KEY: size}
            for key, query_params in self.__flink_log_queries.items():
                params = {**origin_params, **query_params}
                job_verf = verification.add_sub_verification(
                    'Check flink log: {}, params: {}'.format(key, query_params))
                print("======>",params)
                job_infos = asi_flink_log_analyzer.get_data(**params)
                if not job_infos:
                    job_verf.add_output('None')
                    job_verf.succeeded()
                else:
                    for key, job_info in job_infos.items():
                        for childKey, child in job_info.get(CHILDREN_KEY).items():
                            component_verf = job_verf.add_sub_verification('{}-{}'.format(key, childKey))
                            component_verf.add_output("logs", child)
                            component_verf.failed()
        else:
            job_verf = verification.add_sub_verification(
                'Skip checking flink logs since event keywords not configured')
            job_verf.succeeded()
        verification.refresh_status(recursively=True)
        return verification
