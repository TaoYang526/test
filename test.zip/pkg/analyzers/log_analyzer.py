import logging
from abc import ABCMeta, abstractmethod
from pkg.utils import common_util
from pkg.framework.error import *
import re
import os
from pkg.constants import *


class LogInfo:

    def __init__(self, timestamp, log_level, source, content, info_dict=None):
        self.timestamp = timestamp
        self.log_level = log_level
        self.source = source
        self.content = content
        self.info_dict = info_dict


class LogParser(metaclass=ABCMeta):

    @abstractmethod
    def load(self, log_file): pass

    @abstractmethod
    def close(self): pass

    # return None when reaching the end of file
    @abstractmethod
    def parse_line(self): pass

    @abstractmethod
    def parse(self, line): pass


class LogProcessor(metaclass=ABCMeta):

    @abstractmethod
    def clear(self): pass

    @abstractmethod
    def process(self, log_info): pass

    @abstractmethod
    def persist(self): pass

    @abstractmethod
    def recover(self): pass


class CommonLogParser(LogParser):

    def __init__(self, context, log_pattern, date_time_format, date_time_index, log_level_index, source_index,
                 content_start_index, date_time_convert_eval=None):
        self.__context = context
        self.__log_pattern = log_pattern
        self.__date_time_index = date_time_index
        self.__date_time_format = date_time_format
        self.__log_level_index = log_level_index
        self.__source_index = source_index
        self.__content_start_index = content_start_index
        self.__log_file = None
        self.__last_line = None
        self.__date_time_convert_eval = date_time_convert_eval

    def __get_log_pattern(self):
        return self.__context.get_env_decoded_str(self.__log_pattern)

    def load(self, log_file):
        if not os.path.exists(log_file):
            raise ArgumentsError(f"log file {log_file} not found!")
        if not os.path.isfile(log_file):
            raise ArgumentsError(f"{log_file} is not a file!")
        self.__log_file = open(log_file, 'r')
        self.__last_line = None

    def close(self):
        if self.__log_file:
            self.__log_file.close()

    def read_line(self):
        lines = list()
        cur_line = self.__log_file.readline() if self.__last_line is None else self.__last_line
        if len(cur_line) == 0:
            return None
        while True:
            if cur_line:
                match = re.search(self.__get_log_pattern(), cur_line)
                if match is None:
                    # drop this line if no valid line yet
                    if len(lines) == 0:
                        logging.debug("drop line ({}) since not match specified log format".format(cur_line.strip()))
                        cur_line = self.__log_file.readline()
                        continue
                    else:
                        lines.append(cur_line)
                else:
                    date_time = match.group(self.__date_time_index)
                    if self.__date_time_convert_eval:
                        date_time = eval(self.__date_time_convert_eval)
                    timestamp = common_util.parse_timestamp(date_time, self.__date_time_format)
                    if len(lines) > 0 and timestamp:
                        break
                    else:
                        lines.append(cur_line)
            cur_line = self.__log_file.readline()
            self.__last_line = cur_line
            if len(cur_line) == 0:
                break
        return None if len(lines) == 0 else ''.join(lines).strip()

    def parse_line(self):
        line = self.read_line()
        if line is None:
            return None
        return self.parse(line)

    def parse(self, line):
        match = re.search(self.__get_log_pattern(), line)
        if match is None or match.lastindex < max(
                [self.__date_time_index, self.__log_level_index, self.__source_index, self.__content_start_index]):
            logging.debug(
                "return None with pattern ({}) after got the last line: {}".format(self.__get_log_pattern(), line))
            return None
        date_time = match.group(self.__date_time_index)
        if self.__date_time_convert_eval:
            date_time = eval(self.__date_time_convert_eval)
        timestamp = common_util.parse_timestamp(date_time, self.__date_time_format)
        content = match.group(self.__content_start_index)
        log_level = match.group(self.__log_level_index)
        source = match.group(self.__source_index)
        loginfo = LogInfo(timestamp, log_level, source, content)
        return loginfo


class SLSLogParser(CommonLogParser):

    def __init__(self, context, log_pattern, date_time_format, date_time_index, log_level_index, source_index,
                 content_start_index):
        super().__init__(context, log_pattern, date_time_format, date_time_index, log_level_index, source_index,
                         content_start_index)
        self.__logs = None
        self.__index = 0

    def load(self, sls_logs):
        self.__logs = sls_logs

    def close(self):
        pass

    def read_line(self):
        if self.__index >= len(self.__logs):
            return None
        log = self.__logs[self.__index]
        self.__index += 1
        time = log.get_contents().get('time') if log.get_contents().get('time') is not None else ''
        return time + log.get_contents().get('content')

    def parse_line(self):
        return super().parse_line()

    def parse(self, line):
        return super().parse(line)


class SLSKVLogParser:

    def __init__(self, context, date_time_format, date_time_index_name, fields_mapping):
        self.__context = context
        self.__logs = None
        self.__index = 0
        self.__date_time_format = date_time_format
        self.__date_time_index_name = date_time_index_name
        self.__fields_mapping = fields_mapping

    def load(self, sls_logs):
        self.__logs = sls_logs

    def close(self):
        pass

    def read_line(self):
        if self.__index >= len(self.__logs):
            return None
        log = self.__logs[self.__index]
        self.__index += 1
        return log.get_contents()

    def parse_line(self):
        line = self.read_line()
        if line is None:
            return None
        return self.parse(line)

    def parse(self, line_dict):
        timestamp_s = line_dict.get(self.__date_time_index_name)
        if not timestamp_s:
            logging.warning("skip parsing log without timestamp field (index_name={}): {}".format(
                self.__date_time_index_name, line_dict))
            return {}
        timestamp_s = timestamp_s.strip()
        timestamp = common_util.parse_timestamp(timestamp_s, self.__date_time_format)
        log_info = {TIMESTAMP_KEY: timestamp, TIMESTAMP_S_KEY: timestamp_s}
        for (key, value) in self.__fields_mapping.items():
            log_info[key] = line_dict.get(value)
        return log_info


class CommonLogAnalyzer:

    def __init__(self, log_parser, log_processors):
        self.__log_parser = log_parser
        self.__log_processors = log_processors

    def clear(self):
        if self.__log_processors:
            for processor in self.__log_processors:
                processor.clear()

    def process(self, log_file_or_logs, from_timestamp=None, to_timestamp=None):
        if isinstance(log_file_or_logs, str):
            logging.debug("start processing log file {}".format(log_file_or_logs))
        else:
            logging.debug("start processing sls logs, number-of-logs={}".format(len(log_file_or_logs)))
        try:
            timer = common_util.get_timer()
            self.__log_parser.load(log_file_or_logs)
            processed_count = 0
            spb = common_util.SimpleProgressBar("Loaded lines", step=10000)
            while True:
                log_info = self.__log_parser.parse_line()
                if log_info is None:
                    break
                if from_timestamp is not None and log_info.timestamp < from_timestamp:
                    continue
                if to_timestamp is not None and log_info.timestamp > to_timestamp:
                    break
                for processor in self.__log_processors:
                    processor.process(log_info)
                processed_count += 1
                if processed_count % 1000 == 0:
                    spb.update(processed_count)
            spb.update(processed_count)
            spb.close()
            logging.debug("processed {} valid messages, timestamp_range=<{},{}>, elapse time: {} ms"
                          .format(processed_count, from_timestamp, to_timestamp, timer.get_elapse_ms()))
        finally:
            self.__log_parser.close()
        return processed_count

    def persist(self):
        timer = common_util.get_timer()
        for processor in self.__log_processors:
            processor.persist()
        logging.debug("persisted cache for {} in {} ms".format(self.__class__.__name__, timer.get_elapse_ms()))

    def recover(self):
        timer = common_util.get_timer()
        for processor in self.__log_processors:
            processor.recover()
        logging.debug("recovered {} in {} ms".format(self.__class__.__name__, timer.get_elapse_ms()))
