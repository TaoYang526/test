import json
from pkg.utils import common_util
from pkg.constants import *
from pkg.framework.error import *
from statistics import mean

NAME_KEY = 'name'
VALUE_KEY = 'value'
BEAN_PREFIX_KEY = 'bean_prefix'
CONDITION_KEY = 'condition'
MESSAGE_KEY = 'message'


class OriginMetricsInfo:

    # metrics structure: dict<bean_name, bean_metrics>
    # bean_metrics structure: dict<metric_name, metric_value>
    def __init__(self, timestamp, origin_jmx_beans):
        self.__timestamp = timestamp
        self.__bean_dict = origin_jmx_beans
        # for origin_jmx_bean in origin_jmx_beans:
        #     bean_name = origin_jmx_bean.get(BEAN_NAME_KEY)
        #     if bean_name is None:
        #         raise RuntimeError("unexpected origin jmx bean without name: {}".format(origin_jmx_bean))
        #     self.__bean_dict[bean_name] = origin_jmx_bean

    def get_timestamp(self):
        return self.__timestamp

    def get_bean(self, bean_name):
        return self.__bean_dict.get(bean_name)

    def get_beans(self, bean_prefix):
        if bean_prefix is None:
            return self.__bean_dict
        return dict(filter(lambda elem: elem[0].startswith(bean_prefix), self.__bean_dict.items()))

    def get_metric_value(self, bean_name, metric_name):
        bean = self.get_bean(bean_name)
        if bean is None:
            return None
        return bean.get(metric_name)


class DiagnoseInfo:

    def __init__(self, id, is_healthy, message, info):
        self.id = id
        self.is_healthy = is_healthy
        self.message = message if message is not None else ''
        self.info = info

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return json.dumps(self.__dict__)

    def get_data(self):
        return self.__dict__


class DiagnoseReport:

    def __init__(self):
        self.__healthy_diagnostics = list()
        self.__unhealthy_diagnostics = list()
        self.__metrics_info = None

    def add_diagnose_info(self, id, is_healthy, message, info_dict):
        diagnostics = self.__healthy_diagnostics if is_healthy else self.__unhealthy_diagnostics
        diagnostics.append(DiagnoseInfo(id, is_healthy, message, info_dict))

    def set_metrics_info(self, metrics_info):
        self.__metrics_info = metrics_info

    def get_metrics_info(self):
        return self.__metrics_info

    def is_healthy(self):
        return len(self.__unhealthy_diagnostics) == 0

    def get_unhealthy_diagnostics(self):
        return self.__unhealthy_diagnostics

    def get_healthy_diagnostics(self):
        return self.__healthy_diagnostics

    def get_all_diagnostics(self):
        return self.__unhealthy_diagnostics + self.__healthy_diagnostics


class MetricsInfo:

    def __init__(self):
        self.__data = dict()

    def add(self, bean_name, metric_name, agg_type, timestamp, metric_value):
        bean_metrics = common_util.get_or_new_value(self.__data, bean_name, dict)
        metric_info = common_util.get_or_new_value(
            bean_metrics, metric_name, (MetricInfo, metric_name, agg_type))
        metric_info.add(timestamp, metric_value)

    def get_metrics(self, bean_name_or_prefix=None):
        if bean_name_or_prefix is None:
            return self.__data
        return dict(filter(lambda elem: elem[0].startswith(bean_name_or_prefix), self.__data.items()))

    def get_metric_value(self, bean_name, metric_name):
        bean = self.__data.get(bean_name)
        if bean is None:
            return None
        metric_info = bean.get(metric_name)
        if metric_info is None:
            return None
        return metric_info.get_value()

    # return metrics data
    # format: map[bean_name: dict[metric_key: metric_value]]
    def get_metrics_data(self):
        rst = dict()
        for bean_name, bean_metrics in self.__data.items():
            bean_data = dict()
            rst[bean_name] = bean_data
            for metric_key, metric_info in bean_metrics.items():
                bean_data[metric_key] = metric_info.get_value()
        return rst


class MetricInfo:

    def __init__(self, name, agg_type):
        self.__name = name
        self.__agg_type = METRIC_AGG_TYPE_MAPPING.get(agg_type)
        if self.__agg_type is None:
            raise ConfError("unexpected agg_type {} for metric {}, valid types: {}".format(
                agg_type, name, METRIC_AGG_TYPE_MAPPING.keys()))
        self.__timestamps = list()
        self.__values = list()

    def add(self, timestamp, value):
        self.__timestamps.append(timestamp)
        self.__values.append(value)

    def get_name(self):
        return self.__name

    def get_value(self):
        if len(self.__values) == 0:
            return None
        if self.__agg_type == METRIC_AGG_TYPE_LAST:
            return self.__values[-1]
        elif self.__agg_type == METRIC_AGG_TYPE_MEAN:
            return mean(self.__values)
        elif self.__agg_type == METRIC_AGG_TYPE_QPS:
            if len(self.__values) >= 2:
                interval = self.__timestamps[-1] - self.__timestamps[0]
                delta = self.__values[-1] - self.__values[0]
                return round(delta/interval, 1)
            return 0
        elif self.__agg_type == METRIC_AGG_TYPE_MAX:
            return max(self.__values)
        elif self.__agg_type == METRIC_AGG_TYPE_MIN:
            return min(self.__values)

    def get_values(self):
        return self.__values

    def get_timestamps(self):
        return self.__timestamps

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return json.dumps(
            {NAME_KEY: self.__name, MONITOR_CONF_KEY_AGG_TYPE: self.__agg_type, VALUE_KEY: self.get_value()})
