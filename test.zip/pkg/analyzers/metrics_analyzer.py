from abc import ABCMeta, abstractmethod
import time
import logging
from pkg.analyzers.metrics_info import *
from pkg.framework.error import *


class MetricsCollector(metaclass=ABCMeta):

    # return metrics info
    @abstractmethod
    def collect(self): pass


class MetricsProcessor(metaclass=ABCMeta):

    @abstractmethod
    def process(self, origin_metrics_info, metrics_info): pass


class MetricsChecker(metaclass=ABCMeta):

    @abstractmethod
    def diagnose(self, metrics): pass


class MetricsAnalyzer(metaclass=ABCMeta):

    def __init__(self, collector, processors, checker):
        self.__collector = collector
        self.__processors = processors
        self.__checker = checker
        self.__metrics_info = MetricsInfo()

    # Visible for testing
    def set_collector(self, collector):
        self.__collector = collector

    def process(self):
        origin_metrics_info = OriginMetricsInfo(time.time(), self.__collector.collect())
        for processor in self.__processors:
            processor.process(origin_metrics_info, self.__metrics_info)
        return self.__checker.diagnose(self.__metrics_info)

    def process_periodically(self, interval_s, max_wait_s, callback_fn=None):
        timer = common_util.get_timer()
        while True:
            report = self.process()
            if callback_fn is not None:
                callback_fn(report)
            remaining_s = round(max_wait_s - timer.get_elapse_s(), 3)
            if remaining_s <= 0:
                return report
            sleep_s = interval_s if interval_s < remaining_s else remaining_s
            logging.debug("sleep {} seconds for this round, remaining_s={}, interval_s={}".format(sleep_s, remaining_s,
                                                                                                  interval_s))
            time.sleep(sleep_s)
        return None

    # Visible for testing
    def update_collector(self, collector):
        self.__collector = collector


class CommonMetricsProcessor(MetricsProcessor):

    # monitor_metrics_conf structure: map[bean_name_or_prefix, monitor_metric_conf]
    # monitor_metric_conf structure: {'type':'realtime|counter', 'agg_type': 'mean|min|max|last|qps',
    #                                 'abnormal_condition': '<compare_expression: x represents the metric value>'}
    def __init__(self, monitor_metrics_conf):
        self.__monitor_metrics_conf = monitor_metrics_conf

    def process(self, origin_metrics_info, metrics_info):
        timestamp = origin_metrics_info.get_timestamp()
        # init chosen bean metrics and their monitor conf
        monitor_bean_list = list()
        for bean_prefix, monitor_conf in self.__monitor_metrics_conf.items():
            filtered_beans = origin_metrics_info.get_beans(bean_prefix)
            if len(filtered_beans) > 0:
                monitor_bean_list.extend(map(lambda elem: (elem[1], monitor_conf), filtered_beans.items()))
        if len(monitor_bean_list) == 0:
            logging.debug("bean starts with {} not found".format(bean_prefix))

        # process metrics
        for bean, monitor_bean_conf in monitor_bean_list:
            bean_name = bean.get(BEAN_NAME_KEY)
            for metric_name, conf in monitor_bean_conf.items():
                metric_value = bean.get(metric_name)
                if metric_value is None:
                    continue
                metrics_info.add(bean_name, metric_name, conf.get(MONITOR_CONF_KEY_AGG_TYPE), timestamp, metric_value)


class CommonMetricsChecker(MetricsChecker):

    def __init__(self, diagnoses_conf):
        self.__diagnoses_conf = diagnoses_conf

    def diagnose(self, metrics_info):
        diagnose_report = DiagnoseReport()
        diagnose_report.set_metrics_info(metrics_info)
        for diagnose_id, diagnose_conf in self.__diagnoses_conf.items():
            bean_name_or_prefix = diagnose_conf.get(BEAN_PREFIX_KEY)
            if bean_name_or_prefix is None:
                raise ConfError('bean_prefix field is required for the diagnoses configuration of metrics checker')
            filtered_metrics = metrics_info.get_metrics(bean_name_or_prefix)
            for bean_name, bean_monitor_metrics in filtered_metrics.items():
                bean_monitor_metric_values = dict(
                    map(lambda elem: [elem[0], elem[1].get_value()], bean_monitor_metrics.items()))
                is_healthy = not self.__check_condition(diagnose_conf, bean_monitor_metric_values)
                unhealthy_message = None if is_healthy else diagnose_conf.get(MESSAGE_KEY)
                new_diagnose_id = diagnose_id if len(filtered_metrics) == 1 \
                    else "{}({})".format(diagnose_id, bean_name.replace(bean_name_or_prefix, ''))
                diagnose_report.add_diagnose_info(new_diagnose_id, is_healthy, unhealthy_message,
                                                  {"metrics": bean_monitor_metric_values})
        return diagnose_report

    def __check_condition(self, diagnose_conf, bean_monitor_metric_values):
        condition = diagnose_conf.get(CONDITION_KEY)
        for metric_name, metric_value in bean_monitor_metric_values.items():
            exec('{} = {}'.format(metric_name, metric_value))
        return eval(condition)
