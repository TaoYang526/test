from pkg.utils import common_util
from pkg.constants import *
from collections import OrderedDict
import logging
import json
from statistics import mean, median


class ContainerBasicInfo:

    def __init__(self, container_id, node_id, resource, diagnostic=None, data=None):
        if data is not None:
            self.__data = data
        else:
            self.__data = {
                CONTAINER_ID_KEY: container_id,
                NODE_ID_KEY: node_id,
                RESOURCE_KEY: resource,
                DIAGNOSTIC_KEY: diagnostic
            }

    def update_item(self, key, value):
        self.__data[key] = value

    def get_item(self, key):
        return self.__data[key]

    def get_container_id(self):
        return self.__data[CONTAINER_ID_KEY]

    def get_node_id(self):
        return self.__data[NODE_ID_KEY]

    def set_node_id(self, node_id):
        self.__data[NODE_ID_KEY] = node_id

    def get_resource(self):
        return self.__data[RESOURCE_KEY]

    def set_resource(self, resource):
        self.__data[RESOURCE_KEY] = resource

    def get_diagnostic(self):
        return self.__data[DIAGNOSTIC_KEY]

    def set_diagnostic(self, diagnostic):
        self.__data[DIAGNOSTIC_KEY] = diagnostic

    def get_data(self):
        return self.__data


class ContainerEvent(ContainerBasicInfo):

    def __init__(self, timestamp, event_type, container_id, node_id, resource, diagnostic=None, data=None):
        if data is not None:
            super().__init__(None, None, None, data=data)
            return
        super().__init__(container_id, node_id, resource, diagnostic=diagnostic)
        self.update_item(TIMESTAMP_KEY, timestamp)
        self.update_item(EVENT_TYPE_KEY, event_type)

    def get_timestamp(self):
        return self.get_item(TIMESTAMP_KEY)

    def get_event_type(self):
        return self.get_item(EVENT_TYPE_KEY)


class ContainerScheduleInfo(ContainerBasicInfo):

    def __init__(self, start_timestamp, container_id, node_id, resource, num_containers_snapshot):
        super().__init__(container_id, node_id, resource)
        self.update_item(START_TIMESTAMP_KEY, start_timestamp)
        self.update_item(FINISH_TIMESTAMP_KEY, -1)
        self.update_item(NUM_CONTAINERS_SNAPSHOT_KEY, num_containers_snapshot)
        self.update_item(HOLD_SECONDS_KEY, -1)

    def set_finish_timestamp(self, finish_timestamp):
        self.update_item(FINISH_TIMESTAMP_KEY, finish_timestamp)
        self.update_item(HOLD_SECONDS_KEY, finish_timestamp - self.get_start_timestamp())

    def get_start_timestamp(self):
        return self.get_item(START_TIMESTAMP_KEY)

    def get_hold_seconds(self):
        return self.get_item(HOLD_SECONDS_KEY)


class AppScheduleInfo:

    def __init__(self, id):
        self.__id = id
        self.__num_containers_snapshot = 0
        self.__max_num_containers = 0
        self.__released_num_containers = 0
        self.__container_infos = OrderedDict()

    def process_container_event(self, container_event):
        container_id = container_event.get_container_id()
        event_type = container_event.get_event_type()
        self.__num_containers_snapshot += event_type
        container_info = None
        if event_type == 1:
            if container_id in self.__container_infos:
                logging.warning("allocate container {} which is already allocated before".format(container_id))
                return None
            container_info = ContainerScheduleInfo(container_event.get_timestamp(), container_id,
                                                   container_event.get_node_id(),
                                                   container_event.get_resource(),
                                                   self.__num_containers_snapshot)
            self.__container_infos[container_id] = container_info
            if self.__max_num_containers < self.__num_containers_snapshot:
                self.__max_num_containers = self.__num_containers_snapshot
        elif event_type == -1:
            self.__released_num_containers += 1
            container_info = self.__container_infos.get(container_id)
            if container_info is not None:
                container_info.set_finish_timestamp(container_event.get_timestamp())
                container_info.set_diagnostic(container_event.get_diagnostic())
        return container_info

    def get_statistic_info(self):
        # statistic for completed containers
        first_schedule_ts, last_schedule_ts = -1, -1
        if len(self.__container_infos) > 0:
            first_schedule_ts = next(iter(self.__container_infos.values())).get_start_timestamp()
            last_schedule_ts = next(reversed(self.__container_infos.values())).get_start_timestamp()

        container_running_seconds = list(map(lambda x: x.get_hold_seconds(), self.__container_infos.values()))
        container_running_seconds = list(filter(lambda x: x != -1, container_running_seconds))
        if len(container_running_seconds) == 0:
            completed_containers_statistic = {'number': 0}
        else:
            completed_containers_statistic = {
                'number': len(container_running_seconds),
                # 'mean': round(mean(container_running_seconds), 3),
                'median': round(median(container_running_seconds), 3),
                'min': round(min(container_running_seconds), 3),
                'max': round(max(container_running_seconds), 3)
            }

        return {
            ID_KEY: self.__id,
            SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_ALLOCATED: len(self.__container_infos),
            SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_RELEASED: self.__released_num_containers,
            SCHEDULE_STATISTIC_KEY_MAX_NUM_ALLOCATED: self.__max_num_containers,
            SCHEDULE_STATISTIC_KEY_NUM_ALLOCATED: self.__num_containers_snapshot,
            SCHEDULE_STATISTIC_KEY_FIRST_SCHEDULE_TIME:
                '' if first_schedule_ts == -1 else common_util.timestamp_to_str(first_schedule_ts,
                                                                                TO_SECOND_DATE_TIME_FORMAT),
            SCHEDULE_STATISTIC_KEY_LAST_SCHEDULE_TIME:
                '' if last_schedule_ts == -1 else common_util.timestamp_to_str(last_schedule_ts,
                                                                               TO_SECOND_DATE_TIME_FORMAT),
            SCHEDULE_STATISTIC_KEY_SCHEDULE_SECONDS: round(last_schedule_ts - first_schedule_ts, 3),
            SCHEDULE_STATISTIC_KEY_COMPLETED_STAT: str(completed_containers_statistic)
        }

    def get_container_infos(self):
        return list(map(lambda x: x.get_data(), self.__container_infos.values()))

    def get_container_info(self, container_id):
        return self.__container_infos.get(container_id)


class StateEvent:

    def __init__(self, timestamp, id, old_state, new_state, info=None, data=None):
        if data is not None:
            self.__data = data
            return
        self.__data = {
            TIMESTAMP_KEY: timestamp,
            ID_KEY: id,
            OLD_STATE_KEY: old_state,
            NEW_STATE_KEY: new_state
        }
        if info is not None:
            self.__data[INFO_KEY] = info

    def get_timestamp(self):
        return self.__data[TIMESTAMP_KEY]

    def get_id(self):
        return self.__data[ID_KEY]

    def get_old_state(self):
        return self.__data[OLD_STATE_KEY]

    def get_new_state(self):
        return self.__data[NEW_STATE_KEY]

    def get_info(self):
        return self.__data.get(INFO_KEY)

    def get_data(self):
        return self.__data


class StateInfo:

    def __init__(self, state, start_timestamp):
        self.state = state
        self.start_timestamp = start_timestamp
        self.finish_timestamp = -1
        self.next_state = None

    def get_hold_seconds(self):
        if self.finish_timestamp == -1:
            return -1
        return round(self.finish_timestamp - self.start_timestamp, 3)

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return json.dumps(
            {STATE_KEY: self.state,
             NEXT_STATE_KEY: self.next_state,
             START_TIME_KEY: common_util.timestamp_to_str(self.start_timestamp, TO_SECOND_DATE_TIME_FORMAT),
             FINISH_TIME_KEY: common_util.timestamp_to_str(self.finish_timestamp, TO_SECOND_DATE_TIME_FORMAT),
             HOLD_SECONDS_KEY: self.get_hold_seconds()})


class State:

    def __init__(self, id):
        self.__id = id
        self.__cur_state = None
        # list of state tuple (state_name, start_timestamp, finish_timestamp)
        self.__states = list()

    def state_changed(self, timestamp, old_state_name, new_state_name):
        if self.__cur_state is not None:
            if old_state_name != self.__cur_state.state:
                logging.error("old state ({}) doesn't match current state ({}) for {}".format(
                    old_state_name, self.__cur_state.state, self.__id))
            self.__cur_state.finish_timestamp = timestamp
            self.__cur_state.next_state = new_state_name
        self.__cur_state = StateInfo(new_state_name, timestamp)
        self.__states.append(self.__cur_state)

    # def get_state_change_time(self):
    #     if len(self.__states) < 2:
    #         return 0
    #     return self.__states[-1][1] - self.__states[0][1]

    def get_id(self):
        return self.__id

    def get_states(self):
        return self.__states

    def get_states_data(self):
        data_list = list()
        for state in self.get_states():
            data_list.append({
                ID_KEY: self.get_id(),
                STATE_KEY: state.state,
                START_TIMESTAMP_KEY: state.start_timestamp,
                FINISH_TIMESTAMP_KEY: state.finish_timestamp,
                HOLD_SECONDS_KEY: state.get_hold_seconds()
            })
        return data_list


class AppState(State):

    def __init__(self, id):
        super().__init__(id)
        self.__app_attempts = OrderedDict()
        self.__queue_name = None

    def app_attempt_state_changed(self, app_attempt_id, timestamp, old_state, new_state):
        app_attempt = common_util.get_or_new_value(self.__app_attempts, app_attempt_id, (AppAttemptState, app_attempt_id))
        app_attempt.state_changed(timestamp, old_state, new_state)

    def set_queue_name(self, queue_name):
        self.__queue_name = queue_name

    def get_queue_name(self):
        return self.__queue_name

    def get_app_attempts(self):
        return self.__app_attempts

    # get all states from itself and app attempts
    def get_all_states_data(self):
        all_states_data = list()
        all_states_data.extend(self.get_states_data())
        for _, app_attempt in self.__app_attempts.items():
            all_states_data.extend(app_attempt.get_states_data())
        return all_states_data


class AppAttemptState(State):

    def __init__(self, id):
        super().__init__(id)
