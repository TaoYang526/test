import os.path

from pkg.analyzers import log_analyzer
from pkg.analyzers.yarn import yarn_nm_log_info
from collections import OrderedDict
from pkg.utils import common_util, io_util
from pkg.constants import *
import logging


class ContainerRuntimeInfoProcessor(log_analyzer.LogProcessor):

    def __init__(self, context):
        self.__context = context
        self.__container_rt_info_dict = OrderedDict()
        self.__cache_file = os.path.join(self.__context.get_cache_dir(), self.__class__.__name__)

    def clear(self):
        self.__container_rt_info_dict = OrderedDict()

    def process(self, log_info):
        content = log_info.content
        if log_info.source == 'org.apache.hadoop.yarn.server.nodemanager.containermanager.container.ContainerImpl' \
                and content.find('transitioned from') != -1:
            container_id, old_state, new_state = self.parse_state_change(content)
            container_rt_info = common_util.get_or_new_value(self.__container_rt_info_dict, container_id,
                                                             [yarn_nm_log_info.ContainerRuntimeInfo, container_id])
            container_rt_info.add_state(old_state, new_state, log_info.timestamp)
        elif content.find('Start request for') == 0:
            parts = content.split(' ')
            container_id = parts[3]
            user = parts[6]
            container_rt_info = yarn_nm_log_info.ContainerRuntimeInfo(container_id, user=user)
            container_rt_info.add_state(None, NEW_STATE_NAME, log_info.timestamp)
            self.__container_rt_info_dict[container_id] = container_rt_info
        elif content.find('Exit code from container') == 0:
            parts = content.split(' ')
            container_id = parts[4]
            exit_code = int(parts[7])
            container_rt_info = common_util.get_or_new_value(self.__container_rt_info_dict, container_id,
                                                             [yarn_nm_log_info.ContainerRuntimeInfo, container_id])
            container_rt_info.set_exit_code(exit_code)
            self.__container_rt_info_dict[container_id] = container_rt_info

    def parse_state_change(self, content):
        parts = content.split(' ')
        id = parts[1]
        old_state = parts[4]
        new_state = parts[6]
        return id, old_state, new_state

    def persist(self):
        timer = common_util.get_timer()
        persist_obj = list()
        for info in self.__container_rt_info_dict.values():
            persist_obj.append(info.get_data())
        io_util.save_dict(self.__cache_file, persist_obj)
        logging.debug("persisted cache for {}: num_container_infos={}, elapse_time={}(ms)"
                      .format(self.__class__.__name__, len(self.__container_rt_info_dict), timer.get_elapse_ms()))

    def recover(self):
        if not os.path.exists(self.__cache_file):
            logging.warning("skip recovering {} since no cache file found!".format(self.__class__.__name__))
            return
        timer = common_util.get_timer()
        self.__container_rt_info_dict = OrderedDict()
        persist_obj = io_util.load_dict(self.__cache_file)
        for info_dict in persist_obj:
            container_rt_info = yarn_nm_log_info.ContainerRuntimeInfo(None, None, data=info_dict)
            self.__container_rt_info_dict[container_rt_info.get_container_id()] = container_rt_info
        logging.debug("recovered {}: num_container_infos={}, elapse_time={}(ms)"
                      .format(self.__class__.__name__, len(self.__container_rt_info_dict), timer.get_elapse_ms()))

    def get_container_infos(self, container_ids):
        results = list()
        if container_ids is not None and len(container_ids) > 0:
            for container_id in container_ids:
                container_info = self.__container_rt_info_dict.get(container_id)
                if container_info is not None:
                    results.append(container_info.get_data())
        else:
            for container_info in self.__container_rt_info_dict.values():
                results.append(container_info.get_data())
        return results
