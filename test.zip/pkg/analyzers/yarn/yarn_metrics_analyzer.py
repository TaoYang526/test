from pkg.analyzers.metrics_analyzer import *
from pkg.utils import io_util
from pkg.caches.yarn.common import *
import os


class YARNMetricsAnalyzer(MetricsAnalyzer):

    def __init__(self, key, context, conf_file=None, conf_dict=None):
        collector = YARNJmxCollector(context)
        # init processor
        if conf_dict is None:
            if conf_file is None:
                raise ConfError(
                    "either conf_file or conf_dict should be configured for {}".format(self.__class__.__name__))
            if not os.path.isabs(conf_file):
                conf_file = os.path.join(context.get_executing_path(), conf_file)
            conf_dict = io_util.load_yaml(conf_file)
        processor = CommonMetricsProcessor(conf_dict.get('monitor_metrics'))
        # init checker
        checker = CommonMetricsChecker(conf_dict.get('check'))
        super().__init__(collector, [processor], checker)


class YARNJmxCollector(MetricsCollector):

    def __init__(self, context):
        self.__yarn_jmx_cache = get_required_cache(context, CACHE_KEY_YARN_JMX_METRICS)

    def collect(self):
        # trigger refreshing the cache
        self.__yarn_jmx_cache.refresh()
        return self.__yarn_jmx_cache.get_data()
