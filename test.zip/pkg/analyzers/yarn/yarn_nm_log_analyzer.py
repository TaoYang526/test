from pkg.analyzers import log_analyzer
from pkg.analyzers.yarn import yarn_nm_log_processors
from pkg.utils import common_util


class YARNNMLogAnalyzer(log_analyzer.CommonLogAnalyzer):

    def __init__(self, key, context, log_parser=None):
        # init log parser
        self.__log_parser = common_util.generate_instance(log_parser,
                                                          {'context': context}) if log_parser is not None else None
        # init log processor
        self.__runtime_processor = yarn_nm_log_processors.ContainerRuntimeInfoProcessor(context)
        super().__init__(self.__log_parser, [self.__runtime_processor])

    def get_container_infos(self, container_ids):
        return self.__runtime_processor.get_container_infos(container_ids)
