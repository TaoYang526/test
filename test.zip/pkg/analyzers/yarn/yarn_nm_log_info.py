from pkg.constants import *
from collections import OrderedDict
import logging


class ContainerRuntimeInfo:

    def __init__(self, container_id, user=None, data=None):
        if data is not None:
            self.__data = data
        else:
            self.__data = {
                CONTAINER_ID_KEY: container_id,
                CONTAINER_STATES_KEY: OrderedDict(),
                CONTAINER_STATES_HOLD_SECONDS_KEY: OrderedDict()
            }
        if user is not None:
            self.__data[USER_KEY] = user

    def get_container_id(self):
        return self.__data[CONTAINER_ID_KEY]

    def get_states(self):
        return self.__data[CONTAINER_STATES_KEY]

    def add_state(self, old_state, new_state, timestamp):
        last_state, last_timestamp = self.get_last_state_and_timestamp()
        if last_state is not None:
            if last_state != old_state:
                logging.warning("got unexpect state for {} : last_state={}, expected_state={}".format(
                    self.get_container_id(), last_state, old_state))
            else:
                self.__data[CONTAINER_STATES_HOLD_SECONDS_KEY][last_state] = round(timestamp - last_timestamp, 3)
        self.__data[CONTAINER_STATES_KEY][new_state] = timestamp
        if new_state == NEW_STATE_NAME:
            self.__data[START_TIMESTAMP_KEY] = timestamp
        if new_state == RUNNING_STATE_NAME:
            new_timestamp = self.__data[CONTAINER_STATES_KEY].get(NEW_STATE_NAME)
            if new_timestamp is not None:
                self.__data[INIT_SECONDS_KEY] = round(timestamp - new_timestamp, 3)
        if old_state == RUNNING_STATE_NAME:
            self.__data[EXIT_STATE_KEY] = new_state
            start_running_timestamp = self.__data[CONTAINER_STATES_KEY].get(RUNNING_STATE_NAME)
            if start_running_timestamp is not None:
                self.__data[RUNNING_SECONDS_KEY] = round(timestamp - start_running_timestamp, 3)

    def set_exit_code(self, exit_code):
        self.__data[EXIT_CODE_KEY] = exit_code

    def get_exit_code(self):
        return self.__data[EXIT_CODE_KEY]

    def get_last_state_and_timestamp(self):
        if len(self.__data[CONTAINER_STATES_KEY]) == 0:
            return None, None
        return next(reversed(self.__data[CONTAINER_STATES_KEY].items()))

    def get_running_seconds(self):
        return self.__data[RUNNING_SECONDS_KEY]

    def get_exit_state(self):
        return self.__data[EXIT_STATE_KEY]

    def get_data(self):
        return self.__data
