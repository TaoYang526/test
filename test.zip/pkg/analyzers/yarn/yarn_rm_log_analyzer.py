from pkg.analyzers import log_analyzer
from pkg.analyzers.yarn import yarn_rm_log_processors
from pkg.utils import common_util


class YARNRMLogAnalyzer(log_analyzer.CommonLogAnalyzer):

    def __init__(self, key, context, log_parser=None):
        # init log parser
        self.__log_parser = common_util.generate_instance(log_parser,
                                                          {'context': context}) if log_parser is not None else None
        # init log processor
        self.__state_processor = yarn_rm_log_processors.StateProcessor(context)
        self.__schedule_processor = yarn_rm_log_processors.ScheduleProcessor(context)
        super().__init__(self.__log_parser, [self.__state_processor, self.__schedule_processor])

    def get_app_state(self, app_id):
        return self.__state_processor.get_app_state(app_id)

    def get_slow_app_states(self, hold_seconds_threshold):
        return self.__state_processor.get_slow_app_states(hold_seconds_threshold)

    def get_all_states_data(self):
        return self.__state_processor.get_all_states_data()

    # figure out which app has the largest number of allocated containers
    def get_app_statistic_infos(self):
        return self.__schedule_processor.get_app_statistic_infos()

    def get_app_schedule_info(self, app_id):
        return self.__schedule_processor.get_app_schedule_info(app_id)

    def get_container_info(self, container_id):
        return self.__schedule_processor.get_container_info(container_id)

    def get_container_events(self):
        return self.__schedule_processor.get_container_events()

    def get_allocate_qps_in_minutes(self):
        return self.__schedule_processor.get_allocate_qps_in_minutes()
