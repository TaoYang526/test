import os.path

from pkg.analyzers import log_analyzer
from pkg.analyzers.yarn import yarn_rm_log_info
from collections import OrderedDict
from pkg.utils import common_util, yarn_util, io_util
import re
import logging


class ScheduleProcessor(log_analyzer.LogProcessor):

    def __init__(self, context):
        self.__context = context
        self.__assigned_match_regex = r'container (\S+) of capacity ([\S|\s]*) on host (\S+), which'
        self.__released_match_regex = r'OPERATION=([\S|\s]*)\tTARGET=[\S|\s]*CONTAINERID=(\S+)[\t]*'
        self.__cache_file = os.path.join(self.__context.get_cache_dir(), self.__class__.__name__)
        self.__app_dict = OrderedDict()
        self.__container_events = list()

    def clear(self):
        self.__app_dict = OrderedDict()
        self.__container_events = list()

    def process(self, log_info):
        content = log_info.content
        if log_info.source == 'org.apache.hadoop.yarn.server.resourcemanager.scheduler.common.fica.FiCaSchedulerNode' \
                or log_info.source == 'org.apache.hadoop.yarn.server.resourcemanager.scheduler.SchedulerNode':
            if not content.startswith('Assigned container'):
                return
            event_type = 1
            match = re.search(self.__assigned_match_regex, content)
            container_id, resource, node_id = match.group(1), match.group(2), match.group(3)
            container_event = yarn_rm_log_info.ContainerEvent(log_info.timestamp, event_type, container_id, node_id,
                                                              resource)
            self.add_container_event(container_event)
        elif log_info.source == 'org.apache.hadoop.yarn.server.resourcemanager.RMAuditLogger' \
                and log_info.content.find('AM Released Container') != -1:
            event_type = -1
            match = re.search(self.__released_match_regex, content)
            operation, container_id = match.group(1), match.group(2)
            diagnostic = None
            if operation.startswith('AM Released Container('):
                diagnostic = operation[22:-1].strip()
                if diagnostic.find('\n') != -1:
                    diagnostic_parts = list(filter(lambda x: x != '' and x.find('Container is being started') == -1,
                                                   diagnostic.split('\n')))
                    if len(diagnostic_parts) >=2 and diagnostic_parts[-1] == diagnostic_parts[-2]:
                        diagnostic_parts = diagnostic_parts[:-1]
                    diagnostic = '; '.join(diagnostic_parts)
                diagnostic = diagnostic.strip()
            container_event = yarn_rm_log_info.ContainerEvent(log_info.timestamp, event_type, container_id, None,
                                                              None, diagnostic=diagnostic)
            self.add_container_event(container_event)

    def add_container_event(self, container_event):
        app_id = yarn_util.parse_app_id(container_event.get_container_id())
        app_schedule_info = common_util.get_or_new_value(self.__app_dict, app_id,
                                                         (yarn_rm_log_info.AppScheduleInfo, app_id))
        new_container_info = app_schedule_info.process_container_event(container_event)
        if new_container_info is None:
            return
        if container_event.get_event_type() == -1 and new_container_info is not None:
            # attach resource / node_id for released container
            container_event.set_resource(new_container_info.get_resource())
            container_event.set_node_id(new_container_info.get_node_id())
        self.__container_events.append(container_event)

    def get_app_statistic_infos(self):
        rst = list(map(lambda x: x.get_statistic_info(), self.__app_dict.values()))
        return rst

    def get_app_schedule_info(self, app_id):
        return self.__app_dict.get(app_id)

    def get_container_info(self, container_id):
        app_id = yarn_util.parse_app_id(container_id)
        app_info = self.get_app_schedule_info(app_id)
        if app_info is None:
            return None
        return app_info.get_container_info(container_id)

    def get_container_events(self):
        return list(map(lambda x: x.get_data(), self.__container_events))

    def get_allocate_qps_in_minutes(self):
        if len(self.__container_events) == 0:
            return dict()
        allocate_events = filter(lambda x: x.get_event_type() == 1, self.__container_events)
        group_dict = common_util.complex_group_by_dict(allocate_events, [lambda x: x.get_timestamp()],
                                                       lambda x: x.get_container_id())
        qps_calculator = common_util.QPSCalculator()
        for timestamp, containers_dict in group_dict.items():
            qps_calculator.add(timestamp, len(containers_dict))
        return qps_calculator.get_qps_buckets_in_minutes()

    def get_most_released_apps(self):
        if len(self.__container_events) == 0:
            return dict()

    def persist(self):
        timer = common_util.get_timer()
        persist_obj = list()
        for event in self.__container_events:
            persist_obj.append(event.get_data())
        io_util.save_dict(self.__cache_file, persist_obj)
        logging.debug("persisted cache for schedule-info processor: num_container_events={}, elapse_time={}(ms)"
                      .format(len(self.__container_events), timer.get_elapse_ms()))

    def recover(self):
        if not os.path.exists(self.__cache_file):
            logging.warning("skip recovering {} since no cache file found!".format(self.__class__.__name__))
            return
        timer = common_util.get_timer()
        self.__app_dict = OrderedDict()
        self.__container_events = list()
        persist_obj = io_util.load_dict(self.__cache_file)
        for event_data in persist_obj:
            container_event = yarn_rm_log_info.ContainerEvent(None, None, None, None, None, data=event_data)
            # self.__container_events.append(container_event)
            self.add_container_event(container_event)
        logging.debug("recovered schedule-info processor: num_container_events={}, elapse_time={}(ms)"
                      .format(len(self.__container_events), timer.get_elapse_ms()))


class StateProcessor(log_analyzer.LogProcessor):

    def __init__(self, context):
        self.__context = context
        self.__cache_file = os.path.join(self.__context.get_cache_dir(), self.__class__.__name__)
        self.__app_state_dict = OrderedDict()
        self.__state_events = list()

    def clear(self):
        self.__app_state_dict = OrderedDict()
        self.__state_events = list()

    def process(self, log_info):
        content = log_info.content
        if log_info.source == 'org.apache.hadoop.yarn.server.resourcemanager.rmapp.RMAppImpl' \
                and content.find('State change') != -1:
            app_id, old_state, new_state = self.parse_state_change(content)
            state_event = yarn_rm_log_info.StateEvent(log_info.timestamp, app_id, old_state, new_state)
            self.process_state_event(state_event)
        elif log_info.source == 'org.apache.hadoop.yarn.server.resourcemanager.rmapp.attempt.RMAppAttemptImpl' \
                and content.find('State change') != -1:
            app_attempt_id, old_state, new_state = self.parse_state_change(content)
            state_event = yarn_rm_log_info.StateEvent(log_info.timestamp, app_attempt_id, old_state, new_state)
            self.process_state_event(state_event)
        elif content.find('is acceptable in queue') != -1:
            parts = content.split(' ')
            queue_name = parts[7]
            app_id = parts[10]
            state_event = yarn_rm_log_info.StateEvent(log_info.timestamp, app_id, None, 'NEW',
                                                      info={'queue': queue_name})
            self.process_state_event(state_event)

    def process_state_event(self, state_event):
        self.__state_events.append(state_event)
        id = state_event.get_id()
        if id.startswith('application_'):
            app_state = common_util.get_or_new_value(self.__app_state_dict, id, (yarn_rm_log_info.AppState, id))
            app_state.state_changed(state_event.get_timestamp(), state_event.get_old_state(),
                                    state_event.get_new_state())
            if state_event.get_info() is not None:
                queue_name = state_event.get_info().get('queue')
                if queue_name is not None:
                    app_state.set_queue_name(queue_name)
        elif id.startswith('appattempt_'):
            app_id = yarn_util.parse_app_id(id)
            app_state = common_util.get_or_new_value(self.__app_state_dict, app_id, (yarn_rm_log_info.AppState, app_id))
            app_state.app_attempt_state_changed(id, state_event.get_timestamp(), state_event.get_old_state(),
                                                state_event.get_new_state())

    def get_slow_app_states(self, hold_seconds_threshold, filter_out_states=set(['RUNNING'])):
        slow_app_states = OrderedDict()
        for app_id, app_state in self.__app_state_dict.items():
            slow_states = list()
            for state in app_state.get_states():
                if state.state in filter_out_states:
                    continue
                if state.get_hold_seconds() >= hold_seconds_threshold:
                    slow_states.append(state)
            if len(slow_states) > 0:
                slow_app_states[app_id] = (slow_states, app_state)
        return slow_app_states

    def get_all_states_data(self):
        rst = list()
        for app_state in self.__app_state_dict.values():
            rst.extend(app_state.get_all_states_data())
        return rst

    def get_app_state(self, app_id):
        return self.__app_state_dict.get(app_id)

    def parse_state_change(self, content):
        parts = content.split(' ')
        id = parts[0]
        old_state = parts[4]
        new_state = parts[6]
        return id, old_state, new_state

    def persist(self):
        timer = common_util.get_timer()
        persist_obj = list()
        for event in self.__state_events:
            persist_obj.append(event.get_data())
        io_util.save_dict(self.__cache_file, persist_obj)
        logging.debug("persisted cache for state processor: num_state_events={}, elapse_time={}(ms)"
                      .format(len(self.__state_events), timer.get_elapse_ms()))

    def recover(self):
        if not os.path.exists(self.__cache_file):
            logging.warning("skip recovering {} since no cache file found!".format(self.__class__.__name__))
            return
        timer = common_util.get_timer()
        self.__app_state_dict = OrderedDict()
        self.__state_events = list()
        persist_obj = io_util.load_dict(self.__cache_file)
        for event_data in persist_obj:
            state_event = yarn_rm_log_info.StateEvent(None, None, None, None, data=event_data)
            self.process_state_event(state_event)
        logging.debug("recovered state processor: num_state_events={}, elapse_time={}(ms)"
                      .format(len(self.__state_events), timer.get_elapse_ms()))
