from pkg.analyzers import log_analyzer
from pkg.utils import common_util
from pkg.constants import *
from pkg.caches.common import *
import logging


class ASIEventLogAnalyzer(log_analyzer.CommonLogAnalyzer):

    def __init__(self, key, context, default_query_params, log_parser, event_log_processor):
        self.context = context
        # init log parser
        self.__log_parser = common_util.generate_instance(log_parser, {CONF_KEY_CONTEXT: context}) \
            if log_parser is not None else None
        # init log processor event_log_processor
        self.__event_processor = common_util.generate_instance(event_log_processor, {CONF_KEY_CONTEXT: context})
        self.__default_query_params = default_query_params
        super().__init__(self.__log_parser, [self.__event_processor])

    def get_event_infos(self, name=None, content=None, log_level=None, reason=None, source=None,
                        from_time=None, to_time=None, size=None, direct_query=None):
        super().clear()
        asi_sls_client = get_required_cache(self.context, CACHE_KEY_ASI_SLS_CLIENT)
        asi_log_source = self.context.get_env_value(ENV_KEY_ASI_LOG_SOURCE)
        asi_domain = self.context.get_env_value(ENV_KEY_ASI_DOMAIN)
        if direct_query:
            query = direct_query
        else:
            default_query = self.__default_query_params.get('default_query')
            name_format = self.__default_query_params.get('name_format')
            content_format = self.__default_query_params.get('content_format')
            log_level_format = self.__default_query_params.get('log_level_format')
            reason_format = self.__default_query_params.get('reason_format')
            source_format = self.__default_query_params.get('source_format')
            query = default_query
            if name:
                query += name_format.format(name)
            if content:
                query += content_format.format(content)
            if log_level:
                query += log_level_format.format(log_level)
            if reason:
                query += reason_format.format(reason)
            if source:
                query += source_format.format(source)
        logging.info("query: {}".format(query))
        from_time = from_time if from_time else self.__default_query_params.get('from_time')
        to_time = to_time if to_time else self.__default_query_params.get('to_time')
        size = size if size else self.__default_query_params.get('size')
        logging.info("query: {}, time_range: {} ~ {}, size: {}".format(query, from_time, to_time, size))
        logs = asi_sls_client.get_data(asi_log_source, from_time, to_time, asi_domain, None,
                                       None, None, query, 0, size, True)
        if len(logs) == 0:
            logging.warning("Logs not found!")
            return None
        self.process(logs)
        return self.__event_processor.get_event_infos()
