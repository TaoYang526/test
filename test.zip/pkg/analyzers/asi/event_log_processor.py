import os.path

from pkg.analyzers import log_analyzer
from pkg.analyzers.yarn import yarn_rm_log_info
from collections import OrderedDict
from pkg.utils import common_util, yarn_util, io_util
import re
import logging
from pkg.constants import *
from string import Template


class EventLogProcessor(log_analyzer.LogProcessor):

    def __init__(self, context, id_format, info_keys, event_keys):
        self.__context = context
        self.__id_format = id_format
        self.__info_keys = info_keys
        self.__event_keys = event_keys
        self.__obj_events = dict()

    def clear(self):
        self.__obj_events = dict()

    def process(self, info_dict):
        key_template = Template(self.__id_format)
        key = key_template.substitute(**info_dict)
        info = self.__obj_events.get(key)
        if not info:
            info = dict(filter(lambda elem: elem[0] in self.__info_keys, info_dict.items()))
            info[EVENTS_KEY] = []
            self.__obj_events[key] = info
        events = info.get(EVENTS_KEY)
        events.append(dict(filter(lambda elem: elem[0] in self.__event_keys, info_dict.items())))

    def persist(self):
        pass

    def recover(self):
        pass

    def get_event_infos(self):
        return self.__obj_events

    def get_events_by_name(self, name):
        return dict(filter(lambda elem: elem[0].endswith('/{}'.format(name)), self.__obj_events.items()))
