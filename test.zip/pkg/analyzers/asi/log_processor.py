from pkg.analyzers import log_analyzer
from pkg.constants import *
from string import Template


class TowLayerInfoAggregator(log_analyzer.LogProcessor):

    def __init__(self, context, id_format, info_keys, child_id_format, child_info_keys):
        self.__context = context
        self.__data = dict()
        self.__id_format = id_format
        self.__info_keys = info_keys
        self.__child_id_format = child_id_format
        self.__child_info_keys = child_info_keys

    def clear(self):
        self.__data = dict()

    def process(self, info_dict):
        if len(info_dict) == 0:
            return
        key = Template(self.__id_format).substitute(**info_dict)
        info = self.__data.get(key)
        if not info:
            info = dict(filter(lambda elem: elem[0] in self.__info_keys, info_dict.items()))
            info[CHILDREN_KEY] = {}
            self.__data[key] = info
        children = info[CHILDREN_KEY]
        child_key = Template(self.__child_id_format).substitute(**info_dict)
        child = children.get(child_key)
        if not child:
            child = []
            children[child_key] = child
        child_log = dict(filter(lambda elem: elem[0] in self.__child_info_keys, info_dict.items()))
        child.append(child_log)

    def persist(self):
        pass

    def recover(self):
        pass

    def get_data(self):
        return self.__data

    def get_item(self, id):
        return self.__data.get(id)

    def get_child_items(self, id, child_id):
        item = self.get_item(id)
        if not item:
            return None
        return item[CHILDREN_KEY].get(child_id)
