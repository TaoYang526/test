from pkg.analyzers import log_analyzer
from pkg.utils import common_util
from pkg.constants import *
from pkg.caches.common import *
import logging


class FlinkLogAnalyzer(log_analyzer.CommonLogAnalyzer):

    def __init__(self, key, context, default_query_params, log_parser, log_processor):
        self.context = context
        self.__default_query_params = default_query_params
        # init log parser
        self.__log_parser = common_util.generate_instance(log_parser, {CONF_KEY_CONTEXT: context}) \
            if log_parser is not None else None
        # init log processor event_log_processor
        self.__log_processor = common_util.generate_instance(log_processor, {CONF_KEY_CONTEXT: context})
        super().__init__(self.__log_parser, [self.__log_processor])

    def get_data(self, job_id=None, log_level=None, content=None, direct_query=None,
                 from_time=None, to_time=None, size=None):
        super().clear()
        asi_sls_client = get_required_cache(self.context, CACHE_KEY_ASI_SLS_CLIENT)
        asi_flink_log_source = self.context.get_env_value(ENV_KEY_ASI_FLINK_LOG_SOURCE)
        asi_flink_domain = self.context.get_env_value(ENV_KEY_ASI_FLINK_DOMAIN)
        default_query = self.__default_query_params.get('default_query')
        job_id_format = self.__default_query_params.get('job_id_format')
        log_level_format = self.__default_query_params.get('log_level_format')
        content_format = self.__default_query_params.get('content_format')
        query = default_query
        if job_id:
            if job_id.startswith("job-"):
                job_id = job_id[4:]
            query += job_id_format.format(job_id)
        if content:
            query += content_format.format(content)
        if log_level:
            query += log_level_format.format(log_level)
        if direct_query:
            if query != default_query:
                logging.warning("directQuery will take effect and jobId, contentQuery will be ignored!")
            query = direct_query
        if not from_time:
            from_time = self.__default_query_params.get('from_time')
        if not to_time:
            to_time = self.__default_query_params.get('to_time')
        if not size:
            size = self.__default_query_params.get('size')
        logging.info("log_source:{}, domain:{}, query: {}, time_range: {} ~ {}, size: {}".format(
            asi_flink_log_source, asi_flink_domain, query, from_time, to_time, size))
        logs = asi_sls_client.get_data(asi_flink_log_source, from_time, to_time, asi_flink_domain, None,
                                       None, None, query, 0, size, True)
        if len(logs) == 0:
            logging.warning("Logs not found!")
            return None
        self.process(logs)
        return self.__log_processor.get_data()
