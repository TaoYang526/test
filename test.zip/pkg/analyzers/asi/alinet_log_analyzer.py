import math
import os.path

from pkg.analyzers import log_analyzer
from pkg.analyzers.yarn import yarn_nm_log_info
from collections import OrderedDict
from pkg.utils import common_util, io_util
from pkg.constants import *
import logging
import sys

class AlinetLogAnalyzer(log_analyzer.CommonLogAnalyzer):

    def __init__(self, key, context, log_parser, log_processor):
        self.context = context
        # init log parser
        self.__log_parser = common_util.generate_instance(log_parser, {CONF_KEY_CONTEXT: context}) \
            if log_parser is not None else None
        # init log processor event_log_processor
        self.__log_processor = common_util.generate_instance(log_processor, {CONF_KEY_CONTEXT: context})
        super().__init__(self.__log_parser, [self.__log_processor])

    def get_processor(self):
        return self.__log_processor


class PodNetworkInfoProcessor(log_analyzer.LogProcessor):

    def __init__(self, context):
        self.__context = context
        self.__pod_rt_info_dict = OrderedDict()
        self.__timestamp_range = [sys.maxsize, 0]
        # self.__cache_file = os.path.join(self.__context.get_cache_dir(), self.__class__.__name__)
        self.__pod_start_msg = "K8S_POD_NAME="
        self.__pod_end_msg = ";"
        self.__request_id_key = "RequestId"
        self.__pod_event_start = "CNIFirstSeen"
        self.__pod_event_end = "CNIAttached"
        self.__request_pod_mapping = {}
        self.__event_locate_mapping = {
            "CNIFirstSeen": lambda msg, info_dict: self.__pod_start_msg in msg,
            "CNICreating": lambda msg, info_dict: msg.startswith("Creating NetworkInterface"),
            "CNIAllocating": lambda msg, info_dict: msg.startswith("Allocating NetworkInterface"),
            "CNIWaiting": lambda msg, info_dict: msg.startswith("Start waiting for cni-service allocate networkInterface"),
            "CNIAttached": lambda msg, info_dict: msg.startswith("Attach networkInterface"),
        }

    def get_events(self):
        return self.__event_locate_mapping.keys()

    def clear(self):
        self.__pod_rt_info_dict = OrderedDict()

    def add_pod_event(self, pod, event, time):
        if time < self.__timestamp_range[0]:
            self.__timestamp_range[0] = time
        if time > self.__timestamp_range[1]:
            self.__timestamp_range[1] = time
        pod_info = self.__pod_rt_info_dict.get(pod)
        if not pod_info:
            pod_info = {}
            self.__pod_rt_info_dict[pod] = pod_info
        pod_info[event] = time

    def parse_content(self, content):
        match = re.search(r'^msg="([\S|\s]+)" ([\S|\s]+)', content)
        if match:
            msg, info = match.group(1), match.group(2)
            info_dict = {}
            for v in info.split(' '):
                if v.find('=') != -1:
                    k, v = v.split('=')
                    info_dict[k] = v.strip('"')
            return msg, info_dict
        return None, None


    def process(self, log_info):
        content = log_info.content
        msg, info_dict = self.parse_content(content)
        if msg is None:
            return
        request_id = info_dict.get(self.__request_id_key)
        if not request_id:
            return
        if self.__pod_start_msg in msg:
            start = msg[msg.find(self.__pod_start_msg)+len(self.__pod_start_msg):]
            pod = start[:start.find(self.__pod_end_msg)]
            self.__request_pod_mapping[request_id] = pod
            logging.debug(f"add pod mapping: {request_id}={pod}")
        # add pod event
        pod = self.__request_pod_mapping.get(request_id)
        if pod:
            for k, v in self.__event_locate_mapping.items():
                if v(msg, info_dict):
                    logging.info(f"match: {k} {pod}")
                    self.add_pod_event(pod, k, log_info.timestamp)
                    break
        # logging.debug(f"pod_rt_info_dict: {self.__pod_rt_info_dict}")


    def get_pod_infos(self):
        result = {}
        for k, v in self.__pod_rt_info_dict.items():
            if self.__pod_event_start not in v or self.__pod_event_end not in v:
                logging.warning(f"pod {k} has not all events: {v}")
                continue
            result[k] = v
        return result

    def get_timestamp_range(self):
        return self.__timestamp_range

    # def get_qps_statistics(self):
    #     from_timestamp = common_util.parse_timestamp(self.__from_time, self.__time_format)
    #     to_timestamp = common_util.parse_timestamp(self.__to_time, self.__time_format)
    #     from_timestamp, to_timestamp = math.floor(from_timestamp), math.ceil(to_timestamp)
    #     qps_statistics = {}
    #     for event in self.__event_locate_mapping.keys():
    #         qps_statistics[event] = [0] * (to_timestamp - from_timestamp + 1)
    #     for events in self.get_pod_infos().values():
    #         for event, time in events.items():
    #             time = math.floor(time)
    #             if time < from_timestamp or time > to_timestamp:
    #                 continue
    #             qps_statistics[event][time - from_timestamp] += 1
    #     return qps_statistics
    #
    #
    # def get_latency_statistics(self):
    #     latency_statistics = {}
    #     phase_latency_data = {}
    #     for events in self.get_pod_infos().values():
    #         for phase, (start_event, end_event) in self.__phase_latency_mapping.items():
    #             start_time = events.get(start_event)
    #             end_time = events.get(end_event)
    #             if start_time is None or end_time is None:
    #                 continue
    #             latency = end_time - start_time
    #             latency_array = phase_latency_data.get(phase)
    #             if latency_array is None:
    #                 latency_array = []
    #                 phase_latency_data[phase] = latency_array
    #             phase_latency_data[phase].append(latency)
    #     for phase, latency_array in phase_latency_data.items():
    #         latency_statistics[phase] = (round(min(latency_array), 3),
    #                                      round(max(latency_array), 3),
    #                                      round(sum(latency_array) / len(latency_array), 3))
    #     return latency_statistics

    def persist(self):
        pass
    #     timer = common_util.get_timer()
    #     persist_obj = list()
    #     for info in self.__pod_rt_info_dict.values():
    #         persist_obj.append(info.get_data())
    #     io_util.save_dict(self.__cache_file, persist_obj)
    #     logging.debug("persisted cache for {}: num_pod_infos={}, elapse_time={}(ms)"
    #                   .format(self.__class__.__name__, len(self.__pod_rt_info_dict), timer.get_elapse_ms()))
    #
    def recover(self):
        pass
    #     if not os.path.exists(self.__cache_file):
    #         logging.warning("skip recovering {} since no cache file found!".format(self.__class__.__name__))
    #         return
    #     timer = common_util.get_timer()
    #     self.__pod_rt_info_dict = OrderedDict()
    #     persist_obj = io_util.load_dict(self.__cache_file)
    #     for info_dict in persist_obj:
    #         pod_rt_info = yarn_nm_log_info.ContainerRuntimeInfo(None, None, data=info_dict)
    #         self.__pod_rt_info_dict[pod_rt_info.get_container_id()] = pod_rt_info
    #     logging.debug("recovered {}: num_pod_infos={}, elapse_time={}(ms)"
    #                   .format(self.__class__.__name__, len(self.__pod_rt_info_dict), timer.get_elapse_ms()))
