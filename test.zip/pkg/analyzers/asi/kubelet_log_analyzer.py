import math
import os.path
import sys

from pkg.analyzers import log_analyzer
from pkg.analyzers.yarn import yarn_nm_log_info
from collections import OrderedDict
from pkg.utils import common_util, io_util
from pkg.constants import *
import logging

class KubeletLogAnalyzer(log_analyzer.CommonLogAnalyzer):

    def __init__(self, key, context, log_parser, log_processor):
        self.context = context
        # init log parser
        self.__log_parser = common_util.generate_instance(log_parser, {CONF_KEY_CONTEXT: context}) \
            if log_parser is not None else None
        # init log processor event_log_processor
        self.__log_processor = common_util.generate_instance(log_processor, {CONF_KEY_CONTEXT: context})
        super().__init__(self.__log_parser, [self.__log_processor])

    def get_processor(self):
        return self.__log_processor


class PodRuntimeInfoProcessor(log_analyzer.LogProcessor):

    def __init__(self, context):
        self.__context = context
        self.__pod_rt_info_dict = OrderedDict()
        self.__timestamp_range = [sys.maxsize, 0]
        # self.__cache_file = os.path.join(self.__context.get_cache_dir(), self.__class__.__name__)
        self.__event_locate_mapping = {
            "FirstSeen": lambda msg, info_dict: msg=="Receiving a new pod",
            "FirstSync": lambda msg, info_dict: msg=="Pod is being synced for the first time",
            "MountVolumesStart": lambda msg, info_dict: msg=="Waiting for volumes to attach and mount for pod",
            "MountVolumesDone": lambda msg, info_dict: msg=="All volumes are attached and mounted for pod",
            "IPDetermined": lambda msg, info_dict: msg=="Determined the ip for pod after sandbox changed",
            "PodSandboxCreating": lambda msg, info_dict: msg=="Creating PodSandbox for pod",
            "PodSandboxCreated": lambda msg, info_dict: msg=="Created PodSandbox for pod",
            "ContainerCreating": lambda msg, info_dict: msg=="Creating container in pod",
            "ContainerCreated": lambda msg, info_dict: msg=="Event occurred" and info_dict["message"]=="Created",
            "ContainerStarted": lambda msg, info_dict: msg=="Event occurred" and info_dict["message"]=="Started",
        }

    def get_events(self):
        return self.__event_locate_mapping.keys()

    def clear(self):
        self.__pod_rt_info_dict = OrderedDict()

    def add_pod_event(self, pod, event, time):
        if time < self.__timestamp_range[0]:
            self.__timestamp_range[0] = time
        if time > self.__timestamp_range[1]:
            self.__timestamp_range[1] = time
        pod_info = self.__pod_rt_info_dict.get(pod)
        if not pod_info:
            pod_info = {}
            self.__pod_rt_info_dict[pod] = pod_info
        pod_info[event] = time

    def parse_content(self, content):
        message, info_dict = "", {}
        # logging.info(f"match: {match}")
        if content.startswith('"'):
            msgEndIndex = content[1:].find('"')
            message = content[1:msgEndIndex+1]
            info = content[msgEndIndex+2:]
            for v in info.split(' '):
                if v.find('=') != -1:
                    k, v = v.split('=')
                    info_dict[k] = v.strip('"')
        return message, info_dict


    def process(self, log_info):
        content = log_info.content
        msg, info_dict = self.parse_content(content)
        logging.debug(f"msg: {msg}, info_dict: {info_dict}")
        for k, v in self.__event_locate_mapping.items():
            if v(msg, info_dict):
                logging.debug(f"match: {k}")
                pod = info_dict.get("pod")
                if not pod:
                    pod = info_dict.get("object")
                if "/" in pod:
                    pod = pod[pod.find("/")+1:]
                self.add_pod_event(pod, k, log_info.timestamp)
                break
        # logging.debug(f"pod_rt_info_dict: {self.__pod_rt_info_dict}")


    def get_pod_infos(self):
        result = {}
        for k, v in self.__pod_rt_info_dict.items():
            if 'FirstSeen' not in v or 'ContainerStarted' not in v:
                logging.warning(f"pod {k} has not all events: {v}")
                continue
            result[k] = v
        return result

    def get_timestamp_range(self):
        return self.__timestamp_range

    # def get_qps_statistics(self):
    #     from_timestamp, to_timestamp = self.__timestamp_range
    #     from_timestamp, to_timestamp = math.floor(from_timestamp), math.ceil(to_timestamp)
    #     qps_statistics = {}
    #     for event in self.__event_locate_mapping.keys():
    #         qps_statistics[event] = [0] * (to_timestamp - from_timestamp + 1)
    #     for events in self.get_pod_infos().values():
    #         for event, time in events.items():
    #             time = math.floor(time)
    #             if time < from_timestamp or time > to_timestamp:
    #                 logging.warning(f"time:{time}, from_timestamp:{from_timestamp}, to_timestamp:{to_timestamp}")
    #                 continue
    #             qps_statistics[event][time - from_timestamp] += 1
    #     return qps_statistics
    #
    #
    # def get_latency_statistics(self):
    #     latency_statistics = {}
    #     phase_latency_data = {}
    #     for events in self.get_pod_infos().values():
    #         for phase, (start_event, end_event) in self.__phase_latency_mapping.items():
    #             start_time = events.get(start_event)
    #             end_time = events.get(end_event)
    #             if start_time is None or end_time is None:
    #                 continue
    #             latency = end_time - start_time
    #             latency_array = phase_latency_data.get(phase)
    #             if latency_array is None:
    #                 latency_array = []
    #                 phase_latency_data[phase] = latency_array
    #             phase_latency_data[phase].append(latency)
    #     for phase, latency_array in phase_latency_data.items():
    #         latency_statistics[phase] = (round(min(latency_array), 3),
    #                                      round(max(latency_array), 3),
    #                                      round(sum(latency_array) / len(latency_array), 3))
    #     return latency_statistics

    def persist(self):
        pass
    #     timer = common_util.get_timer()
    #     persist_obj = list()
    #     for info in self.__pod_rt_info_dict.values():
    #         persist_obj.append(info.get_data())
    #     io_util.save_dict(self.__cache_file, persist_obj)
    #     logging.debug("persisted cache for {}: num_pod_infos={}, elapse_time={}(ms)"
    #                   .format(self.__class__.__name__, len(self.__pod_rt_info_dict), timer.get_elapse_ms()))
    #
    def recover(self):
        pass
    #     if not os.path.exists(self.__cache_file):
    #         logging.warning("skip recovering {} since no cache file found!".format(self.__class__.__name__))
    #         return
    #     timer = common_util.get_timer()
    #     self.__pod_rt_info_dict = OrderedDict()
    #     persist_obj = io_util.load_dict(self.__cache_file)
    #     for info_dict in persist_obj:
    #         pod_rt_info = yarn_nm_log_info.ContainerRuntimeInfo(None, None, data=info_dict)
    #         self.__pod_rt_info_dict[pod_rt_info.get_container_id()] = pod_rt_info
    #     logging.debug("recovered {}: num_pod_infos={}, elapse_time={}(ms)"
    #                   .format(self.__class__.__name__, len(self.__pod_rt_info_dict), timer.get_elapse_ms()))
