import logging
from pkg.utils import io_util
from pkg.constants import *
from pkg.caches.common import parse_log_content
import os
import collections


class LogIssuesHunter:

    def __init__(self, key, context, conf_file):
        if not os.path.isabs(conf_file):
            conf_file = os.path.join(context.get_executing_path(), conf_file)
        self.__conf_dict = io_util.load_yaml(conf_file)
        self.__context = context

    def hunt(self):
        cluster_local_conf_cache = self.__context.get_cache(CACHE_KEY_CLUSTER_LOCAL_CONF)
        cluster_local_conf_cache.load()
        sls_client_cache = self.__context.get_cache(CACHE_KEY_SLS_CLIENT)
        log_domain = self.__context.get_env_value(ENV_KEY_DOMAIN)
        topic = self.__context.get_cluster_id()
        issues, checklist = dict(), list()
        for group_name, group_conf in self.__conf_dict.items():
            target_logs_conf = group_conf.get(CONF_KEY_TARGET_LOGS)
            log_source = self.__context.get_env_decoded_str(target_logs_conf.get(CONF_KEY_SOURCE))
            from_time = target_logs_conf.get(CONF_KEY_FROM_TIME)
            to_time = target_logs_conf.get(CONF_KEY_TO_TIME)
            query = target_logs_conf.get(CONF_KEY_QUERY)
            size = target_logs_conf.get(CONF_KEY_SIZE)
            reverse = target_logs_conf.get(CONF_KEY_REVERSE)
            logs = sls_client_cache.get_data(log_source, from_time, to_time, log_domain, None,
                                             None, topic, query, 0, size, reverse)
            logging.debug('found {} logs for {} with conditions: log_source={}, log_domain={}, topic={}, query={},'
                          ' from_time={}, to_time={}, size={} reverse={}'.format(len(logs), group_name, log_source,
                                                                                 log_domain, topic, query, from_time,
                                                                                 to_time, size, reverse))
            if len(logs) == 0:
                checklist.append(group_name)
                continue
            logging.debug('first log: {}'.format(logs[0].get_contents().get('content')))
            diagnoses_conf = group_conf.get(CONF_KEY_DIAGNOSES)
            for issue_name, diagnose_conf in diagnoses_conf.items():
                checklist.append(issue_name)
                pattern = diagnose_conf.get(CONF_KEY_PATTERN)
                info_extract_expression = diagnose_conf.get(CONF_KEY_INFO_EXTRACT_EXPRESSION)
                hit_expression = diagnose_conf.get(CONF_KEY_HIT_EXPRESSION)
                hit_infos = []
                for log in logs:
                    content = parse_log_content(log)
                    if content is None:
                        continue
                    match = re.search(pattern, content)
                    if match is not None:
                        info = eval(info_extract_expression)
                        hit = eval(hit_expression)
                        if hit:
                            hit_infos.append(info)
                        logging.debug('found matched log content: info={}, hit={}, hit_index={}, content={}'.format(
                            info, hit, len(hit_infos) - 1, content))
                if len(hit_infos) > 0:
                    output_expression = diagnose_conf.get(CONF_KEY_OUTPUT_EXPRESSION)
                    output = eval(output_expression)
                    issues[issue_name] = output
        return issues, checklist
