import json
import math

from pkg.utils import rest_util, common_util, io_util, yarn_util
from collections import OrderedDict
from pkg.caches.common import *
from pkg.framework.error import *
from pkg.constants import *
import logging


def get_cluster(context):
    return context.get_env_value(ENV_KEY_HADOOP_CLUSTER)


def get_required_yarn_basic_info(context):
    yarn_state_cache = context.get_cache(CACHE_KEY_YARN_STATE)
    if yarn_state_cache is None:
        raise ConfError("failed to find cache {} while loading cache {}".format(CACHE_KEY_YARN_STATE,
                                                                                   YARN_STATE_KEY_YARN_BASIC_INFO))
    # check required condition
    yarn_basic_info = yarn_state_cache.get_data(YARN_STATE_KEY_YARN_BASIC_INFO)
    if yarn_basic_info.data_source is None:
        raise RuntimeError("data source not found")
    return yarn_basic_info


def get_active_rm_state(context):
    yarn_state_cache = get_required_cache(context, CACHE_KEY_YARN_STATE)
    active_rm_state = yarn_state_cache.get_data(YARN_STATE_KEY_ACTIVE_RM_STATE)
    if active_rm_state is None:
        raise RuntimeError('active RM not found')
    return active_rm_state


# return tmp partitions
def get_tmp_partitions(context):
    yarn_partitions_cache = get_required_cache(context, CACHE_KEY_YARN_PARTITIONS)
    partitions = yarn_partitions_cache.get_data()
    tmp_partitions = dict()
    for partition in partitions.values():
        tmp_partition = TmpPartition(partition)
        tmp_partitions[partition.get_name()] = tmp_partition
    yarn_nodes_cache = get_required_cache(context, CACHE_KEY_YARN_NODES)
    nodes = yarn_nodes_cache.get_data()
    for node in nodes.values():
        tmp_partition = tmp_partitions.get(node.get_partition())
        if tmp_partition is None:
            raise ArgumentsError("partition {} not found for node {}, valid partitions: {}".format(
                node.get_partition(), node.get_id(), list(tmp_partitions.keys())))
        if node.is_running():
            tmp_partition.add_node(node)
    return tmp_partitions


def parse_resource(resource_dict):
    if resource_dict is None:
        return None
    resource = [resource_dict.get('memory'),
                resource_dict.get('vCores') if 'vCores' in resource_dict else resource_dict.get('virtualCores')]
    resource_infos = resource_dict.get('resourceInformations')
    if resource_infos is not None:
        ris = resource_infos.get('resourceInformation')
        for ri in ris:
            if ri.get('name') in YARN_SKIPPED_RESOURCE_NAMES_IN_RI:
                continue
            resource.append(ri.get('value'))
    return tuple(resource)


def get_required_app(context, app_id):
    app_cache = get_required_cache(context, CACHE_KEY_YARN_APPS)
    app = app_cache.get_data(app_id)
    if app is None:
        raise ArgumentsError("app {} not found!".format(app_id))
    return app


def get_required_queue(context, queue_name):
    queue_cache = get_required_cache(context, CACHE_KEY_YARN_QUEUES)
    queue = queue_cache.get_data(queue_name)
    if queue is None:
        raise ArgumentsError("queue {} not found!".format(queue_name))
    return queue


def get_activities(context, queue_path, partition_name, app_id=None):
    scheduler_activities_cache = get_required_cache(context, CACHE_KEY_YARN_SCHEDULER_ACTIVITIES)
    return scheduler_activities_cache.get_data(
        {'queue_path': queue_path, 'partition': partition_name, 'app_id': app_id})


def check_app(context, app_verf, app, queue):
    max_request_resource = app.get_max_request_resource()
    app_outputs = ['BasicInfo: {}'.format(app.get_basic_info(', ')),
                   'RunningInfo: {}'.format(app.get_running_info(', ')),
                   'PendingRequests: {}'.format(app.get_pending_requests_info(', ')),
                   'MaxPendingRequest: {}'.format(max_request_resource),
                   "YARN Diagnostic: {}".format(app.get_diagnostics())]
    app_verf.add_output('App {}'.format(app.get_id()), app_outputs)
    if len(app.get_pending_resource_requests()) == 0:
        app_verf.add_output('No pending resource')
        app_verf.succeeded()
        return
    partitions = list(map(lambda x: x.partition, app.get_pending_resource_requests()))
    partition_info = queue.get_partition_info(partitions[0])
    user_info = queue.get_user_info(app.get_user())
    app_verf.add_output('Queue {}'.format(app.get_queue()),
                        ['Capacities: {}'.format(partition_info.get_capacities_info(delimiter=', ')),
                         'Headroom: {}'.format(partition_info.get_headroom_info(delimiter=', ')),
                         'User {} Headroom: {}'.format(app.get_user(),
                                                       user_info.get_headroom_info(delimiter=', '))])
    confirmed_diagnostics = list()
    if app.get_state() == "ACCEPTED" and app.get_num_allocated_containers() == 0:
        diagnostic = check_headroom(context, partition_info.get_am_headroom(), max_request_resource, 'queue AM')
        if diagnostic is not None:
            confirmed_diagnostics.append(diagnostic)
        diagnostic = check_headroom(context, user_info.get_am_headroom(), max_request_resource, 'user AM')
        if diagnostic is not None:
            confirmed_diagnostics.append(diagnostic)
    diagnostic = check_headroom(context, partition_info.get_headroom(), max_request_resource, 'queue')
    if diagnostic is not None:
        confirmed_diagnostics.append(diagnostic)
    diagnostic = check_headroom(context, user_info.get_headroom(), max_request_resource, 'user')
    if diagnostic is not None:
        confirmed_diagnostics.append(diagnostic)
    if len(confirmed_diagnostics) > 0:
        app_verf.add_output("Confirmed Diagnostics", confirmed_diagnostics)
    else:
        app_verf.add_output("No Diagnostics detected, please make sure ")
    app_verf.succeeded()


def check_headroom(context, headroom, max_request_resource, headroom_type):
    if headroom is None:
        return None
    if common_util.iterable_any_matches(headroom, lambda it: it <= 0):
        conf_key = CONF_KEY_DIAGNOSTICS_INSUF_QUEUE_HEADROOM if headroom_type == "queue" \
            else CONF_KEY_DIAGNOSTICS_INSUF_USER_HEADROOM
        diagnostics = context.get_conf().get(CONF_KEY_DIAGNOSTICS, conf_key)
        return 'limited by {} headroom {}: {}'.format(headroom_type, headroom, diagnostics)
    elif common_util.iterable_any_matches(common_util.sub_tuple_by_indexes(headroom, max_request_resource),
                                          lambda it: it < 0):
        conf_key = CONF_KEY_DIAGNOSTICS_INSUF_QUEUE_AM_HEADROOM if headroom_type == "queue" \
            else CONF_KEY_DIAGNOSTICS_INSUF_USER_AM_HEADROOM
        diagnostics = context.get_conf().get(CONF_KEY_DIAGNOSTICS, conf_key)
        return 'limited by {} headroom {}, max request resource={}: {}'.format(
            headroom_type, headroom, max_request_resource, diagnostics)
    return None


def get_conf_list(data_source, additional_query=None):
    rm_conf_source_data = data_source.get_data(SOURCE_DATA_KEY_RM_CONF, additional_query)
    if str(rm_conf_source_data.content).find("<?xml") == 0:
        return io_util.read_xml(None, xml_content=rm_conf_source_data.content)
    else:
        rm_conf = common_util.parse_json_str(rm_conf_source_data.content)
        return rm_conf.get(ROOT_NAME_YARN_RM_CONF)


class YARNBasicInfo:

    def __init__(self, scheduler_class, ha_enabled, data_source):
        self.scheduler_class = scheduler_class
        self.ha_enabled = ha_enabled
        self.data_source = data_source

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return json.dumps(self.to_json())

    def to_json(self):
        return {"ha_enabled": self.ha_enabled, "scheduler_class": self.scheduler_class,
                "data_source": str(self.data_source)}

    def is_capacity_scheduler(self):
        return self.scheduler_class is None or self.scheduler_class.endswith('CapacityScheduler')


class RMState:
    def __init__(self, rm_id, host_name, data_source):
        self.__id = rm_id
        self.__host_name = host_name if host_name != '0.0.0.0' else None
        self.__data_source = data_source
        self.__conf_list = None
        self.__rm_info_dict = None
        self.__cluster_metrics_dict = None

    def load_conf(self):
        self.__conf_list = get_conf_list(self.__data_source, additional_query=self.__host_name)
        logging.debug("loaded conf in RMState for {}".format(self.__id))

    def load_rm_info(self):
        info_source_data = self.__data_source.get_data(SOURCE_DATA_KEY_CLUSTER_INFO, additional_query=self.__host_name)
        info_resp_obj = common_util.parse_json_str(info_source_data.content)
        self.__rm_info_dict = info_resp_obj.get(ROOT_NAME_YARN_CLUSTER_INFO)
        logging.debug("loaded info in RMState for {}".format(self.__id))

    def load_cluster_metrics(self):
        cluster_metrics_source_data = self.__data_source.get_data(SOURCE_DATA_KEY_CLUSTER_METRICS)
        cluster_metrics_resp_obj = common_util.parse_json_str(cluster_metrics_source_data.content)
        self.__cluster_metrics_dict = cluster_metrics_resp_obj.get(ROOT_NAME_YARN_CLUSTER_METRICS)
        logging.debug("loaded cluster metrics in RMState for {}".format(self.__id))

    def get_id(self):
        return self.__id

    def get_hostname(self):
        return self.__host_name

    def get_conf_list(self):
        if self.__conf_list is None:
            self.load_conf()
        return self.__conf_list

    def get_conf_dict(self):
        return dict(map(lambda x: [x['key'], x['value']], self.get_conf_list()))

    def get_info_dict(self):
        if self.__rm_info_dict is None:
            self.load_rm_info()
        return self.__rm_info_dict

    def get_cluster_metrics_dict(self):
        if self.__cluster_metrics_dict is None:
            self.load_cluster_metrics()
        return self.__cluster_metrics_dict

    def get_version(self):
        return self.get_info_dict().get('hadoopVersion')

    def is_active(self):
        info_dict = self.get_info_dict()
        if info_dict is not None:
            return info_dict.get('haState') == 'ACTIVE'
        return False


class Queue:

    def __init__(self, parent_queue, info_dict):
        self.__name = None
        self.__path = None
        self.__parent_queue = parent_queue
        self.__info_dict = info_dict
        self.__child_queues = dict()
        self.__partition_infos = dict()
        self.__user_infos = dict()
        self.__level = -1
        self.__max_depth = -1
        self.load()

    def load(self):
        if self.__parent_queue is None:
            self.__level = 0
        else:
            self.__level = self.__parent_queue.get_level() + 1
        self.__name = self.__info_dict.get('queueName')
        self.__path = "{}.{}".format(self.__parent_queue.get_path(),
                                     self.__name) if self.__parent_queue is not None else self.__name
        capabilities = self.__info_dict.get('capacities')
        if capabilities is not None:
            capacities_by_partition_list = capabilities.get('queueCapacitiesByPartition')
            for capacities_by_partition in capacities_by_partition_list:
                queue_partition_info = QueuePartitionInfo(capacities_by_partition.get('partitionName'))
                queue_partition_info.add_capacities(capacities_by_partition.get('absoluteCapacity'),
                                                    capacities_by_partition.get('absoluteMaxCapacity'),
                                                    capacities_by_partition.get('absoluteUsedCapacity'),
                                                    parse_resource(capacities_by_partition.get('configuredMinResource')),
                                                    parse_resource(capacities_by_partition.get('configuredMaxResource')),
                                                    parse_resource(capacities_by_partition.get('effectiveMinResource')),
                                                    parse_resource(capacities_by_partition.get('effectiveMaxResource')))
                self.__partition_infos[queue_partition_info.get_name()] = queue_partition_info
        resources_list = self.__info_dict.get('resources')
        if resources_list is not None:
            resources_by_partition_list = resources_list.get('resourceUsagesByPartition')
            for resources_by_partition in resources_by_partition_list:
                queue_partition_info = self.__partition_infos.get(resources_by_partition.get('partitionName'))
                queue_partition_info.add_resources(parse_resource(resources_by_partition.get('pending')),
                                                   parse_resource(resources_by_partition.get('used')),
                                                   parse_resource(resources_by_partition.get('reserved')),
                                                   parse_resource(resources_by_partition.get('amUsed')),
                                                   parse_resource(resources_by_partition.get('amLimit')),
                                                   parse_resource(resources_by_partition.get('userAmLimit')))
        user_am_resource_limit = self.__info_dict.get('userAMResourceLimit')
        users_list = self.__info_dict.get('users')
        if users_list is not None:
            user_list = users_list.get('user') if users_list.get('user') is not None else []
            for user in user_list:
                user_name = user.get('username')
                self.__user_infos[user_name] = QueueUserInfo(user_name, parse_resource(user.get('resourcesUsed')),
                                                             parse_resource(user.get('userResourceLimit')),
                                                             parse_resource(user.get('AMResourceUsed')),
                                                             parse_resource(user_am_resource_limit))
        max_depth = 1
        child_queues_info = self.__info_dict.get('queues')
        if child_queues_info is not None:
            for child_queue_info in child_queues_info.get('queue'):
                child_queue = Queue(self, child_queue_info)
                self.__child_queues[child_queue.get_name()] = child_queue
                if max_depth < child_queue.get_max_depth() + 1:
                    max_depth = child_queue.get_max_depth() + 1
        self.__max_depth = max_depth

    def get_partition_info(self, partition):
        return self.__partition_infos.get(partition)

    def get_partition_infos(self):
        return self.__partition_infos

    def get_user_info(self, user_name):
        return self.__user_infos.get(user_name)

    def get_user_resources_info(self, delimiter='\n'):
        if self.__user_infos is None:
            return ''
        user_resources_info = []
        for user_info in self.__user_infos.values():
            user_resources_info.append("[{}] Used={}{}Limit={}{}AMUsed={}{}AMLimit={}{}Headroom={}{}AMHeadroom={}" \
                                       .format(user_info.get_user_name(), user_info.get_used_resource(), delimiter,
                                               user_info.get_resource_limit(), delimiter,
                                               user_info.get_am_used_resource(), delimiter,
                                               user_info.get_am_resource_limit(), delimiter,
                                               user_info.get_headroom(), delimiter,
                                               user_info.get_am_headroom()))
        return "\n".join(user_resources_info)

    def get_level(self):
        return self.__level

    def get_name(self):
        return self.__name

    def get_path(self):
        return self.__path

    def get_info_dict(self):
        return self.__info_dict

    def get_child_queues(self):
        return self.__child_queues

    def is_leaf(self):
        return len(self.__child_queues) == 0

    def is_root(self):
        return self.__level == 0

    def get_max_depth(self):
        return self.__max_depth

    # parent queue doesn't have this field, so this may return None
    def get_num_pending_apps(self):
        return self.__info_dict.get('numPendingApplications')

    # parent queue doesn't have this field, so this may return None
    def get_num_active_apps(self):
        return self.__info_dict.get('numActiveApplications')

    def get_num_max_apps(self):
        return max(self.__info_dict.get('maxApplications'), self.__info_dict.get('maxApplicationsPerUser'))

    def get_num_pending_containers(self):
        return self.__info_dict.get('pendingContainers')

    def get_num_allocated_containers(self):
        return self.__info_dict.get('allocatedContainers')

    def get_num_reserved_containers(self):
        return self.__info_dict.get('reservedContainers')

    def get_apps_info(self, delimiter='\n'):
        if self.get_num_pending_apps() is None:
            return ''
        return "Pending: {}{}Active: {}".format(
            self.get_num_pending_apps(), delimiter, self.get_num_active_apps())

    def get_containers_info(self, delimiter='\n'):
        if self.get_num_pending_containers() is None:
            return ''
        return "Pending: {}{}Allocated: {}{}Reserved: {}".format(
            self.get_num_pending_containers(), delimiter, self.get_num_allocated_containers(), delimiter,
            self.get_num_reserved_containers())


class QueuePartitionInfo:

    def __init__(self, name):
        self.__name = name
        self.__absolute_capacity = None
        self.__absolute_max_capacity = None
        self.__absolute_used_capacity = None
        self.__pending_resource = None
        self.__used_resource = None
        self.__reserved_resource = None
        self.__am_used_resource = None
        self.__am_limit_resource = None
        self.__user_am_limit_resource = None
        self.__configured_min_resource = None
        self.__configured_max_resource = None
        self.__effective_min_resource = None
        self.__effective_max_resource = None

    def add_capacities(self, absolute_capacity, absolute_max_capacity, absolute_used_capacity, configured_min_resource,
                       configured_max_resource, effective_min_resource, effective_max_resource):
        self.__absolute_capacity = absolute_capacity
        self.__absolute_max_capacity = absolute_max_capacity
        self.__absolute_used_capacity = absolute_used_capacity
        self.__configured_min_resource = configured_min_resource
        self.__configured_max_resource = configured_max_resource
        self.__effective_min_resource = effective_min_resource
        self.__effective_max_resource = effective_max_resource

    def add_resources(self, pending_resource, used_resource, reserved_resource, am_used_resource, am_limit_resource,
                      user_am_limit_resource):
        self.__pending_resource = pending_resource
        self.__used_resource = used_resource
        self.__reserved_resource = reserved_resource
        self.__am_used_resource = am_used_resource
        self.__am_limit_resource = am_limit_resource
        self.__user_am_limit_resource = user_am_limit_resource

    def get_name(self):
        return self.__name

    def get_capacities_info(self, delimiter='\n'):
        if self.__absolute_capacity is None:
            return ''
        rst = "Capacity={}{}MaxCapacity={}{}UsedCapacity={}".format(
            self.__absolute_capacity, delimiter, self.__absolute_max_capacity, delimiter, self.__absolute_used_capacity)
        if self.__effective_min_resource is not None:
            rst += "{}EffectiveMin={}{}EffectiveMax={}".format(delimiter, self.__effective_min_resource, delimiter,
                                                                 self.__effective_max_resource)
        return rst

    def get_resources_info(self, delimiter='\n'):
        if self.__pending_resource is None:
            return ''
        return "Pending={}{}Used={}{}Reserved={}".format(
            self.__pending_resource, delimiter, self.__used_resource, delimiter, self.__reserved_resource)

    def get_headroom_info(self, delimiter='\n'):
        return "Headroom={}{}AMHeadroom={}".format(self.get_headroom(), delimiter, self.get_am_headroom())

    def has_pending_resource(self):
        if self.__pending_resource is not None and sum(self.__pending_resource) > 0:
            return True
        return False

    def get_am_resources_info(self, delimiter='\n'):
        if self.__pending_resource is None:
            return ''
        return "AMUsed={}{}AMLimit={}{}UserAMLimit={}".format(
            self.__am_used_resource, delimiter, self.__am_limit_resource, delimiter, self.__user_am_limit_resource)

    # parent queue doesn't have AM headroom, this may return None for parent queues
    def get_am_headroom(self):
        if self.__am_limit_resource is None or self.__user_am_limit_resource is None:
            return None
        am_limit = common_util.min_tuple_by_indexes(self.__am_limit_resource, self.__user_am_limit_resource)
        return yarn_util.calculate_headroom(am_limit, self.__am_used_resource)

    def get_headroom(self):
        if self.__effective_max_resource is None or self.__used_resource is None:
            return None
        return yarn_util.calculate_headroom(self.__effective_max_resource, self.__used_resource)

    def get_configured_min_resource(self):
        return self.__configured_min_resource

    def get_effective_min_resource(self):
        return self.__effective_min_resource

    def get_effective_max_resource(self):
        return self.__effective_max_resource

    def __repr__(self):
        return json.dumps({'capacities_info': self.get_capacities_info(delimiter=', '),
                          'resources_info': self.get_resources_info(delimiter=', ')})


class QueueUserInfo:

    def __init__(self, user_name, used_resource, resource_limit, am_used_resource, am_resource_limit):
        self.__user_name = user_name
        self.__used_resource = used_resource
        self.__resource_limit = resource_limit
        self.__am_used_resource = am_used_resource
        self.__am_resource_limit = am_resource_limit

    def get_user_name(self):
        return self.__user_name

    def get_used_resource(self):
        return self.__used_resource

    def get_am_used_resource(self):
        return self.__am_used_resource

    def get_resource_limit(self):
        return self.__resource_limit

    def get_am_resource_limit(self):
        return self.__am_resource_limit

    def get_headroom(self):
        return yarn_util.calculate_headroom(self.__resource_limit, self.__used_resource)

    def get_am_headroom(self):
        return yarn_util.calculate_headroom(self.__am_resource_limit, self.__am_used_resource)

    def get_headroom_info(self, delimiter='\n'):
        return "Headroom={}{}AMHeadroom={}".format(self.get_headroom(), delimiter, self.get_am_headroom())


class Partition:

    def __init__(self, name, exclusivity):
        self.__name = name
        self.__exclusivity = exclusivity

    def get_name(self):
        return self.__name

    def is_exclusivity(self):
        return self.__exclusivity


# support for calculating tmp info (like total resource or number of nodes)
class TmpPartition(Partition):

    def __init__(self, partition):
        super().__init__(partition.get_name(), partition.is_exclusivity())
        self.__num_nodes = 0
        self.__total_resource = (0, 0)
        self.__used_resource = (0, 0)

    def add_node(self, node):
        self.__num_nodes += 1
        self.__total_resource = common_util.add_tuple_by_indexes(self.__total_resource, node.get_total_resource())
        self.__used_resource = common_util.add_tuple_by_indexes(self.__used_resource, node.get_used_resource())

    def get_num_nodes(self):
        return self.__num_nodes

    def get_total_resource(self):
        return self.__total_resource

    def get_used_resource(self):
        return self.__used_resource

    def get_used_ratio(self):
        return common_util.divide_tuple_by_indexes(self.get_used_resource(), self.get_total_resource())


class App:

    def __init__(self, app_resp):
        self.__id = app_resp.get('id')
        self.__user = app_resp.get('user')
        self.__name = app_resp.get('name')
        self.__queue = app_resp.get('queue')
        if self.__queue.find('.') > 0:
            self.__queue = self.__queue.rsplit('.', 1)[1]
        self.__priority = app_resp.get('priority')
        if self.__priority is None:
            self.__priority = 0
        self.__state = app_resp.get('state')
        self.__diagnostics = app_resp.get('diagnostics')
        self.__type = app_resp.get('applicationType')
        self.__tags = app_resp.get('applicationTags')
        self.__cluster_usage_percentage = app_resp.get('clusterUsagePercentage')
        self.__start_timestamp = app_resp.get('startedTime') / 1000.0
        self.__num_allocated_containers = app_resp.get('runningContainers')
        self.__resource_requests = list()
        rrs_resp = app_resp.get('resourceRequests')
        if rrs_resp is not None:
            for rr_resp in rrs_resp:
                self.__resource_requests.append(ResourceRequest(rr_resp))

    def get_id(self):
        return self.__id

    def get_queue(self):
        return self.__queue

    def get_user(self):
        return self.__user

    def get_state(self):
        return self.__state

    def get_info_dict(self):
        return {COLUMN_KEY_ID: self.__id, COLUMN_KEY_NAME: self.__name, COLUMN_KEY_QUEUE: self.__queue,
                COLUMN_KEY_PRIORITY: self.__priority, COLUMN_KEY_USER: self.__user, COLUMN_KEY_STATE: self.__state,
                COLUMN_KEY_DIAGNOSTICS: self.__diagnostics, COLUMN_KEY_TYPE: self.__type,
                COLUMN_KEY_TAGS: self.__tags, COLUMN_KEY_START_TIME: self.get_start_time(),
                COLUMN_KEY_START_TIMESTAMP: self.__start_timestamp,
                COLUMN_KEY_NUM_ALLOCATED_CONTAINERS: self.__num_allocated_containers,
                COLUMN_KEY_NUM_PENDING_CONTAINERS: self.get_num_pending_containers(),
                COLUMN_KEY_CLUSTER_USAGE_PERCENTAGE: self.__cluster_usage_percentage}

    def get_num_pending_containers(self):
        return sum(list(map(lambda x: x.num_containers, self.__resource_requests)))

    def get_num_allocated_containers(self):
        return self.__num_allocated_containers

    def get_start_time(self):
        return common_util.timestamp_to_str(self.__start_timestamp)

    def get_basic_info(self, delimiter='\n'):
        return "Name={}{}Queue={}{}User={}{}Type={}{}Priority={}{}Tags={}".format(
            self.__name, delimiter, self.__queue, delimiter, self.__user, delimiter, self.__type, delimiter,
            self.__priority, delimiter, self.__tags)

    def get_running_info(self, delimiter='\n'):
        return "State={}{}StartedTime={}{}ElapseSeconds={}{}NumAllocatedContainers={}".format(
            self.__state, delimiter, self.get_start_time(), delimiter,
            round(common_util.get_timestamp() - self.__start_timestamp, 3), delimiter, self.__num_allocated_containers)

    def get_pending_requests_info(self, delimiter='\n'):
        rst = ''
        for rr in self.get_pending_resource_requests():
            if rst != '':
                rst += delimiter
            rst += "Priority={}{}ResourceName={}{}Resource={}{}NumContainers={}{}RelaxLocality={}{}" \
                   "Partition={}".format(rr.priority, delimiter, rr.resource_name, delimiter, rr.resource,
                                         delimiter, rr.num_containers, delimiter, rr.relax_locality, delimiter,
                                         rr.partition)
        return rst

    def get_max_request_resource(self):
        max_request_resource = None
        for rr in self.get_pending_resource_requests():
            if max_request_resource is None:
                max_request_resource = rr.resource
                continue
            max_request_resource = common_util.max_tuple_by_indexes(max_request_resource, rr.resource)
        return max_request_resource

    def get_diagnostics(self):
        return self.__diagnostics

    def get_pending_resource_requests(self):
        return list(filter(lambda x: x.num_containers > 0, self.__resource_requests))

    def get_resource_requests(self):
        return self.__resource_requests


class ResourceRequest:

    def __init__(self, rr_resp):
        self.resource = parse_resource(rr_resp.get('capability'))
        self.num_containers = rr_resp.get('numContainers')
        self.partition = rr_resp.get('nodeLabelExpression')
        self.priority = rr_resp.get('priority')
        if isinstance(self.priority, dict):
            self.priority = self.priority.get('priority')
        self.resource_name = rr_resp.get('resourceName')
        self.allocation_request_id = rr_resp.get('allocationRequestId')
        self.relax_locality = rr_resp.get('relaxLocality')


class Node:

    def __init__(self, info_dict):
        self.__info_dict = info_dict

    def get_id(self):
        return self.__info_dict.get('id')

    def get_state(self):
        return self.__info_dict.get('state')

    def get_partition(self):
        return self.__info_dict.get('nodeLabels')[0] if self.__info_dict.get('nodeLabels') is not None else ''

    def get_used_resource(self):
        return self.__info_dict.get('usedMemoryMB'), self.__info_dict.get('usedVirtualCores')

    def get_available_resource(self):
        return self.__info_dict.get('availMemoryMB'), self.__info_dict.get('availableVirtualCores')

    def get_total_resource(self):
        return common_util.add_tuple_by_indexes(self.get_used_resource(), self.get_available_resource())

    def is_running(self):
        return self.get_state() == 'RUNNING'

    def get_used_ratio(self):
        return common_util.divide_tuple_by_indexes(self.get_used_resource(), self.get_total_resource())

    def get_http_address(self):
        return self.__info_dict.get('nodeHTTPAddress')

    def get_num_containers(self):
        return self.__info_dict.get('numContainers')

    def get_last_health_update(self):
        timestamp = self.__info_dict.get('lastHealthUpdate')
        if timestamp is not None and isinstance(timestamp, int):
            return common_util.timestamp_to_str(timestamp/1000)
        return ''

    def get_health_report(self):
        return self.__info_dict.get('healthReport')

    def get_resource_utilization(self):
        return self.__info_dict.get('resourceUtilization')


class SchedulerActivities:

    def __init__(self, response_obj):
        self.__timestamp = response_obj.get('timestamp') / 1000.0
        self.__datetime = response_obj.get('dateTime')
        self.__allocations = list()
        for allocation in response_obj.get('allocations'):
            partition = allocation.get('partition')
            final_state = allocation.get('finalAllocationState')
            queue_activities = self.parse_queue_activities(allocation.get('root'))
            self.__allocations.append(ActivitiesInSingleRound(partition, final_state, queue_activities))

    def parse_queue_activities(self, queue_info):
        name = queue_info.get('name')
        allocation_state = queue_info.get('allocationState')
        diagnostic = queue_info.get('diagnostic')
        activity = Activity(name, allocation_state, diagnostic)
        children = queue_info.get('children')
        if children is not None:
            for child_info in children:
                child_activity = self.parse_queue_activities(child_info)
                activity.add_child(child_activity)
        return activity

    def get_activities(self, queue_path, app_id=None, partition=None):
        rst = list()
        for allocation in self.__allocations:
            if partition is not None and partition != allocation.partition:
                continue
            target_names = queue_path.split('.')
            if app_id is not None:
                target_names.append(app_id)
            found_activity = allocation.get_activity(target_names)
            if found_activity is not None:
                rst.append(found_activity)
        logging.debug("found {} matched activities from {} allocations".format(len(rst), len(self.__allocations)))
        return rst

    def get_activities_columns_rows(self, skip_no_requirement=False):
        rows = list()
        for index, allocation in enumerate(self.__allocations):
            row_data = [allocation.partition if allocation.partition != '' else 'DEFAULT_PARTITION',
                        'allocation-{}({})'.format(index, allocation.final_state)]
            allocation.activity.parse_rows(row_data, rows, skip_no_requirement)
        if len(rows) == 0:
            return list(), rows
        longest_columns = max(rows, key=len)
        max_num_of_columns = len(longest_columns)
        formatted_rows = list(map(lambda x: x + [''] * (max_num_of_columns - len(x)), rows))
        formatted_rows = common_util.dedup_rows(formatted_rows, [0, 1, 2, 3])
        columns = ['partition', 'allocation_id']
        formatted_columns = columns
        for i in range(0, max_num_of_columns - len(columns)):
            formatted_columns.append('level-{}'.format(i))
        return formatted_columns, formatted_rows

    def get_datetime(self):
        return self.__datetime


class ActivitiesInSingleRound:

    def __init__(self, partition, final_allocation_state, activity):
        self.partition = partition
        self.final_state = final_allocation_state
        self.activity = activity

    def get_activity(self, target_names):
        cur_activity = None
        for name in target_names:
            if cur_activity is None:
                if name == self.activity.name:
                    cur_activity = self.activity
                    continue
                else:
                    return None
            next_activity = cur_activity.get_child(name)
            if next_activity is None:
                return None
            cur_activity = next_activity
        return cur_activity


class Activity:

    def __init__(self, name, allocation_state, diagnostic):
        self.name = name
        self.allocation_state = allocation_state
        self.diagnostic = diagnostic
        self.children = OrderedDict()

    def add_child(self, activity):
        self.children[activity.name] = activity

    def get_child(self, child_name):
        return self.children.get(child_name)

    def parse_rows(self, row_data, rows, skip_no_requirement):
        cur_key = '{} ({}){}'.format(self.name, self.allocation_state,
                                     ': ' + self.diagnostic if self.diagnostic is not None else '')
        if self.children is not None and len(self.children) > 0:
            for child in self.children.values():
                child.parse_rows(row_data + [cur_key], rows, skip_no_requirement)
        else:
            if skip_no_requirement and self.diagnostic is not None and self.diagnostic.find(
                    'does not need more resource') != -1:
                return
            rows.append(row_data + [cur_key])

    def get_columns_rows(self):
        rows = list()
        self.parse_rows([], rows, False)
        if len(rows) == 0:
            return list(), rows
        max_num_of_columns = len(max(rows, key=len))
        formatted_rows = list(map(lambda x: x + [''] * (max_num_of_columns - len(x)), rows))
        formatted_rows = common_util.dedup_rows(formatted_rows, [0, 1, 2, 3])
        formatted_columns = list()
        for i in range(0, max_num_of_columns):
            formatted_columns.append('level-{}'.format(i))
        return formatted_columns, formatted_rows

    def __str__(self):
        return self.__repr__()


class ComponentHealthReport:

    def __init__(self, name, healthy, work_state, update_timestamp, diagnostics, metrics):
        self.__name = name
        self.__healthy = healthy
        self.__work_state = work_state
        self.__update_timestamp = update_timestamp
        self.__diagnostics = diagnostics
        self.__metrics = dict()
        if metrics is not None:
            for metric in common_util.confirmed_list(metrics):
                self.__metrics[metric.get('key')] = metric.get('value')

    def get_name(self):
        return self.__name

    def is_healthy(self):
        return self.__healthy

    def get_work_state(self):
        return self.__work_state

    def get_update_timestamp(self):
        return self.__update_timestamp

    def get_diagnostics(self):
        return self.__diagnostics

    def get_metrics(self):
        return self.__metrics

    def get_metrics_info(self, delimiter='\n'):
        metric_infos = list()
        for key, value in self.__metrics.items():
            metric_infos.append("{}: {}".format(key, value))
        return delimiter.join(metric_infos)

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        data = {"name": self.__name, "healthy": self.__healthy, "work_state": self.__work_state,
                "update_timestamp": self.__update_timestamp}
        if self.__diagnostics is not None:
            data["diagnostics"] = self.__diagnostics
        if self.__metrics is not None:
            data["metrics"] = self.__metrics
        return json.dumps(data)


def load_queues(root_queue):
    queues = dict()
    __recursively_load_queues(root_queue, queues)
    return queues


def __recursively_load_queues(current_queue, queues):
    queues[current_queue.get_name()] = current_queue
    if current_queue.get_child_queues() is not None:
        for child_queue in current_queue.get_child_queues().values():
            __recursively_load_queues(child_queue, queues)
