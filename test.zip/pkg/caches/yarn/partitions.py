from pkg.framework import interface
from pkg.caches.yarn.common import *
import logging


class YARNPartitionsCache(interface.Cache):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__partition_info_dict = None

    def load(self):
        self.__partition_info_dict = dict()
        yarn_basic_info = get_required_yarn_basic_info(self.context)
        # add default partition
        default_partition = Partition('', False)
        self.__partition_info_dict[default_partition.get_name()] = default_partition
        # load non-default partitions
        source_data = yarn_basic_info.data_source.get_data(SOURCE_DATA_KEY_NODE_LABELS)
        resp_obj = common_util.parse_json_str(source_data.content)
        if resp_obj is not None:
            partitions_info = resp_obj.get('nodeLabelInfo')
            if isinstance(partitions_info, list):
                for partition_info in partitions_info:
                    self.__parse_partition_info(partition_info)
            elif isinstance(partitions_info, dict):
                self.__parse_partition_info(partitions_info)
        # mark loaded
        self.loaded = True
        logging.debug("loaded {} partitions {} for {}".format(
            len(self.__partition_info_dict), list(self.__partition_info_dict.keys()), self.get_key()))

    def __parse_partition_info(self, partition_info):
        partition = Partition(partition_info.get('name'),
                              True if partition_info.get('exclusivity') == 'true' else False)
        self.__partition_info_dict[partition.get_name()] = partition

    # return partitions info dict if no keys
    # return specified partition info if given just 1 key (seem as requested partition name)
    def get_data(self, *keys):
        if len(keys) > 1:
            raise RuntimeError(
                'failed to get partition info from yarn partitions cache with multiple keys: {}'.format(keys))
        if not self.loaded:
            self.load()
        if len(keys) == 0:
            return self.__partition_info_dict
        else:
            return self.__partition_info_dict.get(keys[0])
