from pkg.framework import cache
from pkg.caches.yarn.common import *
from pkg.caches.yarn import data_sources


class YARNLogsCache(cache.ReusableCache):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__logs = None
        self.__old_parse_pattern = \
            r'HREF=["]?([^"]+)"\>([\S+-.]+)&nbsp;[</A>]*</TD><TD ALIGN=right>(\S+) bytes&nbsp;</TD><TD>([\w| ,:]+)'
        self.__new_parse_pattern = \
            r'href=["]?([^"]+)"\>([\S+-.]+)&nbsp;</a></td><td [\S+]*>([\w| ,:]+)&nbsp;</td>' \
            r'<td [\S+]*>(\S+) bytes&nbsp;</td>'
        self.__yarn_basic_info = None

    def __get_yarn_basic_info(self):
        if self.__yarn_basic_info is None:
            self.__yarn_basic_info = get_required_yarn_basic_info(self.context)
        return self.__yarn_basic_info

    def get_serializable_data(self):
        yarn_basic_info = self.__get_yarn_basic_info()
        if not isinstance(yarn_basic_info.data_source, data_sources.RestApiSource):
            raise RuntimeError("unsupported cache '{}' for non-RESTFul source".format(CACHE_KEY_YARN_LOGS))
        logs_resp_content = yarn_basic_info.data_source.get_data(SOURCE_DATA_KEY_LOGS)
        return logs_resp_content.content

    def load_from_serializable_data(self, data):
        yarn_basic_info = self.__get_yarn_basic_info()
        if data.find('thead') == -1:
            pattern = self.__old_parse_pattern
            name_index, url_index, size_index, update_time_index = 1, 0, 2, 3
        else:
            pattern = self.__new_parse_pattern
            name_index, url_index, size_index, update_time_index = 1, 0, 3, 2
        logs_info = re.findall(pattern, data)
        self.__logs = OrderedDict()
        for log_info in logs_info:
            log_name = log_info[name_index]
            self.__logs[log_name] = {COLUMN_KEY_NAME: log_name,
                                     COLUMN_KEY_URL: "http://{}{}".format(
                                         yarn_basic_info.data_source.get_webapp_address(),
                                         log_info[url_index]),
                                     COLUMN_KEY_SIZE: int(log_info[size_index].replace(',', '')),
                                     COLUMN_KEY_UPDATE_TIME: log_info[update_time_index]}
        logging.debug("loaded {} logs for {}".format(len(self.__logs), self.get_key()))

    # return logs info dict if no keys
    # return specified log if given just 1 key (seem as requested log name)
    def get_data(self, *keys):
        if len(keys) > 1:
            raise RuntimeError('failed to get data from yarn logs cache with multiple keys: {}'.format(keys))
        if self.should_reload():
            self.load()
        if len(keys) == 0:
            return self.__logs
        return self.__logs.get(keys[0])
