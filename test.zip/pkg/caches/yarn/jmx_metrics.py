from pkg.framework import interface
from pkg.caches.yarn.common import *
import logging


class YARNMetricsCache(interface.Cache):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__metrics = None

    def load(self):
        yarn_basic_info = get_required_yarn_basic_info(self.context)
        # load metrics
        source_data = yarn_basic_info.data_source.get_data(SOURCE_DATA_KEY_RM_METRICS)
        resp_obj = common_util.parse_json_str(source_data.content)
        self.__metrics = dict()
        if resp_obj is not None:
            beans = resp_obj.get('beans')
            for bean in beans:
                self.__metrics[bean['name']] = bean
        self.loaded = True
        logging.debug("loaded jmx metrics for {}".format(self.get_key()))

    # return all metrics without any keys
    # return specified metrics if given 1 key which can be seem as the requested bean name
    def get_data(self, *keys):
        if len(keys) > 1:
            raise RuntimeError('failed to get data from yarn jmx metrics cache with multiple keys: {}'.format(keys))
        if not self.loaded:
            self.load()
        if len(keys) == 0:
            return self.__metrics
        return self.__metrics.get(keys[0])
