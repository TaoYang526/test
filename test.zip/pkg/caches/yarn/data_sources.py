from abc import ABCMeta, abstractmethod
from pkg.constants import *
from pkg.utils import rest_util, common_util
from pkg.caches.yarn import common
import logging
import zlib
import base64
import json
from pkg.utils import io_util
import os


class Source(metaclass=ABCMeta):

    # return tuple(data, data_timestamp)
    def get_data(self, key, query):
        pass


class MockSource(Source):

    def __init__(self, mock_data_dir):
        self.__mock_data_dir = mock_data_dir

    def get_data(self, key, additional_query=None):
        data_file = os.path.join(self.__mock_data_dir, key)
        data = io_util.read_file(data_file)
        return SourceData(data, '', common_util.get_timestamp())


class RestApiSource(Source):

    def __init__(self, url_type, webapp_address, http_anonymous_enabled, cluster_id, data_backup_dir=None):
        self.__url_type = url_type
        self.__webapp_address = webapp_address
        self.__http_anonymous_enabled = http_anonymous_enabled
        self.__cluster_id = cluster_id
        self.__data_backup_dir = data_backup_dir

    def get_webapp_address(self):
        return self.__webapp_address

    def get_data(self, key, additional_query=None):
        url = REST_API_URL_TEMPLATE_MAPPING.get(key)
        if url is None:
            logging.error("undefined key {} in RestApiSource, valid keys: {}".format(
                key, REST_API_URL_TEMPLATE_MAPPING.keys()))
            return None, None
        url = rest_util.generate_url(url, self.__url_type,
                                     self.__webapp_address,
                                     self.__http_anonymous_enabled)
        data = rest_util.RestClient().url(url).header(REQUEST_HEADER).get_response_body_content()
        hostname = self.__webapp_address.split(':')[0]
        if self.__data_backup_dir is not None and self.__data_backup_dir != "":
            try_backup_data(self.__data_backup_dir, self.__cluster_id, key, data)
        return SourceData(data, hostname, common_util.get_timestamp())

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return json.dumps({'url_type': self.__url_type, 'webapp_address': self.__webapp_address,
                           "http_anonymous_enabled": self.__http_anonymous_enabled})


class SLSSource(Source):

    def __init__(self, context, sls_source, domain, cluster_id, data_backup_dir=None):
        self.__context = context
        self.__sls_source = sls_source
        self.__domain = domain
        self.__cluster_id = cluster_id
        self.__data_backup_dir = data_backup_dir

    def get_data(self, key, additional_query=None):
        query = "{} and {}".format(key, self.__cluster_id)
        if additional_query is not None and additional_query != '':
            # replace additional query
            replace_query = self.__context.get_env_value(ENV_KEY_REPLACE_QUERY)
            if replace_query:
                replace_items = replace_query.split(',')
                for replace_item in replace_items:
                    tmp_array = replace_item.split('=')
                    if len(tmp_array) == 2 and additional_query.find(tmp_array[0]) != -1:
                        additional_query = additional_query.replace(tmp_array[0], tmp_array[1])
                        logging.info("replaced additional_query: {}".format(additional_query))
            # add prefix for additional query
            additional_query_prefix = self.__context.get_env_value(ENV_KEY_ADDITIONAL_QUERY_PREFIX)
            if additional_query_prefix is not None and additional_query_prefix != '':
                additional_query = "{}{}".format(additional_query_prefix, additional_query)
            query = "{} and {}".format(query, additional_query)
        sls_client_cache = common.get_required_cache(self.__context, CACHE_KEY_SLS_CLIENT)
        logs = sls_client_cache.get_data(self.__sls_source, '30 min ago', 'now', self.__domain, None, None, topic=None,
                                         query=query, size=1, reverse=True)
        if len(logs) != 1:
            raise RuntimeError("failed to get data from sls source, domain={}, query='{}'".format(self.__domain, query))
        log_content = logs[0].get_contents().get('content')
        log_content_obj = common_util.parse_json_str(log_content)
        # decode content
        content = log_content_obj.get('content')
        decoded64 = base64.b64decode(content)
        origin_content = zlib.decompress(decoded64)
        origin_content = str(origin_content, 'UTF-8')
        if self.__data_backup_dir is not None and self.__data_backup_dir != "":
            try_backup_data(self.__data_backup_dir, self.__cluster_id, key, origin_content)
        return SourceData(origin_content, log_content_obj.get('timestamp'),
                          log_content_obj.get('hostname'))

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return json.dumps({'sls_source': self.__sls_source, 'domain': self.__domain, "cluster_id": self.__cluster_id})


class SourceData:

    def __init__(self, content, timestamp, hostname=None):
        self.content = content
        self.timestamp = timestamp
        self.hostname = hostname


def try_backup_data(data_backup_dir, cluster_id, key, data):
    if not os.path.exists(data_backup_dir):
        logging.warning("skip backing up data {} since backup dir {} doesn't exist".format(key, data_backup_dir))
        return
    sub_dir = os.path.join(data_backup_dir, cluster_id)
    if not os.path.exists(sub_dir):
        os.mkdir(sub_dir)
    backup_file = os.path.join(sub_dir, key)
    io_util.write_file(backup_file, data)
    logging.debug("backed up data {} into file: {}".format(key, backup_file))
