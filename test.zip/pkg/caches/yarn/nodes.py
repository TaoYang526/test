from pkg.framework import interface
from pkg.caches.yarn.common import *
import logging


class YARNNodesCache(interface.Cache):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__nodes = None

    def load(self):
        yarn_basic_info = get_required_yarn_basic_info(self.context)
        # load nodes
        source_data = yarn_basic_info.data_source.get_data(SOURCE_DATA_KEY_NODES)
        resp_obj = common_util.parse_json_str(source_data.content)
        self.__nodes = dict()
        if resp_obj is not None:
            nodes_info = resp_obj.get('nodes').get('node')
            for node_info in nodes_info:
                node = Node(node_info)
                self.__nodes[node.get_id()] = node
        # mark loaded
        self.loaded = True
        logging.debug("loaded {} nodes for {}".format(len(self.__nodes), self.get_key()))

    # return all nodes without any keys
    # return specified node if given 1 key which can be seem as the requested node ID
    def get_data(self, *keys):
        if len(keys) > 1:
            raise RuntimeError('failed to get data from yarn nodes cache with multiple keys: {}'.format(keys))
        if not self.loaded:
            self.load()
        if len(keys) == 0:
            return self.__nodes
        return self.__nodes.get(keys[0])
