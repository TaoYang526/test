from pkg.framework import interface
from pkg.caches.yarn.common import *
import logging


class YARNQueuesCache(interface.Cache):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__queues = None

    def load(self):
        yarn_basic_info = get_required_yarn_basic_info(self.context)
        if not yarn_basic_info.is_capacity_scheduler():
            raise RuntimeError("can't load queues cache since only CapacityScheduler is supported!")
        # load hierarchical queues
        source_data = yarn_basic_info.data_source.get_data(SOURCE_DATA_KEY_QUEUES)
        root_queue_dict = common_util.parse_json_str(source_data.content)
        for key in ROOT_NAMES_YARN_SCHEDULER:
            root_queue_dict = root_queue_dict.get(key)
        root_queue = Queue(None, root_queue_dict)
        self.__queues = load_queues(root_queue)
        self.loaded = True
        logging.debug("loaded {} queues {} for {}".format(
            len(self.__queues), list(self.__queues.keys()), self.get_key()))

    # return queues info dict if no keys
    # return specified queue if given just 1 key (seem as requested queue name)
    def get_data(self, *keys):
        if len(keys) > 1:
            raise RuntimeError('failed to get data from yarn queues cache with multiple keys: {}'.format(keys))
        if not self.loaded:
            self.load()
        if len(keys) == 0:
            return self.__queues
        return self.__queues.get(keys[0])
