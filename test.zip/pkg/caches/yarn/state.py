import os

from pkg.framework import interface
from pkg.caches.yarn.common import *
from pkg.caches.yarn import data_sources
from pkg.constants import *
from pkg.utils import common_util, rest_util
import logging


class YARNStateCache(interface.Cache):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__data = None

    def load(self):
        self.__data = dict()
        local_conf_cache = self.context.get_cache(CACHE_KEY_CLUSTER_LOCAL_CONF)
        if local_conf_cache is None:
            raise ConfError(
                "failed to find cache {} while loading cache {}".format(CACHE_KEY_CLUSTER_LOCAL_CONF, self.get_key()))
        configured_http_anonymous_enabled = local_conf_cache.get_data(
            FILE_NAME_CORE_SITE, 'hadoop.http.authentication.simple.anonymous.allowed')
        mock_data_dir = self.context.get_env_value(ENV_KEY_MOCK_DATA_DIR)
        if mock_data_dir is not None and mock_data_dir != "":
            if not os.path.isabs(mock_data_dir):
                mock_data_dir = os.path.join(self.context.get_executing_path(), mock_data_dir)
                if not os.path.exists(mock_data_dir):
                    raise ConfError("specified mock data dir ({}) configured by env {} not found".format(
                        mock_data_dir, ENV_KEY_MOCK_DATA_DIR))
            yarn_basic_info, rm_states = self.__load_from_mock_data(mock_data_dir)
        elif configured_http_anonymous_enabled is None:
            yarn_basic_info, rm_states = self.__load_from_sls()
        else:
            yarn_basic_info, rm_states = self.__load_from_rest_api(local_conf_cache)
        # update data
        self.__data[YARN_STATE_KEY_YARN_BASIC_INFO] = yarn_basic_info
        self.__data[YARN_STATE_KEY_RM_STATES] = rm_states
        self.loaded = True
        logging.debug("loaded {}".format(self.get_key()))

    def __load_from_mock_data(self, mock_data_dir):
        data_source = data_sources.MockSource(mock_data_dir)
        return self.__load_from_data(data_source)

    def __load_from_sls(self):
        # init data source
        sls_snapshot_source = self.context.get_env_value(ENV_KEY_SNAPSHOT_LOG_SOURCE)
        if sls_snapshot_source is None:
            raise ConfError(
                "'{}' is required in env but not found for SLS source!".format(ENV_KEY_SNAPSHOT_LOG_SOURCE))
        domain = self.context.get_env_value(ENV_KEY_DOMAIN)
        if domain is None:
            raise ConfError("'{}' is required in env but not found for SLS source!".format(ENV_KEY_DOMAIN))
        cluster_id = self.context.get_env_value(ENV_KEY_CLUSTER_ID)
        if cluster_id is None:
            raise ConfError("'{}' is required in env but not found for SLS source!".format(ENV_KEY_CLUSTER_ID))
        data_backup_dir = self.context.get_conf().get(CONF_KEY_DATA_BACKUP_DIR)
        data_source = data_sources.SLSSource(self.context, sls_snapshot_source, domain, cluster_id,
                                             data_backup_dir=data_backup_dir)
        return self.__load_from_data(data_source)

    def __load_from_data(self, data_source):
        # init conf
        conf_list = get_conf_list(data_source)
        conf_dict = dict(map(lambda x: [x['key'], x['value']], conf_list))
        common_util.format_conf_dict(conf_dict, conf_dict)
        ha_enabled = conf_dict.get('yarn.resourcemanager.ha.enabled') == 'true'
        rm_states = list()
        if ha_enabled:
            rm_ids = conf_dict.get('yarn.resourcemanager.ha.rm-ids').split(',')
            for rm_id in rm_ids:
                rm_hostname = conf_dict.get('yarn.resourcemanager.hostname.{}'.format(rm_id))
                rm_state = RMState(rm_id, rm_hostname, data_source)
                if rm_state.is_active():
                    self.__data[YARN_STATE_KEY_ACTIVE_RM_STATE] = rm_state
                rm_states.append(rm_state)
        else:
            webapp_address = conf_dict.get('yarn.resourcemanager.address')
            rm_hostname = webapp_address.split(':')[0]
            rm_state = RMState('', rm_hostname, data_source)
            if rm_state.is_active():
                self.__data[YARN_STATE_KEY_ACTIVE_RM_STATE] = rm_state
            rm_states.append(rm_state)
        configured_scheduler_class = conf_dict.get('yarn.resourcemanager.scheduler.class')
        return YARNBasicInfo(configured_scheduler_class, ha_enabled, data_source), rm_states

    def __load_from_rest_api(self, local_conf_cache):
        configured_http_anonymous_enabled = local_conf_cache.get_data(
            FILE_NAME_CORE_SITE, 'hadoop.http.authentication.simple.anonymous.allowed')
        http_anonymous_enabled = not (configured_http_anonymous_enabled == 'false')
        ha_enabled = local_conf_cache.get_data(FILE_NAME_YARN_SITE, 'yarn.resourcemanager.ha.enabled') == 'true'
        use_https = local_conf_cache.get_data(FILE_NAME_YARN_SITE, 'yarn.http.policy') == 'HTTPS_ONLY'
        configured_scheduler_class = local_conf_cache.get_data(FILE_NAME_YARN_SITE,
                                                               'yarn.resourcemanager.scheduler.class')
        url_type = rest_util.get_url_type(use_https)
        if use_https:
            webapp_address_conf_prefix = 'yarn.resourcemanager.webapp.https.address'
        else:
            webapp_address_conf_prefix = 'yarn.resourcemanager.webapp.address'
        rm_states = list()
        active_data_source = None
        cluster_id = self.context.get_env_value(ENV_KEY_CLUSTER_ID)
        data_backup_dir = self.context.get_conf().get(CONF_KEY_DATA_BACKUP_DIR)
        if ha_enabled:
            rm_ids = local_conf_cache.get_data(FILE_NAME_YARN_SITE, 'yarn.resourcemanager.ha.rm-ids').split(',')
            for rm_id in rm_ids:
                rm_webapp_address = local_conf_cache.get_data(FILE_NAME_YARN_SITE,
                                                              '{}.{}'.format(webapp_address_conf_prefix, rm_id))
                rm_hostname = rm_webapp_address.split(':')[0]
                data_source = data_sources.RestApiSource(url_type, rm_webapp_address, http_anonymous_enabled,
                                                         cluster_id, data_backup_dir=data_backup_dir)
                rm_state = RMState(rm_id, rm_hostname, data_source)
                if rm_state.is_active():
                    active_data_source = data_source
                    self.__data[YARN_STATE_KEY_ACTIVE_RM_STATE] = rm_state
                rm_states.append(rm_state)
        else:
            rm_webapp_address = local_conf_cache.get_data(FILE_NAME_YARN_SITE, webapp_address_conf_prefix)
            rm_hostname = rm_webapp_address.split(':')[0]
            data_source = data_sources.RestApiSource(url_type, rm_webapp_address, http_anonymous_enabled,
                                                     cluster_id, data_backup_dir=data_backup_dir)
            rm_state = RMState('', rm_hostname, data_source)
            if rm_state.is_active():
                active_data_source = data_source
                self.__data[YARN_STATE_KEY_ACTIVE_RM_STATE] = rm_state
            rm_states.append(rm_state)
        yarn_basic_info = YARNBasicInfo(configured_scheduler_class, ha_enabled, active_data_source)
        return yarn_basic_info, rm_states

    def get_data(self, *keys):
        if len(keys) > 1:
            raise RuntimeError('failed to get data from yarn state cache with multiple keys: {}'.format(keys))
        if not self.loaded:
            self.load()
        return self.__data.get(keys[0])
