import time

from pkg.framework import interface
from pkg.caches.yarn.common import *
from pkg.caches.yarn import data_sources
import logging


class YARNSchedulerActivitiesCache(interface.Cache):

    def __init__(self, key, context, ttl_seconds):
        super().__init__(key, context)
        self.__scheduler_activities = None
        self.__update_ts = -1
        self.__ttl_seconds = ttl_seconds
        self.__yarn_basic_info = None

    def load(self):
        self.__yarn_basic_info = get_required_yarn_basic_info(self.context)
        if not self.__yarn_basic_info.is_capacity_scheduler():
            logging.info("skip loading scheduler activities cache since it's not supported for this cluster")
            return
        if not isinstance(self.__yarn_basic_info.data_source, data_sources.RestApiSource):
            raise RuntimeError(
                "unsupported cache '{}' for non-RESTFul source".format(CACHE_KEY_YARN_SCHEDULER_ACTIVITIES))
        # load scheduler activities
        try:
            while True:
                source_data = self.__yarn_basic_info.data_source.get_data(SOURCE_DATA_KEY_SCHEDULER_ACTIVITIES)
                resp_obj = common_util.parse_json_str(source_data.content)
                if resp_obj is not None:
                    activities = resp_obj.get('activities')
                    if activities.get('diagnostic') is not None and activities.get(
                            'diagnostic') == 'waiting for next allocation':
                        continue
                    timestamp = activities.get('timestamp')
                    datetime = activities.get('dateTime')
                    cur_timestamp = common_util.get_timestamp()
                    if cur_timestamp * 1000 - timestamp < self.__ttl_seconds * 1000:
                        self.__scheduler_activities = SchedulerActivities(activities)
                        self.__update_ts = cur_timestamp
                        break
                    logging.info("retry after getting outdated scheduler activities: datetime={},"
                                 " elapse_seconds={}".format(datetime, round(cur_timestamp - timestamp / 1000, 3)))
                else:
                    logging.error("failed to get scheduler activities, response={}".format(resp_obj))
                time.sleep(0.1)
        except Exception as ex:
            logging.error(
                "skip loading scheduler activities cache since it's not support for current cluster: {}".format(ex))
        self.loaded = True
        logging.debug("loaded scheduler activities for {}".format(self.get_key()))

    # return all activities without any keys
    # return specified activities if given 1 key which can be seem as the query object,
    #    format example: {'queue_path':'root.default', 'app_id':'application_1612518732138_855664', partition=''}
    def get_data(self, *keys):
        if len(keys) > 1:
            raise RuntimeError(
                'failed to get data from yarn scheduler activities cache with multiple keys: {}'.format(keys))
        if not self.loaded or common_util.get_timestamp() - self.__update_ts >= self.__ttl_seconds:
            self.load()
        if not self.__yarn_basic_info.is_capacity_scheduler():
            return None
        if len(keys) == 0:
            return self.__scheduler_activities
        if self.__scheduler_activities is None:
            return list()
        return self.__scheduler_activities.get_activities(**keys[0])
