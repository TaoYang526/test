import time

from pkg.framework import interface
from pkg.caches.yarn.common import *
import logging


class YARNConfCache(interface.Cache):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__resource_conf_dict = None

    def load(self):
        # load yarn conf
        active_rm_state = get_active_rm_state(self.context)
        conf_list = active_rm_state.get_conf_list()
        resource_conf_dict = dict()
        for conf in conf_list:
            resource = conf.get('resource')
            resource_conf_items = common_util.get_or_new_value(resource_conf_dict, resource, list)
            resource_conf_items.append((conf.get('key'), conf.get('value')))

        # load scheduler conf for capacity-scheduler
        yarn_basic_info = get_required_yarn_basic_info(self.context)
        if yarn_basic_info.is_capacity_scheduler():
            try:
                source_data = yarn_basic_info.data_source.get_data(SOURCE_DATA_KEY_SCHEDULER_CONF)
                resp_obj = common_util.parse_json_str(source_data.content)
                capacity_scheduler_conf_list = list()
                scheduler_conf_items = resp_obj.get('items')
                for conf_item in scheduler_conf_items:
                    capacity_scheduler_conf_list.append((conf_item.get('key'), conf_item.get('value')))
                resource_conf_dict[CAPACITY_SCHEDULER_CONF_NAME] = capacity_scheduler_conf_list
            except Exception as ex:
                logging.debug("failed to load scheduler conf, error: {}".format(str(ex)))
        self.__resource_conf_dict = resource_conf_dict
        self.loaded = True
        logging.debug("loaded cache for {}".format(self.get_key()))

    def get_data(self):
        if not self.loaded:
            self.load()
        return self.__resource_conf_dict
