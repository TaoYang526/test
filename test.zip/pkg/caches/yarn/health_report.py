from pkg.framework import cache
from pkg.caches.yarn.common import *
import logging


class YARNHealthReportCache(cache.GenericCache):

    def __init__(self, key, context, ttl_seconds=-1):
        super().__init__(key, context, ttl_seconds)
        self.__components = None
        self.__health_report_enabled_conf_key = 'yarn.resourcemanager.health-check.enabled'

    def load(self):
        yarn_basic_info = get_required_yarn_basic_info(self.context)
        active_rm_state = get_active_rm_state(self.context)
        conf_dict = active_rm_state.get_conf_dict()
        health_report_enabled = conf_dict.get(self.__health_report_enabled_conf_key)
        if health_report_enabled != 'true':
            logging.debug("skip loading health report since not enabled: {}={}".format(
                self.__health_report_enabled_conf_key, self.get_key()))
            self.trigger_loaded()
            return
        # load health report
        source_data = yarn_basic_info.data_source.get_data(SOURCE_DATA_KEY_RM_HEALTH_REPORT)
        resp_obj = common_util.parse_json_str(source_data.content)
        self.__components = dict()
        if resp_obj is not None:
            components = resp_obj.get('componentHealth')
            for component in components:
                name = component.get('name')
                metrics = component.get('metrics')
                if metrics is not None:
                    metrics = metrics.get('entry')
                self.__components[name] = ComponentHealthReport(
                    name, component.get('healthy'), component.get('workState'), component.get('updateTime'),
                    component.get('diagnostics'), metrics)
        self.trigger_loaded()
        logging.debug("loaded health report for {}".format(self.get_key()))

    def get_data(self, *keys):
        if len(keys) > 1:
            raise RuntimeError(
                'failed to get data from yarn health report cache with multiple keys: {}'.format(keys))
        if self.should_reload():
            self.load()
        if len(keys) == 0:
            return self.__components
        if self.__components is None:
            return None
        return self.__components.get(**keys[0])
