from pkg.framework import interface, cache
from pkg.caches.yarn.common import *


class YARNAppsCache(cache.ReusableCache):

    def __init__(self, key, context, ttl_seconds=60, reusable=True):
        super().__init__(key, context, ttl_seconds=ttl_seconds, reusable=reusable)
        self.__apps = None

    def get_serializable_data(self):
        yarn_basic_info = get_required_yarn_basic_info(self.context)
        source_data = yarn_basic_info.data_source.get_data(SOURCE_DATA_KEY_APPS)
        apps_resp = common_util.parse_json_str(source_data.content)
        for key in ROOT_NAMES_YARN_APPS:
            if key in apps_resp:
                apps_resp = apps_resp.get(key)
        return apps_resp

    def load_from_serializable_data(self, data):
        self.__apps = dict()
        for app_resp in data:
            app = App(app_resp)
            self.__apps[app.get_id()] = app
        logging.debug("loaded {} apps for {}".format(len(self.__apps), self.get_key()))

    # return apps info dict if no keys
    # return specified app if given just 1 key (seem as requested app id)
    def get_data(self, *keys):
        if len(keys) > 1:
            raise RuntimeError('failed to get data from yarn apps cache with multiple keys: {}'.format(keys))
        if self.should_reload():
            self.load()
        if len(keys) == 0:
            return self.__apps
        return self.__apps.get(keys[0])
