from pkg.framework import interface
import logging
from pkg.framework.error import *
from pkg.utils import sls_util


class SLSClientCache(interface.Cache):

    def __init__(self, key, context, access_keys=list(), sources=dict()):
        super().__init__(key, context)
        self.__domains = dict()
        for access_key in access_keys:
            access_key_id = access_key.get('access_key_id')
            access_key_secret = access_key.get('access_key_secret')
            if access_key_id is None or access_key_id == '' or access_key_secret is None or access_key_secret == '':
                raise ConfError("both access_key_id and access_key_secret are required for sls-client")
            for domain, infos in access_key.get('domains').items():
                project = infos.get('project')
                endpoint = infos.get('endpoint')
                self.__domains[domain] = (project, endpoint, access_key_id, access_key_secret)
        self.__sources = dict()
        for source_name, source_conf in sources.items():
            domain = source_conf.get('domain')
            self.__sources[source_name] = (domain, source_conf.get('log_store'))

    def load(self):
        pass

    def get_data(self, source, from_time, to_time, domain, project=None, log_store=None,
                 topic=None, query=None, offset=None, size=None, reverse=None):
        client, configured_project, configured_log_store = self.get_client(source, domain)
        project = configured_project if project is None else None
        log_store = configured_log_store if log_store is None else None
        target = sls_util.SLSTarget(project, log_store, from_time, to_time)
        target.set_topic(topic) if topic is not None else None
        target.set_query(query) if query is not None else None
        target.set_offset(offset) if offset is not None else None
        target.set_size(size) if size is not None else None
        target.set_reverse(reverse) if reverse is not None else None
        logging.debug("get logs by {}".format(target))
        return client.get_logs(target)

    # return sls client and configured project
    def get_client(self, source, domain):
        if source not in self.__sources.keys():
            raise ArgumentsError("Source {} not found, valid sources: {}".format(source, list(self.__sources.keys())))
        source_info = self.__sources.get(source)
        if domain is None and source_info[0] is not None:
            domain = source_info[0]
        configured_log_store = source_info[1]
        if domain is None or configured_log_store is None:
            raise ArgumentsError(
                "required fields not found! domain={}, log_store={}".format(domain, configured_log_store))
        domain_info = self.__domains.get(domain)
        if domain_info is None:
            raise ArgumentsError(
                "domain {} not found, configured domains: {}".format(domain, list(self.__domains.keys())))
        configured_project = domain_info[0]
        endpoint, access_key_id, access_key_secret = domain_info[1], domain_info[2], domain_info[3]
        client = sls_util.SLSClient(endpoint, access_key_id, access_key_secret)
        return client, configured_project, configured_log_store
