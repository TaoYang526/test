import copy
import logging
import os
from pkg.framework import *
from pkg.framework.error import *
from pkg.constants import *
from pkg.utils import io_util, common_util


class ClusterLocalConfCache(interface.Cache):

    def __init__(self, key, context, default_conf, default_env, clusters):
        super().__init__(key, context)
        self.__conf_dicts = None
        self.__flat_conf_dict = None
        self.__default_conf = default_conf
        self.__default_env = default_env
        self.__clusters_conf = clusters

    def load(self):
        if self.loaded:
            return
        self.__flat_conf_dict = dict()
        cluster_name = self.context.get_env_value(ENV_KEY_HADOOP_CLUSTER)
        if cluster_name is None:
            raise ArgumentsError("required environment variable 'HADOOP_CLUSTER' not found!")
        self.__load_cluster_conf(cluster_name)

    def __load_cluster_conf(self, cluster_name):
        cluster_conf = self.__clusters_conf.get(cluster_name)
        if cluster_conf is None:
            raise ConfError("failed to find configurations for specified cluster {}!".format(cluster_name))
        hadoop_conf_dir = cluster_conf.get('conf_dir')
        conf = cluster_conf.get('conf')
        if hadoop_conf_dir is not None:
            filter_file_names = cluster_conf.get('filter_file_names')
            if filter_file_names is None:
                raise ConfError("'filter_file_names' is required but not found for cluster {}".format(cluster_name))
            self.__conf_dicts = copy.deepcopy(self.__default_conf)
            for filter_file_name in filter_file_names:
                filter_file = os.path.join(hadoop_conf_dir, filter_file_name)
                if not os.path.exists(filter_file):
                    raise ConfError('required local configuration file {} does not exist!'.format(filter_file))
                conf_dict = io_util.read_xml_2_dict(filter_file)
                common_util.format_conf_dict(conf_dict, self.__flat_conf_dict)
                self.__conf_dicts[filter_file_name] = conf_dict
                self.__flat_conf_dict.update(conf_dict)
        elif conf is not None:
            self.__conf_dicts = copy.deepcopy(self.__default_conf)
            for file_name, configurations in conf.items():
                if file_name in self.__conf_dicts:
                    self.__conf_dicts[file_name].update(configurations)
                else:
                    self.__conf_dicts[file_name] = configurations
                self.__flat_conf_dict.update(configurations)
        env = cluster_conf.get(CONF_KEY_ENV)
        if env is not None:
            for env_key, env_value in env.items():
                self.context.add_env_if_absent(env_key, env_value)
        for env_key, env_value in self.__default_env.items():
            self.context.add_env_if_absent(env_key, env_value)
        self.loaded = True
        logging.debug("loaded {} for cluster {}".format(self.get_key(), cluster_name))

    def get_data(self, *keys):
        if not self.loaded:
            self.load()
        if len(keys) == 2:
            if self.__conf_dicts is None:
                return None
            filter_filename, conf_key = keys[0], keys[1]
            conf_dict = self.__conf_dicts.get(filter_filename)
            if conf_dict is not None:
                return conf_dict.get(conf_key)
        return None
