from pkg.framework.error import *


def get_required_cache(context, cache_key):
    cache = context.get_cache(cache_key)
    if cache is None:
        raise ConfError('failed to get cache {}'.format(cache_key))
    return cache


def get_required_checker(context, checker_key):
    checker = context.get_checker(checker_key)
    if checker is None:
        raise ConfError('failed to get checker {}, valid checkers: {}'.format(checker_key,
                                                                              list(context.get_checkers().keys())))
    return checker


def get_required_analyzer(context, analyzer_key):
    analyzer = context.get_analyzer(analyzer_key)
    if analyzer is None:
        raise ConfError('failed to get analyzer {}, valid analyzers: {}'.format(analyzer_key,
                                                                                list(context.get_analyzer().keys())))
    return analyzer


# parse log content from sls log instance
def parse_log_content(log):
    contents = log.get_contents()
    content = contents.get('content')
    if content:
        time = contents.get('time')
        if time is not None and not content.startswith(time):
            return "{}{}".format(time, content)
        return content
    return contents
