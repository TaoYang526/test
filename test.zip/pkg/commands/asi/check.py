from pkg.commands.generic import *
from pkg.caches.yarn.common import *


class CheckJob(GenericCmdHandler):

    def handle(self, job_id, from_time, to_time, size):
        job_checker = get_required_checker(self.context, CHECKER_KEY_ASI_FLINK_JOB)
        verification = job_checker.check(job_id, from_time, to_time, size)
        return "Report for job {}:\n{}".format(job_id, verification.get_report()), None
