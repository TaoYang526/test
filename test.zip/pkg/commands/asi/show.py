import logging

from pkg.commands.generic import *
from pkg.caches.common import *
import time
from pkg.analyzers.yarn.yarn_rm_log_info import *


class ShowEvents(GenericCmdHandler):

    def handle(self, _, name, content, log_level, reason, source, from_time, to_time, size, direct_query=None):
        cluster_local_conf_cache = get_required_cache(self.context, CACHE_KEY_CLUSTER_LOCAL_CONF)
        cluster_local_conf_cache.load()
        asi_event_log_analyzer = get_required_analyzer(self.context, ANALYZER_KEY_ASI_EVENT_LOG)
        event_infos = asi_event_log_analyzer.get_event_infos(
            name, content, log_level, reason, source, from_time, to_time, size, direct_query)
        if not event_infos:
            return None, None
        columns = [TIMESTAMP_KEY, LOG_LEVEL_KEY, REASON_KEY, SOURCE_KEY, CONTENT_KEY]
        format_fn_dict = {TIMESTAMP_KEY: lambda x: time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(x))}
        show_info = "========>result size: {}".format(len(event_infos))
        for key, event_info in event_infos.items():
            events = event_info.get(EVENTS_KEY)
            common_util.sort_by_key(events, TIMESTAMP_KEY)
            rows = common_util.get_rows(events, columns, format_fn_dict)
            table = common_util.generate_table(columns, rows)
            show_info += "\nresult: {}\n{}".format(key, table)
        return show_info, None


class ShowFlinkLogs(GenericCmdHandler):

    def handle(self, _, from_time, to_time, size, log_level, job_id, content, direct_query):
        cluster_local_conf_cache = get_required_cache(self.context, CACHE_KEY_CLUSTER_LOCAL_CONF)
        cluster_local_conf_cache.load()
        asi_flink_log_analyzer = get_required_analyzer(self.context, ANALYZER_KEY_ASI_FLINK_LOG)
        data = asi_flink_log_analyzer.get_data(job_id=job_id, log_level=log_level, content=content,
                                               from_time=from_time, to_time=to_time, size=size,
                                               direct_query=direct_query)
        if not data:
            return None, None
        show_info = "========>got {} jobs".format(len(data))
        for job_id, job_info in data.items():
            filtered_job_info = dict(filter(lambda elem: elem[0] != CHILDREN_KEY, job_info.items()))
            show_info += "\n========>jobId={}, jobInfo={}".format(job_id, filtered_job_info)
            columns = [TIMESTAMP_KEY, LOG_LEVEL_KEY, CONTENT_KEY]
            components = job_info[CHILDREN_KEY]
            format_fn_dict = {TIMESTAMP_KEY: lambda x: time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(x))}
            for component_key, logs in components.items():
                common_util.sort_by_key(logs, TIMESTAMP_KEY)
                rows = common_util.get_rows(logs, columns, format_fn_dict)
                table = common_util.generate_table(columns, rows)
                show_info += "\ncomponent: {}\n{}".format(component_key, table)
        return show_info, None
