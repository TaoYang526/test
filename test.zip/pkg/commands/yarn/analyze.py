from pkg.commands.generic import *
import pandas
import os
from pkg.analyzers.yarn.yarn_rm_log_info import *
from pkg.utils import rest_util


class ListRMLogs(GenericCmdHandler):

    def handle(self, _):
        logs_cache = self.context.get_cache(CACHE_KEY_YARN_LOGS)
        logs = logs_cache.get_data().values()
        if len(logs) == 0:
            logging.info("Logs not found!")
            exit(EXIT_CODE_NORMAL)
        columns = [COLUMN_KEY_NAME, COLUMN_KEY_SIZE, COLUMN_KEY_UPDATE_TIME, COLUMN_KEY_URL]
        df = common_util.get_data_frame(logs, columns)
        return "Logs:\n{}".format(df), None


class GetRMLog(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)

    def handle(self, log_name, output_file):
        logs_cache = self.context.get_cache(CACHE_KEY_YARN_LOGS)
        log = logs_cache.get_data(log_name)
        if log is None:
            return None, ArgumentsError("Log {} not found!".format(log_name))
        if output_file is None:
            return None, ArgumentsError("outputFile is required but not found!")
        log_url = log.get(COLUMN_KEY_URL)
        try:
            progress_bar = common_util.SimpleProgressBar("Download Progress: ", step=1, max=100)
            def show_progress(block_num, block_size, total_size):
                ratio = 100 * int(block_num) * int(block_size) / int(total_size)
                progress_bar.update(int(ratio))
            rest_util.retrieve_file(log_url, output_file, show_progress)
            return "Successfully download log {} to {}".format(log_name, output_file), None
        except Exception as ex:
            return None, ArgumentsError("failed to get log {}: {}".format(log_name, str(ex)))


class LoadLogs(GenericCmdHandler):

    def __init__(self, key, context, analyzer):
        super().__init__(key, context)
        self.__analyzer = analyzer

    def handle(self, _, file, from_time, to_time, keep_cache):
        if not os.path.isfile(file):
            return ArgumentsError('file {} not found or is not a file!'.format(file))
        cluster_local_conf = self.context.get_cache(CACHE_KEY_CLUSTER_LOCAL_CONF)
        cluster_local_conf.load()
        from_timestamp, to_timestamp = None, None
        if from_time is not None:
            from_timestamp = common_util.parse_timestamp(from_time, TO_SECOND_DATE_TIME_FORMAT)
        if to_time is not None:
            to_timestamp = common_util.parse_timestamp(to_time, TO_SECOND_DATE_TIME_FORMAT)
        if keep_cache:
            self.__analyzer.recover()
        loaded_count = self.__analyzer.process(file, from_timestamp=from_timestamp, to_timestamp=to_timestamp)
        self.__analyzer.persist()
        return "processed {} valid log messages".format(loaded_count), None


class LoadRMLogs(LoadLogs):

    def __init__(self, key, context):
        super().__init__(key, context, context.get_analyzer(ANALYZER_KEY_YARN_RM_LOG))


class GetSlowAppStates(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__analyzer = context.get_analyzer(ANALYZER_KEY_YARN_RM_LOG)

    def handle(self, _, slow_threshold_s):
        self.__analyzer.recover()
        slow_app_states = self.__analyzer.get_slow_app_states(int(slow_threshold_s))
        columns = ['AppID', 'Queue', 'SlowStates']
        rows = list()
        for app_id, slow_states_tuple in slow_app_states.items():
            slow_states = slow_states_tuple[0]
            app_state = slow_states_tuple[1]
            rows.append(
                [app_id, app_state.get_queue_name(), '\n'.join(list(map(lambda x: str(x), slow_states)))])
        table = common_util.generate_table(columns, rows)
        if len(rows) == 0:
            return "no slow app state found by slow threshold {}".format(slow_threshold_s), None
        else:
            return "Slow app states:\n{}".format(table), None


class GetAppStates(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__analyzer = context.get_analyzer(ANALYZER_KEY_YARN_RM_LOG)

    def handle(self, app_ids):
        if app_ids is None:
            return None, ArgumentsError("-appIds is required for this action")
        self.__analyzer.recover()
        output = []
        for app_id in app_ids:
            app_state = self.__analyzer.get_app_state(app_id)
            if app_state is None:
                logging.info("state not found for app {}".format(app_id))
                continue
            all_states_data = app_state.get_all_states_data()
            all_states_data = sorted(all_states_data, key=lambda x: x.get(START_TIMESTAMP_KEY))
            columns = [START_TIMESTAMP_KEY, ID_KEY, STATE_KEY, HOLD_SECONDS_KEY]
            df = common_util.get_data_frame(all_states_data, columns)
            df[START_TIME_KEY] = df[START_TIMESTAMP_KEY].apply(
                lambda x: common_util.timestamp_to_str(float(x), '%Y-%m-%d %H:%M:%S,%f'))
            # df['start_time_m'] = df['start_time'].apply(lambda x: x.rsplit(':', 1)[0])
            output.append("App state for {}:\n{}".format(app_id, df))
        return output, None


class GetAppScheduleInfos(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__analyzer = context.get_analyzer(ANALYZER_KEY_YARN_RM_LOG)

    def handle(self, app_ids):
        if app_ids is None:
            return ArgumentsError("-appIds is required for this action")
        self.__analyzer.recover()
        output = []
        for app_id in app_ids:
            schedule_info = self.__analyzer.get_app_schedule_info(app_id)
            if schedule_info is None:
                logging.info("schedule info not found for app {}".format(app_id))
                continue
            container_infos = schedule_info.get_container_infos()
            columns = [START_TIMESTAMP_KEY, CONTAINER_ID_KEY, NODE_ID_KEY, HOLD_SECONDS_KEY,
                       NUM_CONTAINERS_SNAPSHOT_KEY]
            df = common_util.get_data_frame(container_infos, columns)
            df[START_TIME_KEY] = df[START_TIMESTAMP_KEY].apply(
                lambda x: common_util.timestamp_to_str(float(x), '%Y-%m-%d %H:%M:%S,%f'))
            output.append("Schedule info for app {}:\n{}".format(app_id, df[
                [START_TIME_KEY, CONTAINER_ID_KEY, NODE_ID_KEY, HOLD_SECONDS_KEY, NUM_CONTAINERS_SNAPSHOT_KEY]]))
        return output, None


class GetAppScheduleStatistics(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__analyzer = context.get_analyzer(ANALYZER_KEY_YARN_RM_LOG)

    def handle(self, _, sort_by, ascending):
        self.__analyzer.recover()
        app_statistic_infos = self.__analyzer.get_app_statistic_infos()
        if len(app_statistic_infos) == 0:
            return "no apps found", None
        columns = [ID_KEY, SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_ALLOCATED,
                   SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_RELEASED,
                   SCHEDULE_STATISTIC_KEY_NUM_ALLOCATED,
                   SCHEDULE_STATISTIC_KEY_MAX_NUM_ALLOCATED,
                   SCHEDULE_STATISTIC_KEY_FIRST_SCHEDULE_TIME,
                   SCHEDULE_STATISTIC_KEY_LAST_SCHEDULE_TIME,
                   SCHEDULE_STATISTIC_KEY_SCHEDULE_SECONDS,
                   SCHEDULE_STATISTIC_KEY_COMPLETED_STAT]
        if sort_by is None:
            sort_by = SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_ALLOCATED
        else:
            # check sort_by
            if not set(sort_by).issubset(columns):
                return None, ArgumentsError("invalid sortBy argument ({}), valid sortBy set is {}".format(sort_by, columns))
        df = common_util.get_data_frame(app_statistic_infos, columns)
        convert_dict = {SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_ALLOCATED: int,
                        SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_RELEASED: int,
                        SCHEDULE_STATISTIC_KEY_MAX_NUM_ALLOCATED: int,
                        SCHEDULE_STATISTIC_KEY_SCHEDULE_SECONDS: float}
        df = df.astype(convert_dict)
        df = df.sort_values(by=sort_by, ascending=ascending)
        return "Statistics of schedule information for apps (sortBy={}, ascending={}):\n{}".format(sort_by, ascending,
                                                                                                   df), None


class GetContainerScheduleEvents(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__analyzer = context.get_analyzer(ANALYZER_KEY_YARN_RM_LOG)

    def handle(self, _, query, group_by, show_diagnostic_column):
        self.__analyzer.recover()
        container_events = self.__analyzer.get_container_events()
        if container_events is None or len(container_events) == 0:
            return "container events not found!", None
        columns = [CONTAINER_ID_KEY, EVENT_TYPE_KEY, NODE_ID_KEY, RESOURCE_KEY, TIMESTAMP_KEY, DIAGNOSTIC_KEY]
        convert_dict = {EVENT_TYPE_KEY: int}
        df = common_util.get_data_frame(container_events, columns)
        df = df.astype(convert_dict)
        df[TIME_KEY] = df[TIMESTAMP_KEY].apply(
            lambda x: common_util.timestamp_to_str(float(x), TO_SECOND_DATE_TIME_FORMAT))
        df['time_m'] = df[TIME_KEY].apply(lambda x: x.rsplit(':', 1)[0])
        show_columns = [TIME_KEY, CONTAINER_ID_KEY, EVENT_TYPE_KEY, NODE_ID_KEY, RESOURCE_KEY, 'time_m']
        if query is not None:
            try:
                df = df.query(query)
            except pandas.core.computation.ops.UndefinedVariableError as ex:
                return None, ArgumentsError(
                    "failed to parse query argument: {}, valid columns: {}".format(ex, show_columns))
        info_prefix = "Schedule info for containers with conditions: query='{}', group_by={}".format(query, group_by)
        if group_by is not None:
            return "{}\n{}".format(info_prefix, df.groupby(group_by)[[CONTAINER_ID_KEY]].count()), None
        else:
            if show_diagnostic_column:
                show_columns.append(DIAGNOSTIC_KEY)
            return "{}:\n{}".format(info_prefix, df[show_columns]), None


class AnalyzeMetrics(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__analyzer = context.get_analyzer(ANALYZER_KEY_YARN_METRICS)

    def handle(self, _, interval_s, max_wait_s, show_details):
        def callback_fn(report):
            if show_details:
                metrics_info = report.get_metrics_info()
                if metrics_info is not None:
                    rows = common_util.build_rows_from_nested_dict(metrics_info.get_metrics_data())
                    deduped_rows = common_util.dedup_rows(rows, [0, 1])
                    table = common_util.generate_table(['BeanName', 'MetricKey', 'MetricValue'], deduped_rows)
                    logging.info("YARN metrics info:\n{}".format(table))
            all_diagnostics = report.get_all_diagnostics()
            all_diagnostics_list = list(map(lambda x: x.get_data(), all_diagnostics))
            df = common_util.get_data_frame(all_diagnostics_list, ['id', 'is_healthy', 'message'])
            logging.info("Daignostics:\n{}".format(df))
        report = self.__analyzer.process_periodically(interval_s, max_wait_s, callback_fn)
        all_diagnostics = report.get_all_diagnostics()
        all_diagnostics_list = list(map(lambda x: x.get_data(), all_diagnostics))
        df = common_util.get_data_frame(all_diagnostics_list, ['id', 'is_healthy', 'message'])
        return str(df), None


class LoadNMLogs(LoadLogs):

    def __init__(self, key, context):
        super().__init__(key, context, context.get_analyzer(ANALYZER_KEY_YARN_NM_LOG))


class GetContainerRTInfos(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__analyzer = context.get_analyzer(ANALYZER_KEY_YARN_NM_LOG)

    def handle(self, _, container_ids):
        self.__analyzer.recover()
        container_rt_infos = self.__analyzer.get_container_infos(container_ids)
        if container_rt_infos is None or len(container_rt_infos) == 0:
            return "container runtime infos{} not found!".format(
                ' for {}'.format(container_ids) if len(container_ids) > 0 else ''), None
        columns = [START_TIMESTAMP_KEY, CONTAINER_ID_KEY, INIT_SECONDS_KEY, RUNNING_SECONDS_KEY, EXIT_STATE_KEY,
                   EXIT_CODE_KEY, CONTAINER_STATES_HOLD_SECONDS_KEY]
        df = common_util.get_data_frame(container_rt_infos, columns)
        df[START_TIME_KEY] = df[START_TIMESTAMP_KEY].apply(
            lambda x: common_util.timestamp_to_str(float(x), '%Y-%m-%d %H:%M:%S,%f'))
        return "Runtime info for containers:\n{}".format(df[[START_TIME_KEY, CONTAINER_ID_KEY, INIT_SECONDS_KEY,
                                                             RUNNING_SECONDS_KEY, EXIT_STATE_KEY,
                                                             EXIT_CODE_KEY, CONTAINER_STATES_HOLD_SECONDS_KEY]]), None


class HuntLogIssues(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)
        self.__log_issues_hunter = context.get_analyzer(ANALYZER_KEY_YARN_LOG_ISSUES_HUNTER)

    def handle(self, _):
        issues, checklist = self.__log_issues_hunter.hunt()
        output = list()
        output.append("found {} issues in checklist (size={})".format(len(issues), len(checklist)))
        for issue_name, issue_output in issues.items():
            output.append("{} : {}".format(issue_name, issue_output))
        return output, None
