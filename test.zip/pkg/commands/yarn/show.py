from pkg.commands.generic import *
from pkg.constants import *
from pkg.utils import common_util
from pkg.caches.yarn import common
from textwrap import fill
import time
import pandas


class ShowRMStates(GenericCmdHandler):

    def __init__(self, key, context, rm_state_keys):
        super().__init__(key, context)
        self.__rm_state_keys = rm_state_keys

    def handle(self, _):
        yarn_state_cache = common.get_required_cache(self.context, CACHE_KEY_YARN_STATE)
        rm_states = yarn_state_cache.get_data(YARN_STATE_KEY_RM_STATES)
        columns = ['']
        comparable_dicts = []
        for rm_state in rm_states:
            columns.append("{} [{}]".format(rm_state.get_id(), rm_state.get_hostname()))
            comparable_dicts.append(rm_state.get_info_dict())
        row_keys = self.__rm_state_keys
        format_fn_dict = {
            'startedOn': lambda x: time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(x / 1000)),
        }
        table = common_util.generate_compare_table(columns, row_keys, comparable_dicts, format_fn_dict)
        return "RM states:\n{}".format(table), None


class ShowClusterMetrics(GenericCmdHandler):

    def __init__(self, key, context, cluster_metrics_grouped_keys):
        super().__init__(key, context)
        self.__cluster_metrics_grouped_keys = cluster_metrics_grouped_keys

    def handle(self, _):
        active_rm_state = common.get_active_rm_state(self.context)
        cluster_metrics_dict = active_rm_state.get_cluster_metrics_dict()
        table = common_util.generate_grouped_info_table(self.__cluster_metrics_grouped_keys, cluster_metrics_dict, None)
        return "Cluster metrics:\n{}".format(table), None


class ShowConf(GenericCmdHandler):

    def handle(self, _, chosen_conf_resources):
        chosen_conf_resources_set = set(chosen_conf_resources) if chosen_conf_resources is not None else None
        valid_resources = set()
        conf_cache = common.get_required_cache(self.context, CACHE_KEY_YARN_CONF)
        resource_conf_dict = conf_cache.get_data()
        columns = ['Resource', 'Key', 'Value']
        rows = list()
        for resource, resource_conf_items in resource_conf_dict.items():
            if chosen_conf_resources_set is not None and resource not in chosen_conf_resources_set:
                continue
            for no, resource_conf_item in enumerate(sorted(resource_conf_items)):
                conf_key = resource_conf_item[0]
                conf_value = resource_conf_item[1]
                if len(conf_value) > TABLE_STYLE_COLUMN_MAX_WIDTH:
                    conf_value = fill(conf_value, width=TABLE_STYLE_COLUMN_MAX_WIDTH)
                rows.append([resource if no == 0 else '', conf_key, conf_value])
        table = common_util.generate_table(columns, rows)
        from_chosen_msg = ' from chosen resources ({})'.format(
            chosen_conf_resources) if chosen_conf_resources is not None else ''
        if len(resource_conf_dict) == 0:
            return None, ArgumentsError("no configuration can be shown{}, valid resources: {}".format(
                from_chosen_msg, valid_resources))
        else:
            return "Configurations{}:\n{}".format(from_chosen_msg, table), None


class ShowPartition(GenericCmdHandler):

    def handle(self, _):
        tmp_partitions = common.get_tmp_partitions(self.context)
        columns = ['PartitionName', 'IsExclusivity', 'NumNodes', 'TotalResource', 'UsedResource', 'UsedRatio']
        rows = list()
        for _, tmp_part in sorted(tmp_partitions.items()):
            rows.append([tmp_part.get_name(), tmp_part.is_exclusivity(), tmp_part.get_num_nodes(),
                         tmp_part.get_total_resource(), tmp_part.get_used_resource(), tmp_part.get_used_ratio()])
        table = common_util.generate_table(columns, rows)
        return "Partitions:\n{}".format(table), None


class ShowQueues(GenericCmdHandler):

    def handle(self, _, specified_partition_name, filter_out_non_pending):
        tmp_partitions = common.get_tmp_partitions(self.context)
        if specified_partition_name is not None:
            specified_partition = tmp_partitions.get(specified_partition_name)
            if specified_partition is None:
                return None, EnvError("specified partition name {} not found, valid partitions: {}".format(
                    specified_partition_name, list(tmp_partitions.keys())))
            tmp_partitions = {specified_partition_name: specified_partition}
        yarn_queues_cache = common.get_required_cache(self.context, CACHE_KEY_YARN_QUEUES)
        root_queue = yarn_queues_cache.get_data('root')
        max_depth = root_queue.get_max_depth()
        queue_name_columns = [''] * max_depth
        queue_name_columns[0] = 'QueueName'
        for index in range(max_depth):
            queue_name_columns[index] += ' L{}'.format(index)
        columns = queue_name_columns + ['Capacities', 'Resources', 'User Resources', 'Apps', 'Containers']
        output = []
        for partition_name, tmp_part in sorted(tmp_partitions.items()):
            rows = list()
            self.__recursively_lookup_queues(root_queue, max_depth, partition_name, rows, filter_out_non_pending)
            if len(rows) == 0:
                output.append("no queues in partition {} can be show".format(partition_name))
                continue
            table = common_util.generate_table(columns, rows)
            output.append("Queues in {} \n{}".format(
                'partition {}'.format(partition_name) if partition_name != '' else 'DEFAULT partition', table))
        return output, None

    def __recursively_lookup_queues(self, queue, max_depth, partition_name, rows, filter_out_non_pending):
        queue_partition_info = queue.get_partition_info(partition_name)
        if queue_partition_info is None:
            return
        if not filter_out_non_pending or queue.is_root() or queue_partition_info.has_pending_resource():
            row_data = [''] * max_depth
            row_data[queue.get_level()] = queue.get_name()
            row_data += [queue_partition_info.get_capacities_info(),
                         "{}\n{}".format(queue_partition_info.get_resources_info(),
                                         queue_partition_info.get_am_resources_info()),
                         queue.get_user_resources_info(),
                         queue.get_apps_info(), queue.get_containers_info()]
            rows.append(row_data)
        for _, child_queue in queue.get_child_queues().items():
            self.__recursively_lookup_queues(child_queue, max_depth, partition_name, rows, filter_out_non_pending)


class ShowApps(GenericCmdHandler):

    def handle(self, _, query, sort_by, ascending):
        columns = [COLUMN_KEY_ID, COLUMN_KEY_NAME, COLUMN_KEY_TYPE, COLUMN_KEY_QUEUE, COLUMN_KEY_PRIORITY,
                   COLUMN_KEY_USER, COLUMN_KEY_STATE, COLUMN_KEY_START_TIME, COLUMN_KEY_START_TIMESTAMP,
                   COLUMN_KEY_NUM_ALLOCATED_CONTAINERS, COLUMN_KEY_NUM_PENDING_CONTAINERS,
                   COLUMN_KEY_CLUSTER_USAGE_PERCENTAGE]
        if sort_by is None:
            sort_by = COLUMN_KEY_START_TIMESTAMP
            ascending = False
        else:
            # check sort_by
            if not set(sort_by).issubset(columns):
                return None, ArgumentsError(
                    "invalid sortBy argument ({}), valid sortBy set is {}".format(sort_by, columns))
        yarn_apps_cache = common.get_required_cache(self.context, CACHE_KEY_YARN_APPS)
        apps = yarn_apps_cache.get_data()
        if len(apps) == 0:
            return "no apps found", None
        apps_table_data = list(map(lambda x: x.get_info_dict(), apps.values()))
        df = common_util.get_data_frame(apps_table_data, columns)
        convert_dict = {COLUMN_KEY_PRIORITY: int, COLUMN_KEY_CLUSTER_USAGE_PERCENTAGE: float,
                        COLUMN_KEY_NUM_ALLOCATED_CONTAINERS: int, COLUMN_KEY_NUM_PENDING_CONTAINERS: int,
                        COLUMN_KEY_START_TIMESTAMP: float}
        df = df.astype(convert_dict)
        if query is not None:
            try:
                df = df.query(query)
            except pandas.core.computation.ops.UndefinedVariableError as ex:
                return None, ArgumentsError("failed to parse query argument: {}, valid columns: {}".format(ex, columns))
        df = df.sort_values(by=sort_by, ascending=ascending)
        return "Apps (query={}, sort_by={}, ascending={}):\n{}".format(query, sort_by, ascending, df[columns]), None


class ShowNodes(GenericCmdHandler):

    def handle(self, _, states, group_by_keys):
        yarn_nodes_cache = common.get_required_cache(self.context, CACHE_KEY_YARN_NODES)
        nodes_dict = yarn_nodes_cache.get_data()
        nodes = sorted(nodes_dict.values(), key=lambda n: n.get_id())
        if states is not None:
            origin_num_nodes = len(nodes)
            nodes = list(filter(lambda n: n.get_state() in set(states), nodes))
            if len(nodes) == 0:
                return "no node can be chosen in states {} from {} nodes".format(states, origin_num_nodes), None
        if len(nodes) == 0:
            return "nodes not found!", None
        if group_by_keys is None:
            columns = YARN_NODES_COMMON_TABLE_COLUMNS
            rows = list(map(self.format_nodes_row, nodes))
            table = common_util.generate_table(columns, rows)
            return "Nodes {}: \n{}".format("in states {}".format(states) if states is not None else '', table), None
        else:
            group_by_fn_list = list()
            summary_columns = list()
            for group_by_key in group_by_keys:
                group_by_fn = YARN_NODES_GROUP_BY_FN_DICT.get(group_by_key)
                if group_by_fn is None:
                    return None, ArgumentsError("can't support group by field: {}, valid fields: {}".format(
                        group_by_key, list(YARN_NODES_GROUP_BY_FN_DICT.keys())))
                summary_columns.append(group_by_key)
                group_by_fn_list.append(group_by_fn)
            group_dict = common_util.complex_group_by_dict(nodes, group_by_fn_list, lambda x: x.get_id())
            columns = summary_columns + ['NumNodes', 'Nodes']
            keys_nodes_tuple_list = common_util.parse_nested_dict(group_dict)
            rows = list(map(self.format_aggregated_nodes_row, keys_nodes_tuple_list))
            table = common_util.generate_table(columns, rows)
            return "Nodes grouped by {}{}: \n{}".format(
                group_by_keys, "in states {}".format(states) if states is not None else '', table), None

    def format_nodes_row(self, node, column_max_width=180):
        row_data = list()
        for column_key in YARN_NODES_COMMON_TABLE_COLUMNS:
            get_row_data_fn = YARN_NODES_GET_ROW_DATA_FN_DICT.get(column_key)
            row_item = get_row_data_fn(node)
            if (isinstance(row_item, str) or isinstance(row_item, dict)) and len(
                    str(row_item)) > column_max_width:
                row_item = fill(str(row_item), width=column_max_width)
            row_data.append(row_item)
        return row_data

    def format_aggregated_nodes_row(self, keys_nodes_tuple, column_max_width=180):
        ret_list = keys_nodes_tuple[0]
        _nodes = keys_nodes_tuple[1]
        ret_list += [len(_nodes), fill(str(sorted(list(_nodes.keys()))), width=column_max_width)]
        return ret_list


class ShowSchedulerActivities(GenericCmdHandler):

    def handle(self, _, filter_out_non_pending):
        activities_cache = common.get_required_cache(self.context, CACHE_KEY_YARN_SCHEDULER_ACTIVITIES)
        scheduler_activities = activities_cache.get_data()
        if scheduler_activities is None:
            return None, NotImplementedError("scheduler activities haven't been implemented for this cluster")
        columns, rows = scheduler_activities.get_activities_columns_rows(filter_out_non_pending)
        if len(rows) == 0:
            return "No wanted scheduler activities (filter_out_non_pending={})".format(filter_out_non_pending), None
        common_util.format_rows(rows, column_max_width=40)
        table = common_util.generate_table(columns, rows)
        return "Scheduler activities in {} (filter_out_non_pending={}): \n{}".format(
            scheduler_activities.get_datetime(), filter_out_non_pending, table), None


class ShowHealthReport(GenericCmdHandler):

    def handle(self, _, healthy, work_states):
        cache = common.get_required_cache(self.context, CACHE_KEY_YARN_HEALTH_REPORT)
        components = cache.get_data()
        if components is None:
            return None, NotImplementedError("health report haven't been implemented for this cluster")
        if len(components) == 0:
            return "components not found!", None
        components = components.values()
        if healthy is not None:
            origin_num_components = len(components)
            components = list(filter(lambda n: n.is_healthy() == healthy, components))
            if len(components) == 0:
                return "no component can be chosen by healthy={} from {} components".format(healthy,
                                                                                            origin_num_components), None
        if work_states is not None:
            origin_num_components = len(components)
            components = list(filter(lambda n: n.get_work_state() in set(work_states), components))
            if len(components) == 0:
                return "no component can be chosen in states {} from {} components".format(work_states,
                                                                                           origin_num_components), None
        columns = ['ComponentName', 'Healthy', 'WorkState', 'UpdateTime', 'Diagnostics', 'Metrics']
        rows = list()
        for component in components:
            rows.append([component.get_name(), component.is_healthy(),
                         '-' if component.get_work_state() == 'UNCHECKED' else component.get_work_state(),
                         common_util.timestamp_to_str(int(component.get_update_timestamp())/1000),
                         component.get_diagnostics(), component.get_metrics_info()])
        table = common_util.generate_table(columns, rows)
        return "Health Report:\n{}".format(table), None
