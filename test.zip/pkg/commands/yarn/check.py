from pkg.commands.generic import *
from pkg.caches.yarn.common import *


class CheckCmdHandler(GenericCmdHandler):

    def __init__(self, key, context):
        super().__init__(key, context)

    def handle(self, checker_key, check_args):
        checker = self.context.get_checker(checker_key)
        if checker is None:
            return None, ArgumentsError("checker not found by key {}, valid  keys: {}".format(
                checker_key, list(self.context.get_checkers().keys())))
        check_args = [] if check_args is None else check_args
        verification = checker.check(*check_args)
        return "Report from {}:\n{}".format(checker_key, verification.get_report()), None


class CheckQueues(GenericCmdHandler):

    def handle(self, queue_names, show_pending_apps, filter_out_non_pending):
        queues_checker = get_required_checker(self.context, CHECKER_KEY_YARN_QUEUES)
        verification = queues_checker.check(queue_names, show_pending_apps,
                                            filter_out_non_pending=filter_out_non_pending)
        return "Report for queues {}:\n{}".format(queue_names, verification.get_report()), None


class CheckApps(GenericCmdHandler):

    def handle(self, app_ids):
        apps_checker = get_required_checker(self.context, CHECKER_KEY_YARN_APPS)
        verification = apps_checker.check(app_ids)
        return "Report for apps {}:\n{}".format(app_ids, verification.get_report()), None


class CheckContainers(GenericCmdHandler):

    def handle(self, container_ids):
        containers_checker = get_required_checker(self.context, CHECKER_KEY_YARN_CONTAINERS)
        verification = containers_checker.check(container_ids)
        return "Report for containers {}:\n{}".format(container_ids, verification.get_report()), None
