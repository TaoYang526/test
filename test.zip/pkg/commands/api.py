import copy
import json
import logging
import shlex

from pkg.framework import interface
from pkg.framework.error import *
from pkg.constants import *
from flask import Flask, g, session, request


SESSION_KEY_ENV = "env"
REQUEST_KEY_APP_IDS = "app_ids"
REQUEST_KEY_CMD = "cmd"
RETURN_KEY_ERROR = "error"

ROUTE_PATH_ENV = "/env"
ROUTE_PATH_CHECK_APPS = "/check_apps"
ROUTE_PATH_CHECK_CLUSTER = "/check_cluster"
ROUTE_PATH_EXECUTE = "/execute"


class APIServer(interface.Command):

    def __init__(self, key, context):
        super().__init__(key, context)

    def run(self, args):
        app = Flask(__name__)

        def err_result(msg):
            return json.dumps({RETURN_KEY_ERROR: msg})

        def get_context():
            context = copy.deepcopy(self.context)
            env = get_current_env()
            if env is not None:
                context.set_env(env)
            return context

        def get_current_env():
            env = session.get(SESSION_KEY_ENV)
            if env is None:
                env = self.context.get_env()
            return env

        @app.before_request
        def init_session():
            # init env
            env_str = request.args.get(SESSION_KEY_ENV)
            if env_str is not None:
                try:
                    current_env = get_current_env()
                    env_dict = json.loads(env_str)
                    for k, v in env_dict.items():
                        current_env[k] = v
                    session[SESSION_KEY_ENV] = current_env
                    logging.info("env updated in session: {}".format(current_env))
                except Exception as ex:
                    return err_result("failed to parse env ({}): {}".format(env_str, str(ex)))

        def format_output(response_body):
            accept = request.headers.get('Accept')
            if not response_body.endswith('\n'):
                response_body += '\n'
            if accept is not None and accept.find('text/html') >= 0:
                return response_body.replace(' ', "&nbsp;").replace('\n', '<br/>')
            return response_body

        @app.route(ROUTE_PATH_EXECUTE)
        def execute():
            cmd_str = request.args.get(REQUEST_KEY_CMD)
            if cmd_str is None:
                return err_result("cmd parameter is required but not found!")
            context = get_context()
            commands = context.get_commands()
            cmd_parts = shlex.split(cmd_str)
            logging.info("received command: {}, parsed command parts: {}".format(cmd_str, cmd_parts))
            command = commands.get(cmd_parts[0])
            if command is None:
                return err_result("failed to find command {}".format(cmd_parts[0]))
            output, err = None, None
            try:
                output, err = command.run(cmd_parts[1:])
            except Exception as e:
                err = e
            except SystemExit as exit_code:
                err = ArgumentsError("failed to execute command {}, exit code: {}".format(cmd_parts, exit_code))
            if err is not None:
                return err_result(str(err))
            if isinstance(output, list):
                return format_output('\n'.join(output))
            else:
                return format_output(str(output))

        # start app
        app.secret_key = 'any random string'
        port = self.context.get_conf().get(CONF_KEY_API_SERVER_PORT)
        app.run(host="0.0.0.0", port=port)

        return None, "api server stopped!"
