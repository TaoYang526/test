import logging

from pkg.commands.generic import *
from pkg.caches.common import *


class GetSLSLogs(GenericCmdHandler):

    def handle(self, _, source, from_time, to_time, domain, project, log_store, topic, query, offset, size, reverse, json_fields):
        sls_client_cache = get_required_cache(self.context, CACHE_KEY_SLS_CLIENT)
        logs = sls_client_cache.get_data(source, from_time, to_time, domain, project, log_store, topic, query, offset,
                                         size, reverse)
        output = list()
        for log in logs:
            content = parse_log_content(log)
            if content is None:
                continue
            output.append(content)
        return output, None
