import re

TO_SECOND_DATE_TIME_FORMAT = '%Y-%m-%d %H:%M:%S'
TO_MINUTE_DATE_TIME_FORMAT = '%Y-%m-%d %H:%M'

TABLE_STYLE_COLUMN_MAX_WIDTH = 80

CONF_KEY_ENV = 'env'
CONF_KEY_ENV_FILE = 'env_file'
CONF_KEY_LOG_FILE = 'log_file'
CONF_KEY_CACHE_DIR = 'cache_dir'
CONF_KEY_SOURCES = 'sources'
CONF_KEY_CACHES = 'caches'
CONF_KEY_COMMANDS = 'commands'
CONF_KEY_ANALYZERS = 'analyzers'
CONF_KEY_CHECKERS = 'checkers'
CONF_KEY_KEY = 'key'
CONF_KEY_CONTEXT = 'context'
CONF_KEY_CLASS = 'class'
CONF_KEY_INIT_ARGS = 'init_args'
CONF_KEY_DESCRIPTION = 'description'
CONF_KEY_HANDLER_ARGS_CONF = 'handle_args_conf'
CONF_KEY_GROUP_DESC = 'group_desc'
CONF_KEY_TYPE = 'type'
CONF_KEY_DEST = 'dest'
CONF_KEY_CONF_TEMPLATES_DIR = 'conf_templates_dir'
CONF_KEY_VERSION_MATCH_REGEX = 'version_match_regex'
CONF_KEY_SOURCE = 'source'
CONF_KEY_FROM_TIME = 'from_time'
CONF_KEY_TO_TIME = 'to_time'
CONF_KEY_QUERY = 'query'
CONF_KEY_SIZE = 'size'
CONF_KEY_REVERSE = 'reverse'
CONF_KEY_TARGET_LOGS = 'target_logs'
CONF_KEY_DIAGNOSES = 'diagnoses'
CONF_KEY_PATTERN = 'pattern'
CONF_KEY_PATTERN = 'pattern'
CONF_KEY_HIT_EXPRESSION = 'hit_expression'
CONF_KEY_OUTPUT_EXPRESSION = 'output_expression'
CONF_KEY_INFO_EXTRACT_EXPRESSION = 'info_extract_expression'
CONF_KEY_API_SERVER_PORT = 'api_server_port'
CONF_KEY_DATA_BACKUP_DIR = 'data_backup_dir'
CONF_KEY_DIAGNOSTICS = "diagnostics"
CONF_KEY_DIAGNOSTICS_INSUF_QUEUE_HEADROOM = "insufficient_queue_headroom"
CONF_KEY_DIAGNOSTICS_INSUF_QUEUE_AM_HEADROOM = "insufficient_queue_am_headroom"
CONF_KEY_DIAGNOSTICS_INSUF_USER_HEADROOM = "insufficient_user_headroom"
CONF_KEY_DIAGNOSTICS_INSUF_USER_AM_HEADROOM = "insufficient_user_am_headroom"


FILE_NAME_YARN_SITE = 'yarn-site.xml'
FILE_NAME_CORE_SITE = 'core-site.xml'

ENV_KEY_HADOOP_CLUSTER = 'HADOOP_CLUSTER'
ENV_KEY_CLUSTER_ID = 'CLUSTER_ID'
ENV_KEY_RM_LOG_SOURCE = 'RM_LOG_SOURCE'
ENV_KEY_NM_LOG_SOURCE = 'NM_LOG_SOURCE'
ENV_KEY_CONTAINER_LOG_SOURCE = 'CONTAINER_LOG_SOURCE'
ENV_KEY_SNAPSHOT_LOG_SOURCE = 'SNAPSHOT_LOG_SOURCE'
ENV_KEY_ASI_LOG_SOURCE = 'ASI_LOG_SOURCE'
ENV_KEY_ASI_DOMAIN = 'ASI_DOMAIN'
ENV_KEY_ASI_FLINK_LOG_SOURCE = 'ASI_FLINK_LOG_SOURCE'
ENV_KEY_ASI_FLINK_DOMAIN = 'ASI_FLINK_DOMAIN'
ENV_KEY_DOMAIN = 'DOMAIN'
ENV_KEY_MOCK_DATA_DIR = 'MOCK_DATA_DIR'
ENV_KEY_REPLACE_QUERY = 'REPLACE_QUERY'
ENV_KEY_ADDITIONAL_QUERY_PREFIX = 'ADDITIONAL_QUERY_PREFIX'

DEFAULT_CONF_FILE_NAME = 'conf.yaml'
DEFAULT_LOG_CONF_FILE_NAME = 'log.yaml'

EXIT_CODE_NORMAL = 0
EXIT_CODE_RUN_ARGUMENTS_ERROR = 1
EXIT_CODE_CONF_ERROR = 2
EXIT_CODE_UNKNOWN = 3

SOURCE_KEY_YARN_REST_API = "yarn_rest_api"
SOURCE_KEY_YARN_SLS = "yarn_sls"

SOURCE_DATA_KEY_RM_CONF = 'YARN_RM_CONF'
SOURCE_DATA_KEY_SCHEDULER_CONF = 'YARN_SCHEDULER_CONF'
SOURCE_DATA_KEY_CLUSTER_INFO = 'YARN_CLUSTER_INFO'
SOURCE_DATA_KEY_CLUSTER_METRICS = 'YARN_CLUSTER_METRICS'
SOURCE_DATA_KEY_QUEUES = 'YARN_QUEUES'
SOURCE_DATA_KEY_NODE_LABELS = 'YARN_NODE_LABELS'
SOURCE_DATA_KEY_NODES = 'YARN_NODES'
SOURCE_DATA_KEY_APPS = 'YARN_APPS'
SOURCE_DATA_KEY_RM_METRICS = 'YARN_RM_METRICS'
SOURCE_DATA_KEY_RM_HEALTH_REPORT = 'YARN_RM_HEALTH_REPORT'
# not exist in SLS snapshot
SOURCE_DATA_KEY_SCHEDULER_ACTIVITIES = 'YARN_SCHEDULER_ACTIVITIES'
SOURCE_DATA_KEY_LOGS = 'YARN_LOGS'

CACHE_KEY_CLUSTER_LOCAL_CONF = 'cluster_local_conf'
CACHE_KEY_SLS_CLIENT = 'sls_client'
CACHE_KEY_ASI_SLS_CLIENT = 'asi_sls_client'
CACHE_KEY_YARN_STATE = 'yarn_state'
CACHE_KEY_YARN_CONF = 'yarn_conf'
CACHE_KEY_YARN_QUEUES = 'yarn_queues'
CACHE_KEY_YARN_PARTITIONS = 'yarn_partitions'
CACHE_KEY_YARN_NODES = 'yarn_nodes'
CACHE_KEY_YARN_APPS = 'yarn_apps'
CACHE_KEY_YARN_JMX_METRICS = 'yarn_jmx_metrics'
CACHE_KEY_YARN_SCHEDULER_ACTIVITIES = 'yarn_scheduler_activities'
CACHE_KEY_YARN_LOGS = 'yarn_logs'
CACHE_KEY_YARN_HEALTH_REPORT = 'yarn_health_report'

CACHE_PERSIST_KEY_UPDATE_TIMESTAMP = 'update_timestamp'
CACHE_PERSIST_KEY_DATA = 'data'
CACHE_PERSIST_KEY_CLUSTER = 'cluster'

CHECKER_KEY_YARN_CLUSTER = 'yarn_cluster_checker'
CHECKER_KEY_YARN_QUEUES = 'yarn_queues_checker'
CHECKER_KEY_YARN_APPS = 'yarn_apps_checker'
CHECKER_KEY_YARN_CONTAINERS = 'yarn_containers_checker'
CHECKER_KEY_ASI_FLINK_JOB = 'asi_flink_job_checker'

REST_API_URL_TEMPLATE_MAPPING = {
    SOURCE_DATA_KEY_RM_CONF: '{}://{}/conf',
    SOURCE_DATA_KEY_SCHEDULER_CONF: '{}://{}/ws/v1/cluster/scheduler-conf',
    SOURCE_DATA_KEY_CLUSTER_INFO: '{}://{}/ws/v1/cluster/info',
    SOURCE_DATA_KEY_CLUSTER_METRICS: '{}://{}/ws/v1/cluster/metrics',
    SOURCE_DATA_KEY_QUEUES: '{}://{}/ws/v1/cluster/scheduler',
    SOURCE_DATA_KEY_NODE_LABELS: '{}://{}/ws/v1/cluster/get-node-labels',
    SOURCE_DATA_KEY_NODES: '{}://{}/ws/v1/cluster/nodes',
    SOURCE_DATA_KEY_APPS: '{}://{}/ws/v1/cluster/apps?state=NEW,NEW_SAVING,SUBMITTED,ACCEPTED,RUNNING,FAILED',
    SOURCE_DATA_KEY_RM_METRICS: '{}://{}/jmx',
    SOURCE_DATA_KEY_SCHEDULER_ACTIVITIES: '{}://{}/ws/v1/cluster/scheduler/activities',
    SOURCE_DATA_KEY_LOGS: '{}://{}/logs',
    SOURCE_DATA_KEY_RM_HEALTH_REPORT: '{}://{}/ws/v1/cluster/healthcheck',
}

ROOT_NAME_YARN_RM_CONF = 'properties'
ROOT_NAME_YARN_CLUSTER_INFO = 'clusterInfo'
ROOT_NAME_YARN_CLUSTER_METRICS = 'clusterMetrics'
ROOT_NAMES_YARN_SCHEDULER = ['scheduler', 'schedulerInfo']
ROOT_NAMES_YARN_APPS = ['apps', 'app']

URL_YARN_NON_ANONYMOUS_PARAMS = {'username': 'ht'}
REQUEST_HEADER = {'Accept': 'application/json'}

CONF_VAR_PATTERN = re.compile('\\${[a-zA-Z0-9_.-]+}')

YARN_STATE_KEY_YARN_BASIC_INFO = 'yarn_basic_info'
YARN_STATE_KEY_RM_STATES = 'rm_states'
YARN_STATE_KEY_ACTIVE_RM_STATE = 'active_rm_state'
YARN_STATE_KEY_CLUSTER_METRICS = 'cluster_metrics'
YARN_NODES_KEY_NODES = 'nodes'
YARN_NODES_KEY_STATE_NODES = 'state_nodes'

YARN_QUEUES_DATA_KEY_QUEUES = ''

YARN_NODES_GROUP_BY_FN_DICT = {'State': lambda x: x.get_state(),
                               'TotalResource': lambda x: x.get_total_resource()}
YARN_NODES_VALID_STATES = ['NEW', 'RUNNING', 'UNHEALTHY', 'LOST', 'REBOOTED', 'DECOMMISSIONING',
                           'DECOMMISSIONED', 'SHUTDOWN']
YARN_NODES_COMMON_TABLE_COLUMNS = ['NodeID', 'Partition', 'State', 'NumContainers', 'UsedResource', 'TotalResource',
                                   'UsedRatio', 'LastHealthUpdate', 'HealthReport']
YARN_NODES_GET_ROW_DATA_FN_DICT = {'NodeID': lambda x: x.get_id(),
                                   'Partition': lambda x: x.get_partition(),
                                   'State': lambda x: x.get_state(),
                                   'HTTPAddress': lambda x: x.get_http_address(),
                                   'NumContainers': lambda x: x.get_num_containers(),
                                   'UsedResource': lambda x: x.get_used_resource(),
                                   'UsedRatio': lambda x: x.get_used_ratio(),
                                   'AvailableResource': lambda x: x.get_available_resource(),
                                   'TotalResource': lambda x: x.get_total_resource(),
                                   'LastHealthUpdate': lambda x: x.get_last_health_update(),
                                   'HealthReport': lambda x: x.get_health_report(),
                                   'ResourceUtilization': lambda x: x.get_resource_utilization()}

YARN_RPC_ACTIVITIES_BEAN_NAME = "Hadoop:service=ResourceManager,name=RpcActivityForPort{}"
YARN_RPC_DETAILED_ACTIVITIES_BEAN_NAME = "Hadoop:service=ResourceManager,name=RpcDetailedActivityForPort{}"

YARN_SKIPPED_RESOURCE_NAMES_IN_RI = set(['memory-mb', 'vcores'])

BEAN_NAME_KEY = 'name'
MONITOR_CONF_KEY_AGG_TYPE = 'agg_type'
MONITOR_CONF_KEY_ABNORMAL_COND = 'abnormal_cond'
METRIC_TYPE_REALTIME = 0
METRIC_TYPE_COUNTER = 1
METRIC_TYPE_MAPPING = {
    'realtime': METRIC_TYPE_REALTIME,
    'counter': METRIC_TYPE_COUNTER,
}

METRIC_AGG_TYPE_LAST = 0
METRIC_AGG_TYPE_MEAN = 1
METRIC_AGG_TYPE_MIN = 2
METRIC_AGG_TYPE_MAX = 3
METRIC_AGG_TYPE_QPS = 4
METRIC_AGG_TYPE_MAPPING = {
    'last': METRIC_AGG_TYPE_LAST,
    'mean': METRIC_AGG_TYPE_MEAN,
    'min': METRIC_AGG_TYPE_MIN,
    'max': METRIC_AGG_TYPE_MAX,
    'qps': METRIC_AGG_TYPE_QPS,
}

ANALYZER_KEY_YARN_METRICS = 'yarn_metrics_analyzer'
ANALYZER_KEY_YARN_RM_LOG = 'yarn_rm_log_analyzer'
ANALYZER_KEY_YARN_RM_SLS_LOG = 'yarn_rm_sls_log_analyzer'
ANALYZER_KEY_YARN_NM_LOG = 'yarn_nm_log_analyzer'
ANALYZER_KEY_YARN_LOG_ISSUES_HUNTER = 'yarn_log_issues_hunter'

ANALYZER_KEY_ASI_EVENT_LOG = 'asi_event_log_analyzer'
ANALYZER_KEY_ASI_FLINK_LOG = 'asi_flink_log_analyzer'

CHECKER_VERIFICATION_STATUS_UNKNOWN = 'UNKNOWN'
CHECKER_VERIFICATION_STATUS_SUCCEEDED = 'SUCCEEDED'
CHECKER_VERIFICATION_STATUS_FAILED = 'FAILED'

OUTPUT_TAB_STRING = '    '

COLUMN_KEY_ID = 'ID'
COLUMN_KEY_NAME = 'Name'
COLUMN_KEY_QUEUE = 'Queue'
COLUMN_KEY_USER = 'User'
COLUMN_KEY_STATE = 'State'
COLUMN_KEY_PRIORITY = 'Priority'
COLUMN_KEY_DIAGNOSTICS = 'Diagnostics'
COLUMN_KEY_TYPE = 'Type'
COLUMN_KEY_TAGS = 'Tags'
COLUMN_KEY_START_TIME = 'StartTime'
COLUMN_KEY_START_TIMESTAMP = 'StartTimestamp'
COLUMN_KEY_NUM_ALLOCATED_CONTAINERS = 'NumAllocatedContainers'
COLUMN_KEY_NUM_PENDING_CONTAINERS = 'NumPendingContainers'
COLUMN_KEY_CLUSTER_USAGE_PERCENTAGE = 'ClusterUsagePercentage'
COLUMN_KEY_URL = 'URL'
COLUMN_KEY_SIZE = 'Size'
COLUMN_KEY_UPDATE_TIME = 'UpdateTime'
COLUMN_KEY_EVENT_TIME = 'EventTime'
COLUMN_KEY_LOG_LEVEL = 'LogLevel'
COLUMN_KEY_REASON = 'Reason'
COLUMN_KEY_CONTENT = 'Content'

CAPACITY_SCHEDULER_CONF_NAME = 'capacity-scheduler.xml'

CONTAINER_ID_KEY = 'container_id'
NODE_ID_KEY = 'node_id'
RESOURCE_KEY = 'resource'
DIAGNOSTIC_KEY = 'diagnostic'
TIME_KEY = 'time'
TIMESTAMP_KEY = 'timestamp'
TIMESTAMP_S_KEY = 'timestamp_s'
EVENT_TYPE_KEY = 'event_type'
ID_KEY = 'id'
NAME_KEY = 'name'
DESCRIPTION_KEY = 'description'
OLD_STATE_KEY = 'old_state'
NEW_STATE_KEY = 'new_state'
STATE_KEY = 'state'
NEXT_STATE_KEY = 'next_state'
STATUS_KEY = 'status'
INFO_KEY = 'info'
START_TIMESTAMP_KEY = 'start_timestamp'
FINISH_TIMESTAMP_KEY = 'finish_timestamp'
START_TIME_KEY = 'start_time'
FINISH_TIME_KEY = 'finish_time'
HOLD_SECONDS_KEY = 'hold_seconds'
NUM_CONTAINERS_SNAPSHOT_KEY = 'num_containers_snapshot'
CONTAINER_STATES_KEY = 'container_states'
EXIT_CODE_KEY = 'exit_code'
USER_KEY = 'user'
EXIT_STATE_KEY = 'exit_state'
INIT_SECONDS_KEY = 'init_seconds'
RUNNING_SECONDS_KEY = 'running_seconds'
CONTAINER_STATES_HOLD_SECONDS_KEY = 'container_states_hold_seconds'
OUTPUTS_KEY = 'outputs'
TITLE_KEY = 'title'
CONTENT_KEY = 'content'
SUB_VERIFICATIONS_KEY = 'sub_verifications'
CLUSTER_KEY = 'cluster'
NAMESPACE_KEY = 'namespace'
NAME_KEY = 'name'
SOURCE_KEY = 'source'
LOG_LEVEL_KEY = 'log_level'
REASON_KEY = 'reason'
EVENTS_KEY = 'events'
CHILDREN_KEY = 'children'
LOGS_KEY = 'logs'
FROM_TIME_KEY = 'from_time'
TO_TIME_KEY = 'to_time'
SIZE_KEY = 'size'

NEW_STATE_NAME = 'NEW'
RUNNING_STATE_NAME = 'RUNNING'

SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_ALLOCATED = 'agg_num_allocated'
SCHEDULE_STATISTIC_KEY_AGGREGATED_NUM_RELEASED = 'agg_num_released'
SCHEDULE_STATISTIC_KEY_MAX_NUM_ALLOCATED = 'max_num_allocated'
SCHEDULE_STATISTIC_KEY_NUM_ALLOCATED = 'num_allocated'
SCHEDULE_STATISTIC_KEY_FIRST_SCHEDULE_TIME = 'first_schedule_time'
SCHEDULE_STATISTIC_KEY_LAST_SCHEDULE_TIME = 'last_schedule_time'
SCHEDULE_STATISTIC_KEY_SCHEDULE_SECONDS = 'schedule_seconds'
SCHEDULE_STATISTIC_KEY_COMPLETED_STAT = 'completed_statistic'
