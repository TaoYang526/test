from abc import ABC

from pkg.framework import interface
from pkg.utils import common_util, io_util
import os
import logging
from pkg.constants import *


class GenericCache(interface.Cache, ABC):

    def __init__(self, key, context, ttl_seconds=-1):
        super().__init__(key, context)
        self.__ttl_seconds = ttl_seconds
        self.__update_timestamp = 0

    def should_reload(self):
        if self.__ttl_seconds <= 0:
            return True
        if self.__ttl_seconds <= common_util.get_timestamp() - self.__update_timestamp:
            return True
        return False

    def trigger_loaded(self):
        self.loaded = True
        self.__update_timestamp = common_util.get_timestamp()


class ReusableCache(interface.Cache):

    def __init__(self, key, context, ttl_seconds=-1, reusable=False):
        self.__recovered = False
        self.__loaded = False
        self.__outdated = False
        self.key = key
        self.context = context
        self.__local_cache_file = os.path.join(context.get_cache_dir(), self.get_key())
        self.__ttl_seconds = ttl_seconds
        self.__reusable = reusable
        self.__update_timestamp = None

    def get_key(self):
        return self.key

    def load(self):
        logging.debug("reload data for cache {}".format(self.get_key()))
        serializable_data = self.get_serializable_data()
        self.__update_timestamp = common_util.get_timestamp()
        if self.__reusable:
            self.__persist(serializable_data)
        self.load_from_serializable_data(serializable_data)
        self.__loaded = True

    def refresh(self):
        self.__loaded = False
        self.load()

    def get_data(self, *keys): pass

    def get_serializable_data(self):
        pass

    def load_from_serializable_data(self, data):
        pass

    def should_reload(self):
        if not self.__recovered and self.__reusable:
            # load from local cache if reusable
            if self.__recover():
                self.__loaded = True
            self.__recovered = True
        return not self.__loaded or (self.__update_timestamp is not None and
                                     0 < self.__ttl_seconds <= common_util.get_timestamp() - self.__update_timestamp)

    def __persist(self, data):
        timer = common_util.get_timer()
        io_util.save_dict(self.__local_cache_file,
                          {CACHE_PERSIST_KEY_UPDATE_TIMESTAMP: self.__update_timestamp, CACHE_PERSIST_KEY_DATA: data,
                           CACHE_PERSIST_KEY_CLUSTER: self.context.get_cluster_id()})
        logging.debug("persisted cache {}, elapse_time={}(ms)".format(self.get_key(), round(timer.get_elapse_ms(), 3)))

    # return True if recovered successfully, else return False
    def __recover(self):
        if not os.path.exists(self.__local_cache_file):
            logging.debug("skip recovering cache {} since local cache file not found!".format(self.get_key()))
            return False
        timer = common_util.get_timer()
        local_cache_data = io_util.load_dict(self.__local_cache_file)
        if local_cache_data.get(CACHE_PERSIST_KEY_CLUSTER) != self.context.get_cluster_id():
            logging.debug("skip recovering cache {} since cluster id miss-matched!".format(self.get_key()))
            return False
        self.__update_timestamp = local_cache_data.get(CACHE_PERSIST_KEY_UPDATE_TIMESTAMP)
        data = local_cache_data.get(CACHE_PERSIST_KEY_DATA)
        if data is None:
            logging.debug("skip recovering cache {} since no data exist!".format(self.get_key()))
            return False
        self.load_from_serializable_data(data)
        logging.debug("recovered cache {}, update_timestamp={} (elapsed {} seconds), elapse_time={}(ms)".format(
            self.get_key(), round(self.__update_timestamp, 3),
            round(common_util.get_timestamp() - self.__update_timestamp, 3),
            round(timer.get_elapse_ms(), 3)))
        return True
