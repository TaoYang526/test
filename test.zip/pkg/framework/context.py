import logging
import os
from pkg.constants import *
from pkg.framework import config
from pkg.framework.error import *
from pkg.utils import io_util, common_util
from collections import OrderedDict


class Context:

    def __init__(self, executing_path, conf_file):
        self.__executing_path = executing_path
        self.__conf_file = conf_file
        self.__env = dict()
        self.__caches = OrderedDict()
        self.__analyzers = OrderedDict()
        self.__checkers = OrderedDict()
        self.__commands = OrderedDict()
        self.__conf = config.Config()
        self.__env_file = None
        self.__cache_dir = None
        self.__cluster = None

    def init(self):
        err = self.__load_conf()
        if err is not None:
            return err
        self.__load_env()

    def __load_env(self):
        if os.path.exists(self.__env_file):
            self.__env = io_util.load_dict(self.__env_file)
            logging.debug("loaded env={}".format(self.__env))
        else:
            logging.debug("skip loading env since env file {} does not exist!".format(self.__env_file))

    def persist_env(self):
        io_util.save_dict(self.__env_file, self.__env)
        logging.info("persisted env: {}".format(self.__env))

    def __load_conf(self):
        conf_file = self.__conf_file
        if conf_file is None:
            conf_file = io_util.find_file(self.__executing_path, DEFAULT_CONF_FILE_NAME)
            if conf_file is None:
                return "failed to load conf since default conf {} not found".format(DEFAULT_CONF_FILE_NAME)
        if not os.path.isfile(conf_file):
            return "failed to load conf since {} is not file".format(conf_file)
        self.__conf.load_yaml(conf_file)
        env_file = self.__conf.get(CONF_KEY_ENV_FILE)
        if env_file is None:
            return "required key {} not found in conf file!".format(CONF_KEY_ENV_FILE)
        if not os.path.isabs(env_file):
            env_file = os.path.join(self.__executing_path, env_file)
        self.__env_file = env_file
        cache_dir = self.__conf.get(CONF_KEY_CACHE_DIR)
        if cache_dir is None:
            return "required key {} not found in conf file!".format(CONF_KEY_CACHE_DIR)
        if not os.path.isabs(cache_dir):
            cache_dir = os.path.join(self.__executing_path, cache_dir)
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)
        self.__cache_dir = cache_dir
        return None

    def get_conf(self):
        return self.__conf

    def add_env(self, env_key, env_value):
        self.__env[env_key] = env_value

    def add_env_if_absent(self, env_key, env_value):
        if env_key not in self.__env:
            self.__env[env_key] = env_value

    def get_env(self):
        return self.__env

    def set_env(self, env):
        self.__env = env

    def parse_env_vars(self, env_vars):
        if env_vars is None:
            return
        for env_var in env_vars:
            kv_array = env_var.split('=', 1)
            if len(kv_array) == 2:
                env_key = kv_array[0]
                env_value = kv_array[1]
                env_old_value = self.__env.get(env_key)
                if env_value == '':
                    self.__env.pop(env_key, None)
                else:
                    self.__env[env_key] = env_value
                logging.info('{} environment variable: {} {}'.format(
                    'Created' if env_old_value is None else 'Updated', env_var,
                    '(old: {})'.format(env_old_value) if env_old_value is not None else ''))
            else:
                raise ArgumentsError('unexpected environment variable(format: VAR_NAME=VAR_VALUE): {}'.format(env_var))

    def get_env_value(self, env_key):
        env_value = self.__env.get(env_key)
        return self.get_env_decoded_str(env_value)

    def add_cache(self, cache_key, cache):
        self.__caches[cache_key] = cache

    def get_cache(self, cache_key):
        return self.__caches.get(cache_key)

    def get_cache_data(self, cache_key, *data_key):
        cache = self.get_cache(cache_key)
        if cache is not None:
            return cache.get_data(*data_key)
        return None

    def add_analyzer(self, analyzer_key, analyzer):
        self.__analyzers[analyzer_key] = analyzer

    def get_analyzer(self, analyzer_key):
        return self.__analyzers.get(analyzer_key)

    def get_analyzers(self):
        return self.__analyzers

    def add_checker(self, checker_key, checker):
        self.__checkers[checker_key] = checker

    def get_checker(self, checker_key):
        return self.__checkers.get(checker_key)

    def get_checkers(self):
        return self.__checkers

    def add_command(self, key, command):
        self.__commands[key] = command

    def get_command(self, key):
        return self.__commands.get(key)

    def get_commands(self):
        return self.__commands

    def get_executing_path(self):
        return self.__executing_path

    def get_cache_dir(self):
        return self.__cache_dir

    def get_env_decoded_str(self, str):
        if str is None:
            return None
        return common_util.replace_var(str, self.get_env())

    def get_cluster_id(self):
        cluster_id = self.get_env_value(ENV_KEY_CLUSTER_ID)
        if cluster_id is None:
            cluster_id = self.get_env_value(ENV_KEY_HADOOP_CLUSTER)
        return cluster_id
