from pkg.constants import *
from abc import ABCMeta, abstractmethod
from pkg.utils import common_util


# Checker interface
class Checker(metaclass=ABCMeta):

    def __init__(self, key, context):
        self.key = key
        self.context = context

    @abstractmethod
    def check(self, *args): pass


class Verification:

    def __init__(self, id, description=None, status=CHECKER_VERIFICATION_STATUS_UNKNOWN, deep=0):
        self.__id = id
        self.__description = description
        self.__status = status
        self.__deep = deep
        self.__sub_verifications = list()
        self.__outputs = list()

    def add_sub_verification(self, id, description=None, assert_result=None,
                             status=CHECKER_VERIFICATION_STATUS_UNKNOWN):
        sub_verf = Verification(id, description, status, deep=self.__deep + 1)
        self.__sub_verifications.append(sub_verf)
        if assert_result is not None:
            sub_verf.set_status(
                CHECKER_VERIFICATION_STATUS_SUCCEEDED if assert_result is True else CHECKER_VERIFICATION_STATUS_FAILED)
        return sub_verf

    def refresh_status(self, recursively=False):
        if len(self.__sub_verifications) > 0:
            self.__status = CHECKER_VERIFICATION_STATUS_SUCCEEDED
            for sub_ver in self.__sub_verifications:
                sub_status = sub_ver.refresh_and_get_status(recursively) if recursively else sub_ver.get_status()
                if sub_status == CHECKER_VERIFICATION_STATUS_FAILED:
                    self.__status = CHECKER_VERIFICATION_STATUS_FAILED
                elif self.__status == CHECKER_VERIFICATION_STATUS_SUCCEEDED \
                        and sub_status == CHECKER_VERIFICATION_STATUS_UNKNOWN:
                    self.__status = CHECKER_VERIFICATION_STATUS_UNKNOWN

    def refresh_and_get_status(self, recursively=False):
        self.refresh_status(recursively)
        return self.__status

    def get_status(self):
        if self.__status == CHECKER_VERIFICATION_STATUS_UNKNOWN:
            return self.refresh_and_get_status()
        return self.__status

    def set_status(self, status):
        self.__status = status

    def get_id(self):
        return self.__id

    def get_deep(self):
        return self.__deep

    def set_deep(self, deep):
        self.__deep = deep

    def get_report(self):
        report = ''
        report += str(self) + '\n'
        for sub_verf in self.__sub_verifications:
            report += sub_verf.get_report() + '\n'
        return report[0:-1]

    def add_output(self, output_title, content=None):
        self.__outputs.append((output_title, content))

    def succeeded(self):
        self.__status = CHECKER_VERIFICATION_STATUS_SUCCEEDED

    def failed(self):
        self.__status = CHECKER_VERIFICATION_STATUS_FAILED

    def get_json(self):
        obj = {ID_KEY: self.__id, STATUS_KEY: self.__status}
        if self.__description is not None:
            obj[DESCRIPTION_KEY] = self.__description
        if len(self.__outputs) > 0:
            obj[OUTPUTS_KEY] = list(
                map(lambda x: {TITLE_KEY: x[0], CONTENT_KEY: common_util.get_serializable_data(x[1])}, self.__outputs))
        if len(self.__sub_verifications) > 0:
            obj[SUB_VERIFICATIONS_KEY] = list(map(lambda x: x.get_json(), self.__sub_verifications))
        return obj

    def __repr__(self):
        prefix = OUTPUT_TAB_STRING * self.__deep
        rst = "{}|- {} [{}] {}".format(prefix, self.__id, self.__status,
                                       '({})'.format(self.__description) if self.__description is not None else '')
        if len(self.__outputs) > 0:
            for index, (output_title, content) in enumerate(self.__outputs):
                rst += '\n{}    |- (OUTPUT-{}) {}'.format(prefix, index, output_title)
                if content is not None:
                    if isinstance(content, list):
                        for content_item in content:
                            rst += '\n{}               {}'.format(prefix, content_item)
                    elif isinstance(content, dict):
                        for k, v in content.items():
                            rst += '\n{}               {}: {}'.format(prefix, k, v)
                    else:
                        rst += ' : {}'.format(content)
        return rst

    def __str__(self):
        return self.__repr__()
