class ArgumentsError(RuntimeError):
    pass


class EnvError(RuntimeError):
    pass


class ConfError(RuntimeError):
    pass
