from abc import ABCMeta, abstractmethod


# Cache interface
class Cache(metaclass=ABCMeta):

    def __init__(self, key, context):
        self.loaded = False
        self.key = key
        self.context = context

    def get_key(self):
        return self.key

    @abstractmethod
    def load(self): pass

    def refresh(self):
        self.loaded = False
        self.load()

    @abstractmethod
    def get_data(self, *keys): pass


# Command interface defines the required functions for concrete commands
class Command(metaclass=ABCMeta):

    def __init__(self, key, context):
        self.key = key
        self.context = context

    @abstractmethod
    def run(self, run_args):
        pass
