import logging
import logging.config
import os
import yaml
from pkg.constants import *
from pkg.utils import io_util, common_util
from pkg.framework import *
import pandas


def init_logging(executing_path, log_conf_file, log_file):
    if log_conf_file is None:
        log_conf_file = io_util.find_file(executing_path, DEFAULT_LOG_CONF_FILE_NAME)
    if log_conf_file:
        with open(log_conf_file, 'r') as f_conf:
            dict_conf = yaml.load(f_conf, Loader=yaml.FullLoader)
        handlers = dict_conf.get('handlers')
        # initialize logs directory if necessary
        for handler in handlers.values():
            handler_class = handler.get('class')
            if handler_class.find('FileHandler') != -1:
                log_dir = os.path.dirname(log_file)
                if not os.path.isabs(log_dir):
                    log_dir = os.path.join(executing_path, log_dir)
                if not os.path.exists(log_dir):
                    os.makedirs(log_dir)
                handler['filename'] = os.path.join(log_dir, os.path.basename(log_file))
        logging.config.dictConfig(dict_conf)
    else:
        logging.info("logging to console since not found the log config file")


def init_context(executing_path, conf_file):
    ctx = context.Context(executing_path, conf_file)
    err = ctx.init()
    if err is not None:
        logging.error("{}. exit!".format(err))
        exit(EXIT_CODE_CONF_ERROR)
    return ctx


def init_extendable_instances(context):
    __add_extendable_instances(context, CONF_KEY_CACHES, context.add_cache)
    __add_extendable_instances(context, CONF_KEY_ANALYZERS, context.add_analyzer)
    __add_extendable_instances(context, CONF_KEY_CHECKERS, context.add_checker)
    __add_extendable_instances(context, CONF_KEY_COMMANDS, context.add_command)


def __add_extendable_instances(context, type, add_fn):
    conf = context.get_conf().get(type)
    if isinstance(conf, list):
        conf_dict = dict()
        for conf_item in conf:
            key = conf_item.get(CONF_KEY_KEY)
            conf_dict[key] = conf_item
        conf = conf_dict
    for key, conf_item in conf.items():
        init_args = {CONF_KEY_KEY: key, CONF_KEY_CONTEXT: context}
        configured_init_args = conf_item.get(CONF_KEY_INIT_ARGS)
        if configured_init_args is not None:
            init_args.update(configured_init_args)
        try:
            construct_fn = common_util.reflect_fn(conf_item.get(CONF_KEY_CLASS))
            instance = construct_fn(**init_args)
        except TypeError as ex:
            logging.error("failed to initialize {} {}: {}".format(type, key, ex))
            exit(EXIT_CODE_CONF_ERROR)
        add_fn(key, instance)


def init_command_dependencies():
    # show all columns
    pandas.set_option('display.max_columns', None)
    # show all rows
    pandas.set_option('display.max_rows', None)
    # keep row data in the same line
    pandas.set_option('display.width', None)
    # show all data
    pandas.set_option('max_colwidth', None)
    pandas.set_option('display.colheader_justify', 'center')
