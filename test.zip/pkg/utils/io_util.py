from xml.dom import minidom
# import numpy as np
import os
import json
import yaml


def read_xml(xml_file, xml_content=None):
    if xml_file is not None:
        doc = minidom.parse(xml_file)
    elif xml_content is not None:
        doc = minidom.parseString(xml_content)
    root = doc.documentElement
    conf_list = []
    for node in root.getElementsByTagName("property"):
        name = node.getElementsByTagName("name")[0].firstChild.data
        value_elem = node.getElementsByTagName("value")[0].firstChild
        value = value_elem.data if value_elem is not None else ''
        resource_elem = node.getElementsByTagName("source")
        resource = resource_elem[0].firstChild.data if resource_elem else ''
        conf_list.append({'key': name, 'value': value, 'resource': resource})
    return conf_list


def read_xml_2_dict(xml_file, xml_content=None):
    conf_list = read_xml(xml_file, xml_content)
    conf_dict = {}
    for conf_item in conf_list:
        conf_dict[conf_item['key']] = conf_item['value']
    return conf_dict


def find_file(path, file_name):
    for root, dirs, files in os.walk(path):
        if file_name in files:
            return os.path.join(root, file_name)


def find_dirs(path):
    results = []
    for root, dirs, files in os.walk(path):
        for d in dirs:
            results.append(d)
    return results


def list_file(path):
    files = []
    for file_name in sorted(os.listdir(path)):
        files.append(os.path.join(path, file_name))
    return files


def save_dict(path, target_dict):
    with open(path, 'w') as f:
        json.dump(target_dict, f)


def load_dict(path):
    with open(path) as f:
        return json.load(f)


def write_yaml(file_path, obj):
    with open(file_path, 'w') as f:
        yaml.dump(obj, f, allow_unicode=True, default_flow_style=False, sort_keys=False)


def load_yaml(file_path):
    with open(file_path, 'r') as f:
        data = yaml.safe_load(f)
    return data


def read_file(file_path):
    with open(file_path) as f:
        return f.read()


def write_file(file_path, data):
    with open(file_path, "w") as file:
        file.write(data)
