# cython: language_level=3
import datetime
import importlib
import logging
from pkg.constants import *
from pkg.framework.error import *
from prettytable import PrettyTable
from textwrap import fill
import pandas as pd
import numpy as np
import argparse
import time
import sys
import json
from collections import OrderedDict

reflect_cache = {}


def get_serializable_data(data):
    if isinstance(data, int) or isinstance(data, float) or isinstance(data, bool):
        return data
    elif isinstance(data, list) or isinstance(data, set) or isinstance(data, tuple):
        return [get_serializable_data(x) for x in data]
    elif isinstance(data, dict):
        return dict(map(lambda elem: [elem[0], get_serializable_data(elem[1])], data.items()))
    else:
        return str(data)


def get_timestamp():
    return time.time()


def replace_var(content, env):
    matched_vars = CONF_VAR_PATTERN.findall(content)
    for var in matched_vars:
        var_name = var[2:-1]
        env_value = env.get(var_name)
        if env_value is None:
            raise ConfError('env var {} defined in conf file not found!'.format(var))
        content = content.replace(var, env_value)
    return content


def parse_json_str(json_str):
    if json_str is not None:
        try:
            # avoid "INF" causing json load failure
            if json_str.find("INF,") >= 0:
                json_str = json_str.replace("INF,", "\"INF\",")
            # avoid "NaN" causing json load failure
            if json_str.find("NaN,") >= 0:
                json_str = json_str.replace("NaN,", "\"NaN\",")
            return json.loads(json_str)
        except Exception as ex:
            logging.error("Fail to parse json string, content=" + json_str)
            raise ex
    return None

# build rows from nested dict
def build_rows_from_nested_dict(nested_dict):
    keys = list()
    rows = list()
    __process_single_level_of_nested_dict(nested_dict, keys, rows)
    return rows


def __process_single_level_of_nested_dict(data, keys, rows):
    if isinstance(data, dict):
        for key, value in data.items():
            __process_single_level_of_nested_dict(value, keys + [key], rows)
    else:
        row = list(keys) + [data]
        rows.append(row)


# deduplicate rows
# change rows from
#   key1 key1-1 key1-1-1 value1
#   key1 key1-1 key1-1-2 value2
#   key1 key1-2 key1-2-1 value3
#   key1 key1-2 key1-2-2 value4
# to:
#   key1 key1-1 key1-1-1 value1
#               key1-1-2 value2
#        key1-2 key1-2-1 value1
#               key1-2-2 value2
def dedup_rows(rows, dedup_indexs):
    if len(rows) == 0:
        return rows
    rst = list()
    last_row = [''] * len(rows[0])
    for row in rows:
        deduped_row = list(row)
        for index, column_value in enumerate(row):
            if index in dedup_indexs and row[index] == last_row[index]:
                deduped_row[index] = ''
        rst.append(deduped_row)
        last_row = row
    return rst

def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


def parse_timestamp(datetime_str, datetime_format):
    time_obj = datetime.datetime.strptime(datetime_str, datetime_format)
    return time_obj.timestamp()


def timestamp_to_str(timestamp, datetime_format=TO_SECOND_DATE_TIME_FORMAT):
    local_time = datetime.datetime.fromtimestamp(timestamp)
    # return datetime.datetime.strftime(datetime_format, local_time)
    return local_time.strftime(datetime_format)


def get_data_frame(dict_list_data, columns):
    nested_list_data = get_nested_list_data(dict_list_data, columns)
    return pd.DataFrame(np.array(nested_list_data), columns=columns)


def get_nested_list_data(dict_list_data, columns):
    nested_list_data = list()
    for dict_obj in dict_list_data:
        sublist = list()
        for column in columns:
            sublist.append(dict_obj.get(column))
        nested_list_data.append(sublist)
    return nested_list_data


# support grouping iterable data by multiple dimensions,
# return hierarchical dictionaries such as:
# group_by_l1_key1 : group_by_l2_key1 : data_dict_key1 : data_value1
#                                       data_dict_key2 : data_value2
#                    group_by_l2_key2 : data_dict_key3 : data_value3
#                                       data_dict_key4 : data_value4
# group_by_l1_key2 : group_by_l2_key1 : data_dict_key5 : data_value5
def complex_group_by_dict(iterable_data, group_by_fn_list, sub_dict_get_key_fn):
    ret_dict = dict()
    for item in iterable_data:
        group = ret_dict
        for group_by_fn in group_by_fn_list:
            group_by_key = group_by_fn(item)
            group = get_or_new_value(group, group_by_key, dict)
        item_key = sub_dict_get_key_fn(item)
        group[item_key] = item
    return ret_dict


# if the specified key can be found in the dict, return the related value,
# if not, add a new value into the dict then return it.
def get_or_new_value(data_dict, key, new_value_fn):
    data = data_dict.get(key)
    if data is None:
        if isinstance(new_value_fn, tuple):
            data = new_value_fn[0](*new_value_fn[1:])
        else:
            data = new_value_fn()
        data_dict[key] = data
    return data


# parse nested dict, return list of (keys_list, value) tuples
def parse_nested_dict(nested_dict):
    ret_list = list()
    key_list = list()
    __parse_nested_dict_one_level(nested_dict, key_list, ret_list)
    return ret_list


def __parse_nested_dict_one_level(cur_level_data, key_list, ret_list):
    if isinstance(cur_level_data, dict):
        last_dict_flag = False
        for key, sub_level_data in cur_level_data.items():
            if isinstance(sub_level_data, dict):
                __parse_nested_dict_one_level(sub_level_data, key_list + [key], ret_list)
            else:
                last_dict_flag = True
                break
        if last_dict_flag:
            ret_data = (key_list, cur_level_data)
            ret_list.append(ret_data)


def group_by_dict(iterable_data, group_by_fn, sub_dict_get_key_fn):
    ret_dict = dict()
    for item in iterable_data:
        group_by_key = group_by_fn(item)
        group = get_or_new_value(ret_dict, group_by_key, dict)
        item_key = sub_dict_get_key_fn(item)
        group[item_key] = item
    return ret_dict


def group_by_list(iterable_data, group_by_fn):
    ret_dict = dict()
    for item in iterable_data:
        group_by_key = group_by_fn(item)
        group = get_or_new_value(ret_dict, group_by_key, list)
        group.append(item)
    return ret_dict


def generate_instance(clazz_dict, init_args_origin_dict):
    clazz = clazz_dict.get(CONF_KEY_CLASS)
    if clazz is None:
        raise ConfError("'{}' field is required".format(CONF_KEY_CLASS))
    init_args_dict = init_args_origin_dict
    init_args = clazz_dict.get(CONF_KEY_INIT_ARGS)
    if init_args is not None:
        init_args_dict.update(init_args)
    constructor_fn = reflect_fn(clazz)
    return constructor_fn(**init_args_dict)


def reflect_fn(fn_path):
    global reflect_cache
    fn = reflect_cache.get(fn_path)
    if fn is None:
        tmp_arrays = fn_path.rsplit('.', 1)
        # directly return eval function if no module defined
        if len(tmp_arrays) == 1:
            return eval(fn_path)
        # logging.debug('loading module {0} class {1}'.format(tmp_arrays[0], tmp_arrays[1]))
        mod = importlib.import_module(tmp_arrays[0])
        fn = getattr(mod, tmp_arrays[1])
        reflect_cache[fn_path] = fn
    # else:
        # logging.debug('loading {0} from cache'.format(fn_path))
    return fn


def get_timer(start=True):
    return Timer(start=start)


def add_tuple_by_indexes(tp1, tp2):
    return tuple(map(lambda x: x[0] + x[1], zip(tp1, tp2)))


def divide_tuple_by_indexes(tp1, tp2):
    return tuple(map(lambda x: round(x[0] / x[1], 3) if x[1] != 0 else 0.0, zip(tp1, tp2)))


def sub_tuple_by_indexes(tp1, tp2):
    return tuple(map(lambda x: round(x[0] - x[1], 3), zip(tp1, tp2)))


def min_tuple_by_indexes(tp1, tp2):
    return tuple(map(lambda x: min(x[0], x[1]), zip(tp1, tp2)))


def max_tuple_by_indexes(tp1, tp2):
    return tuple(map(lambda x: max(x[0], x[1]), zip(tp1, tp2)))


def iterable_any_matches(its, any_match_fn):
    if its is None:
        return False
    if isinstance(its, int) or isinstance(its, float):
        return any_match_fn(its)
    for item in its:
        if any_match_fn(item):
            return True
    return False


def confirmed_list(data):
    if isinstance(data, list):
        return data
    return [data]


def add_group_item(dict_info, key, value):
    values = dict_info.get(key)
    if not values:
        values = list()
        dict_info[key] = values
    values.append(value)


# format configuration dict via replacing variables with the values given by the dict itself or other dict.
def format_conf_dict(conf_dict, other_conf_dict):
    for conf_key, conf_value in conf_dict.items():
        replace_keys = CONF_VAR_PATTERN.findall(conf_value)
        for replace_key in replace_keys:
            replace_key_name = replace_key[2:-1]
            replace_value = conf_dict.get(replace_key_name)
            if replace_value is None:
                replace_value = other_conf_dict.get(replace_key_name)
            if replace_value is None:
                logging.debug('required conf \'{}\' cannot be found in conf dict for dependent var: {}={}'.format(
                    replace_key_name, conf_key, conf_value))
                continue
            conf_dict[conf_key] = conf_value.replace(replace_key, replace_value)


# return error_message
def check_dict(target_dict, required_keys):
    required_missing = []
    for required_key in required_keys:
        if required_key not in target_dict:
            required_missing.append(required_key)
    if len(required_missing) > 0:
        return "{} is required but missing!".format(required_missing)
    return None


def generate_table(columns, rows):
    '''
    :param columns: list of column names
    :param rows: list of rows
    :return: table
    '''
    table = PrettyTable(field_names=tuple(columns), align='l')
    table.add_rows(rows)
    return table


def format_rows(rows, column_max_width=TABLE_STYLE_COLUMN_MAX_WIDTH):
    for row in rows:
        for index, row_item in enumerate(row):
            if isinstance(row_item, str) and len(row_item) > column_max_width:
                row[index] = fill(row_item, width=column_max_width)


def generate_grouped_info_table(grouped_keys, info_dict, format_fn_dict):
    """
    :param grouped_keys: list of grouped keys
    :param info_dict: info dict
    :param format_fn_dict: dict of format functions
    :return: table
    """
    rows = list()
    for grouped_key in grouped_keys:
        group_name = grouped_key.get('group_name')
        fields = grouped_key.get('fields')
        for no, field in enumerate(fields):
            key = field.get('key')
            value = info_dict.get(key)
            if value is None:
                continue
            format_fn = format_fn_dict.get(key) if format_fn_dict is not None else None
            if format_fn is not None:
                value = format_fn(value)
            alias = field.get('alias')
            row_data = [group_name if no == 0 else '', alias if alias is not None else key, value]
            rows.append(row_data)
    columns = ['Group', 'Field', 'Value']
    return generate_table(columns, rows)


def generate_compare_table(columns, row_keys, comparable_dicts, format_fn_dict):
    """
    :param columns: list of column names
    :param keys: list of keys
    :param comparable_dicts: list of comparable data dicts
    :param format_fn_dict: dict of format functions
    :return: table
    """
    rows = list()
    for row_key in row_keys:
        row = [row_key]
        format_fn = format_fn_dict.get(row_key) if format_fn_dict is not None else None
        for comparable_dict in comparable_dicts:
            value = comparable_dict.get(row_key)
            if value is None:
                row.append('')
            if format_fn is not None:
                value = format_fn(value)
            if isinstance(value, str) and len(value) > TABLE_STYLE_COLUMN_MAX_WIDTH:
                row.append(fill(value, width=TABLE_STYLE_COLUMN_MAX_WIDTH))
            else:
                row.append(value)
        rows.append(row)
    return generate_table(columns, rows)


class Timer:

    def __init__(self, start=True):
        if start:
            self.start_time = datetime.datetime.now()

    def start(self):
        self.start_time = datetime.datetime.now()

    def get_elapse_ms(self):
        elapse = datetime.datetime.now() - self.start_time
        return elapse.total_seconds() * 1000

    def get_elapse_s(self):
        elapse = datetime.datetime.now() - self.start_time
        return elapse.total_seconds()


class SimpleProgressBar:
    def __init__(self, description='', max=0, state=0, step=2):
        self.max = max
        self.state = state
        self.description = description
        self.step = step
        self.closed = False

    def __print(self, state):
        print("\r", end="")
        print("{}: {} {}".format(self.description, state, "/ {}".format(self.max) if self.max > 0 else ""),
              "▋" * (state // self.step), end="")

    def update(self, state=None):
        if state is not None:
            self.__print(state)
            if 0 < self.max == state:
                self.close()
            sys.stdout.flush()

    def close(self):
        if not self.closed:
            print("")
            self.closed = True


class QPSCalculator:

    def __init__(self):
        self.__qps_buckets_in_minutes = OrderedDict()

    def add(self, timestamp, num=1):
        struct_time = time.localtime(timestamp)

        minute_str = time.strftime(TO_MINUTE_DATE_TIME_FORMAT, struct_time)
        qps_buckets = self.__qps_buckets_in_minutes.get(minute_str)
        if qps_buckets is None:
            qps_buckets = [0] * 60
            self.__qps_buckets_in_minutes[minute_str] = qps_buckets
        sec_index = struct_time.tm_sec if struct_time.tm_sec < 60 else 59
        qps_buckets[sec_index] += num

    def get_qps_in_minutes(self):
        rst = OrderedDict()
        for minute_str, qps_buckets in self.__qps_buckets_in_minutes.items():
            rst[minute_str] = float(sum(qps_buckets)) / len(qps_buckets)
        return rst

    def get_qps_buckets_in_minutes(self):
        return self.__qps_buckets_in_minutes


def sort_by_key(info_list, sort_key, reverse=False):
    def get_value(info):
        return info.get(sort_key)
    info_list.sort(key=get_value, reverse=reverse)


def get_rows(info_list, row_keys, format_fn_dict=None):
    rows = []
    for info in info_list:
        row = []
        for key in row_keys:
            value = info.get(key)
            if not value:
                value = ''
            format_fn = format_fn_dict.get(key) if format_fn_dict is not None else None
            if format_fn:
                value = format_fn(value)
            row.append(value)
        rows.append(row)
    return rows