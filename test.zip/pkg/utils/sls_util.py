import json
from aliyun.log.logclient import LogClient


OPT_FILED_NAME_FROM_TIME = "fromTime"
OPT_FILED_NAME_TO_TIME = "toTime"
OPT_FIELD_NAME_TOPIC = "topic"
OPT_FIELD_NAME_QUERY = "query"
OPT_FIELD_NAME_OFFSET = "offset"
OPT_FIELD_NAME_SIZE = "size"
OPT_FILED_NAME_REVERSE = "reverse"


class SLSClient:

    def __init__(self, endpoint, access_key_id, access_key_secret):
        self.__cli = LogClient(endpoint, access_key_id, access_key_secret)

    def get_logs(self, target):
        re = self.__cli.get_log(target.get_project(), target.get_log_store(), target.get_from_time(),
                                target.get_to_time(), **target.get_opt_args())
        return re.get_logs()


class SLSTarget:

    def __init__(self, project=None, log_store=None, from_time=None, to_time=None):
        self.__project = project
        self.__log_store = log_store
        self.__from_time = from_time
        self.__to_time = to_time
        self.__opt_args = dict()

    def get_project(self):
        return self.__project

    def get_log_store(self):
        return self.__log_store

    def get_from_time(self):
        return self.__from_time

    def get_to_time(self):
        return self.__to_time

    def get_opt_args(self):
        return self.__opt_args

    def set_project(self, project):
        self.__project = project
        return self

    def set_log_store(self, log_store):
        self.__log_store = log_store
        return self

    def set_topic(self, topic):
        self.__opt_args[OPT_FIELD_NAME_TOPIC] = topic
        return self

    def set_query(self, query):
        self.__opt_args[OPT_FIELD_NAME_QUERY] = query
        return self

    def set_size(self, size):
        self.__opt_args[OPT_FIELD_NAME_SIZE] = size
        return self

    def set_offset(self, offset):
        self.__opt_args[OPT_FIELD_NAME_OFFSET] = offset
        return self

    def set_reverse(self, reverse):
        self.__opt_args[OPT_FILED_NAME_REVERSE] = reverse
        return self

    def __repr__(self):
        options = {
            'project': self.__project,
            'log_store': self.__log_store,
            'from_time': self.__from_time,
            'to_time': self.__to_time,
        }
        options.update(self.__opt_args)
        return json.dumps(options)

    def __str__(self):
        return self.__repr__()
