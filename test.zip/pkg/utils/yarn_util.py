import math

from pkg.utils import common_util


# parse app id from app attempt id or container id
def parse_app_id(other_id):
    parts = other_id.split('_')
    if other_id.startswith('container_e'):
        return "application_{}_{}".format(parts[2], parts[3])
    else:
        return "application_{}_{}".format(parts[1], parts[2])


def calculate_headroom(limit, used):
    headroom = common_util.sub_tuple_by_indexes(limit, used)
    if used[1] > 1 and limit[1] == 1:
        # using DefaultResourceCalculator
        tmp = list(headroom)
        tmp[1] = math.inf
        return tuple(tmp)
    return headroom
